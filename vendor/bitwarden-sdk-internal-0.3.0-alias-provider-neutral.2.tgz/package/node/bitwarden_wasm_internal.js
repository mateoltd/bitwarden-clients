/* @ts-self-types="./bitwarden_wasm_internal.d.ts" */

/**
 * Stateful provider-neutral lifecycle service around a host-injected adapter.
 */
class AliasClient {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AliasClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_aliasclient_free(ptr, 0);
    }
    /**
     * Returns the canonical encrypted connection metadata supplied at construction.
     * @returns {AliasConnection}
     */
    connection() {
        const ret = wasm.aliasclient_connection(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Creates an alias through the injected adapter.
     * @param {CreateAliasRequest} request
     * @returns {Promise<Alias>}
     */
    create(request) {
        const ret = wasm.aliasclient_create(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Creates a recipient-scoped send/reply identity.
     * @param {CreateSendReplyIdentityRequest} request
     * @returns {Promise<SendReplyIdentity>}
     */
    create_send_reply_identity(request) {
        const ret = wasm.aliasclient_create_send_reply_identity(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Deletes an alias idempotently without modifying any bound login.
     * @param {AliasIdentity} identity
     * @returns {Promise<DeleteAliasResult>}
     */
    delete(identity) {
        const ret = wasm.aliasclient_delete(this.__wbg_ptr, addHeapObject(identity));
        return takeObject(ret);
    }
    /**
     * Gets the current snapshot for a connection-scoped identity.
     * @param {AliasIdentity} identity
     * @returns {Promise<Alias>}
     */
    get(identity) {
        const ret = wasm.aliasclient_get(this.__wbg_ptr, addHeapObject(identity));
        return takeObject(ret);
    }
    /**
     * Lists a page of aliases through the injected adapter.
     * @param {ListAliasesRequest} request
     * @returns {Promise<AliasPage>}
     */
    list(request) {
        const ret = wasm.aliasclient_list(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Lists recipient-scoped send/reply identities for one alias.
     * @param {AliasIdentity} alias
     * @param {string | null} [page_token]
     * @returns {Promise<SendReplyIdentityPage>}
     */
    list_send_reply_identities(alias, page_token) {
        var ptr0 = isLikeNone(page_token) ? 0 : passStringToWasm0(page_token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.aliasclient_list_send_reply_identities(this.__wbg_ptr, addHeapObject(alias), ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Creates a lifecycle service from encrypted neutral connection metadata and a host adapter.
     * @param {AliasConnection} connection
     * @param {AliasProviderAdapter} adapter
     */
    constructor(connection, adapter) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.aliasclient_new(retptr, addHeapObject(connection), addHeapObject(adapter));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            this.__wbg_ptr = r0 >>> 0;
            AliasClientFinalization.register(this, this.__wbg_ptr, this);
            return this;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Removes a recipient-scoped send/reply identity.
     * @param {SendReplyIdentity} identity
     * @returns {Promise<void>}
     */
    remove_send_reply_identity(identity) {
        const ret = wasm.aliasclient_remove_send_reply_identity(this.__wbg_ptr, addHeapObject(identity));
        return takeObject(ret);
    }
    /**
     * Explicitly enables or disables an alias and validates the confirmed state.
     * @param {AliasIdentity} identity
     * @param {boolean} enabled
     * @returns {Promise<Alias>}
     */
    set_enabled(identity, enabled) {
        const ret = wasm.aliasclient_set_enabled(this.__wbg_ptr, addHeapObject(identity), enabled);
        return takeObject(ret);
    }
    /**
     * Sets recipient blocking when the adapter negotiated `send-reply.block`.
     * @param {SendReplyIdentity} identity
     * @param {boolean} blocked
     * @returns {Promise<SendReplyIdentity>}
     */
    set_send_reply_blocked(identity, blocked) {
        const ret = wasm.aliasclient_set_send_reply_blocked(this.__wbg_ptr, addHeapObject(identity), blocked);
        return takeObject(ret);
    }
}
if (Symbol.dispose) AliasClient.prototype[Symbol.dispose] = AliasClient.prototype.free;
exports.AliasClient = AliasClient;

/**
 * Wrapper for attachment admin operations. Uses the admin server API endpoints and does
 * not modify local state.
 */
class AttachmentAdminClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(AttachmentAdminClient.prototype);
        obj.__wbg_ptr = ptr;
        AttachmentAdminClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AttachmentAdminClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_attachmentadminclient_free(ptr, 0);
    }
    /**
     * Deletes an attachment from a cipher using the admin endpoint.
     * Affects server data only, does not modify local state.
     * @param {CipherId} cipher_id
     * @param {string} attachment_id
     * @returns {Promise<Cipher>}
     */
    delete_attachment(cipher_id, attachment_id) {
        const ptr0 = passStringToWasm0(attachment_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.attachmentadminclient_delete_attachment(this.__wbg_ptr, addHeapObject(cipher_id), ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Fetches the download URL for an attachment from the admin API. The admin client has
     * no local repository to fall back to on 404, so a server-side 404 is surfaced as
     * [`CipherAdminGetAttachmentDownloadUrlError::NotFound`] for the caller to handle.
     * @param {CipherId} cipher_id
     * @param {string} attachment_id
     * @returns {Promise<string>}
     */
    get_attachment_download_url(cipher_id, attachment_id) {
        const ptr0 = passStringToWasm0(attachment_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.attachmentadminclient_get_attachment_download_url(this.__wbg_ptr, addHeapObject(cipher_id), ptr0, len0);
        return takeObject(ret);
    }
}
if (Symbol.dispose) AttachmentAdminClient.prototype[Symbol.dispose] = AttachmentAdminClient.prototype.free;
exports.AttachmentAdminClient = AttachmentAdminClient;

/**
 * Wrapper for attachment-specific cipher operations.
 */
class AttachmentsClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(AttachmentsClient.prototype);
        obj.__wbg_ptr = ptr;
        AttachmentsClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AttachmentsClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_attachmentsclient_free(ptr, 0);
    }
    /**
     * Returns a new client for performing attachment admin operations.
     * Uses the admin server API endpoints and does not modify local state.
     * @returns {AttachmentAdminClient}
     */
    admin() {
        const ret = wasm.attachmentsclient_admin(this.__wbg_ptr);
        return AttachmentAdminClient.__wrap(ret);
    }
    /**
     * Creates a new attachment slot on the server and updates local repository
     * state with the merged cipher returned by the server.
     *
     * The caller must upload the encrypted bytes to [`CreatedAttachment::upload_url`]
     * using the transport in [`CreatedAttachment::file_upload_type`].
     *
     * If a later step fails after slot creation, the SDK best-effort deletes the
     * orphaned slot and returns the original error.
     * @param {CipherId} cipher_id
     * @param {CreateAttachmentRequest} request
     * @returns {Promise<CreatedAttachment>}
     */
    create_attachment(cipher_id, request) {
        const ret = wasm.attachmentsclient_create_attachment(this.__wbg_ptr, addHeapObject(cipher_id), addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * @param {Cipher} cipher
     * @param {AttachmentView} attachment
     * @param {Uint8Array} encrypted_buffer
     * @returns {Uint8Array}
     */
    decrypt_buffer(cipher, attachment, encrypted_buffer) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(encrypted_buffer, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.attachmentsclient_decrypt_buffer(retptr, this.__wbg_ptr, addHeapObject(cipher), addHeapObject(attachment), ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v2 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v2;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Deletes an attachment from a cipher, and updates the local repository with the new
     * cipher data returned from the API.
     * @param {CipherId} cipher_id
     * @param {string} attachment_id
     * @returns {Promise<Cipher>}
     */
    delete_attachment(cipher_id, attachment_id) {
        const ptr0 = passStringToWasm0(attachment_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.attachmentsclient_delete_attachment(this.__wbg_ptr, addHeapObject(cipher_id), ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Returns the attachment download URL.
     *
     * With `emergency_access_id`, uses the emergency-access endpoint and never falls back.
     * Otherwise uses the cipher endpoint and falls back to the local repository on 404.
     * @param {CipherId} cipher_id
     * @param {string} attachment_id
     * @param {string | null} [emergency_access_id]
     * @returns {Promise<string>}
     */
    get_attachment_download_url(cipher_id, attachment_id, emergency_access_id) {
        const ptr0 = passStringToWasm0(attachment_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(emergency_access_id) ? 0 : passStringToWasm0(emergency_access_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.attachmentsclient_get_attachment_download_url(this.__wbg_ptr, addHeapObject(cipher_id), ptr0, len0, ptr1, len1);
        return takeObject(ret);
    }
    /**
     * Returns a renewed upload URL for an attachment.
     * Does not modify the attachment slot.
     * @param {CipherId} cipher_id
     * @param {string} attachment_id
     * @returns {Promise<string>}
     */
    renew_file_upload_url(cipher_id, attachment_id) {
        const ptr0 = passStringToWasm0(attachment_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.attachmentsclient_renew_file_upload_url(this.__wbg_ptr, addHeapObject(cipher_id), ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Upgrades a legacy v1 attachment to `CipherKey(AttachmentKey(Contents))`.
     *
     * Downloads and re-encrypts the attachment, creates a new slot, uploads the
     * new bytes, then deletes the old attachment. If the upload fails, it tries
     * to delete the new slot before returning the error. Returns the decrypted
     * cipher view.
     * @param {CipherId} cipher_id
     * @param {string} attachment_id
     * @returns {Promise<CipherView>}
     */
    upgrade_attachment(cipher_id, attachment_id) {
        const ptr0 = passStringToWasm0(attachment_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.attachmentsclient_upgrade_attachment(this.__wbg_ptr, addHeapObject(cipher_id), ptr0, len0);
        return takeObject(ret);
    }
}
if (Symbol.dispose) AttachmentsClient.prototype[Symbol.dispose] = AttachmentsClient.prototype.free;
exports.AttachmentsClient = AttachmentsClient;

/**
 * Subclient containing auth functionality.
 */
class AuthClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(AuthClient.prototype);
        obj.__wbg_ptr = ptr;
        AuthClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AuthClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_authclient_free(ptr, 0);
    }
    /**
     * Client for login functionality
     * @returns {LoginClient}
     */
    login() {
        const ret = wasm.authclient_login(this.__wbg_ptr);
        return LoginClient.__wrap(ret);
    }
    /**
     * Client for initializing user account cryptography and unlock methods after JIT provisioning
     * @returns {RegistrationClient}
     */
    registration() {
        const ret = wasm.authclient_registration(this.__wbg_ptr);
        return RegistrationClient.__wrap(ret);
    }
    /**
     * Client for send access functionality
     * @returns {SendAccessClient}
     */
    send_access() {
        const ret = wasm.authclient_send_access(this.__wbg_ptr);
        return SendAccessClient.__wrap(ret);
    }
}
if (Symbol.dispose) AuthClient.prototype[Symbol.dispose] = AuthClient.prototype.free;
exports.AuthClient = AuthClient;

/**
 * Indicates the authentication strategy to use when accessing a Send
 * @enum {0 | 1 | 2}
 */
const AuthType = Object.freeze({
    /**
     * Email-based OTP authentication
     */
    Email: 0, "0": "Email",
    /**
     * Password-based authentication
     */
    Password: 1, "1": "Password",
    /**
     * No authentication required
     */
    None: 2, "2": "None",
});
exports.AuthType = AuthType;

/**
 * The current biometric capability state for a specific user on this client.
 * @enum {0 | 1 | 2 | 3}
 */
const BiometricsStatus = Object.freeze({
    /**
     * Biometrics is available and can be used immediately.
     */
    Available: 0, "0": "Available",
    /**
     * Biometrics is supported, but user interaction is required before unlock can proceed.
     */
    UnlockNeeded: 1, "1": "UnlockNeeded",
    /**
     * Biometrics hardware or platform support is unavailable.
     */
    HardwareUnavailable: 2, "2": "HardwareUnavailable",
    /**
     * Biometrics is supported but not enabled for this user.
     */
    NotEnabled: 3, "3": "NotEnabled",
});
exports.BiometricsStatus = BiometricsStatus;

/**
 * @enum {300 | 301 | 302 | 303 | 304 | 305}
 */
const CardLinkedIdType = Object.freeze({
    CardholderName: 300, "300": "CardholderName",
    ExpMonth: 301, "301": "ExpMonth",
    ExpYear: 302, "302": "ExpYear",
    Code: 303, "303": "Code",
    Brand: 304, "304": "Brand",
    Number: 305, "305": "Number",
});
exports.CardLinkedIdType = CardLinkedIdType;

/**
 * Client for performing admin operations on ciphers. Unlike the regular CiphersClient,
 * this client uses the admin server API endpoints, and does not modify local state.
 */
class CipherAdminClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CipherAdminClient.prototype);
        obj.__wbg_ptr = ptr;
        CipherAdminClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CipherAdminClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_cipheradminclient_free(ptr, 0);
    }
    /**
     * Creates a new [Cipher] for an organization, using the admin server endpoints.
     * Creates the Cipher on the server only, does not store it to local state.
     * @param {CipherCreateRequest} request
     * @returns {Promise<CipherView>}
     */
    create(request) {
        const ret = wasm.cipheradminclient_create(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Deletes the Cipher with the matching CipherId from the server, using the admin endpoint.
     * Affects server data only, does not modify local state.
     * @param {CipherId} cipher_id
     * @returns {Promise<void>}
     */
    delete(cipher_id) {
        const ret = wasm.cipheradminclient_delete(this.__wbg_ptr, addHeapObject(cipher_id));
        return takeObject(ret);
    }
    /**
     * Deletes all Cipher objects with a matching CipherId from the server, using the admin
     * endpoint. Affects server data only, does not modify local state.
     * @param {CipherId[]} cipher_ids
     * @param {OrganizationId} organization_id
     * @returns {Promise<void>}
     */
    delete_many(cipher_ids, organization_id) {
        const ptr0 = passArrayJsValueToWasm0(cipher_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.cipheradminclient_delete_many(this.__wbg_ptr, ptr0, len0, addHeapObject(organization_id));
        return takeObject(ret);
    }
    /**
     * Edit an existing [Cipher] and save it to the server.
     * @param {CipherEditRequest} request
     * @param {CipherView} original_cipher_view
     * @returns {Promise<CipherView>}
     */
    edit(request, original_cipher_view) {
        const ret = wasm.cipheradminclient_edit(this.__wbg_ptr, addHeapObject(request), addHeapObject(original_cipher_view));
        return takeObject(ret);
    }
    /**
     * Fetches and decrypts all ciphers assigned to the current user for an organization.
     * @param {OrganizationId} org_id
     * @returns {Promise<ListOrganizationCiphersResult>}
     */
    list_assigned_org_ciphers(org_id) {
        const ret = wasm.cipheradminclient_list_assigned_org_ciphers(this.__wbg_ptr, addHeapObject(org_id));
        return takeObject(ret);
    }
    /**
     * Get all ciphers for an organization.
     * @param {OrganizationId} org_id
     * @param {boolean} include_member_items
     * @returns {Promise<ListOrganizationCiphersResult>}
     */
    list_org_ciphers(org_id, include_member_items) {
        const ret = wasm.cipheradminclient_list_org_ciphers(this.__wbg_ptr, addHeapObject(org_id), include_member_items);
        return takeObject(ret);
    }
    /**
     * Restores a soft-deleted cipher on the server, using the admin endpoint.
     * @param {CipherId} cipher_id
     * @returns {Promise<CipherView>}
     */
    restore(cipher_id) {
        const ret = wasm.cipheradminclient_restore(this.__wbg_ptr, addHeapObject(cipher_id));
        return takeObject(ret);
    }
    /**
     * Restores multiple soft-deleted ciphers on the server.
     * @param {CipherId[]} cipher_ids
     * @param {OrganizationId} org_id
     * @returns {Promise<DecryptCipherListResult>}
     */
    restore_many(cipher_ids, org_id) {
        const ptr0 = passArrayJsValueToWasm0(cipher_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.cipheradminclient_restore_many(this.__wbg_ptr, ptr0, len0, addHeapObject(org_id));
        return takeObject(ret);
    }
    /**
     * Soft-deletes the Cipher with the matching CipherId from the server, using the admin
     * endpoint. Affects server data only, does not modify local state.
     * @param {CipherId} cipher_id
     * @returns {Promise<void>}
     */
    soft_delete(cipher_id) {
        const ret = wasm.cipheradminclient_soft_delete(this.__wbg_ptr, addHeapObject(cipher_id));
        return takeObject(ret);
    }
    /**
     * Soft-deletes all Cipher objects for the given CipherIds from the server, using the admin
     * endpoint. Affects server data only, does not modify local state.
     * @param {CipherId[]} cipher_ids
     * @param {OrganizationId} organization_id
     * @returns {Promise<void>}
     */
    soft_delete_many(cipher_ids, organization_id) {
        const ptr0 = passArrayJsValueToWasm0(cipher_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.cipheradminclient_soft_delete_many(this.__wbg_ptr, ptr0, len0, addHeapObject(organization_id));
        return takeObject(ret);
    }
    /**
     * Adds the cipher matched by [CipherId] to any number of collections on the server.
     * @param {CipherId} cipher_id
     * @param {CollectionId[]} collection_ids
     * @returns {Promise<CipherView>}
     */
    update_collection(cipher_id, collection_ids) {
        const ptr0 = passArrayJsValueToWasm0(collection_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.cipheradminclient_update_collection(this.__wbg_ptr, addHeapObject(cipher_id), ptr0, len0);
        return takeObject(ret);
    }
}
if (Symbol.dispose) CipherAdminClient.prototype[Symbol.dispose] = CipherAdminClient.prototype.free;
exports.CipherAdminClient = CipherAdminClient;

/**
 * @enum {0 | 1}
 */
const CipherRepromptType = Object.freeze({
    None: 0, "0": "None",
    Password: 1, "1": "Password",
});
exports.CipherRepromptType = CipherRepromptType;

/**
 * Client for evaluating credential risk for login ciphers.
 */
class CipherRiskClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CipherRiskClient.prototype);
        obj.__wbg_ptr = ptr;
        CipherRiskClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CipherRiskClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_cipherriskclient_free(ptr, 0);
    }
    /**
     * Evaluate security risks for multiple login ciphers concurrently.
     *
     * For each cipher:
     * 1. Calculates password strength (0-4) using zxcvbn with cipher-specific context
     * 2. Optionally checks if the password has been exposed via Have I Been Pwned API
     * 3. Counts how many times the password is reused in the provided `password_map`
     *
     * Returns a vector of `CipherRisk` results, one for each input cipher.
     *
     * ## HIBP Check Results (`exposed_result` field)
     *
     * The `exposed_result` field uses the `ExposedPasswordResult` enum with three possible states:
     * - `NotChecked`: Password exposure check was not performed because:
     *   - `check_exposed` option was `false`, or
     *   - Password was empty
     * - `Found(n)`: Successfully checked via HIBP API, password appears in `n` data breaches
     * - `Error(msg)`: HIBP API request failed with error message `msg`
     *
     * # Errors
     *
     * This method only returns `Err` for internal logic failures. HIBP API errors are
     * captured per-cipher in the `exposed_result` field as `ExposedPasswordResult::Error(msg)`.
     * @param {CipherLoginDetails[]} login_details
     * @param {CipherRiskOptions} options
     * @returns {Promise<CipherRiskResult[]>}
     */
    compute_risk(login_details, options) {
        const ptr0 = passArrayJsValueToWasm0(login_details, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.cipherriskclient_compute_risk(this.__wbg_ptr, ptr0, len0, addHeapObject(options));
        return takeObject(ret);
    }
    /**
     * Build password reuse map for a list of login ciphers.
     *
     * Returns a map where keys are passwords and values are the number of times
     * each password appears in the provided list. This map can be passed to `compute_risk()`
     * to enable password reuse detection.
     * @param {CipherLoginDetails[]} login_details
     * @returns {PasswordReuseMap}
     */
    password_reuse_map(login_details) {
        const ptr0 = passArrayJsValueToWasm0(login_details, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.cipherriskclient_password_reuse_map(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
}
if (Symbol.dispose) CipherRiskClient.prototype[Symbol.dispose] = CipherRiskClient.prototype.free;
exports.CipherRiskClient = CipherRiskClient;

/**
 * @enum {1 | 2 | 3 | 4 | 5 | 6 | 7 | 8}
 */
const CipherType = Object.freeze({
    Login: 1, "1": "Login",
    SecureNote: 2, "2": "SecureNote",
    Card: 3, "3": "Card",
    Identity: 4, "4": "Identity",
    SshKey: 5, "5": "SshKey",
    BankAccount: 6, "6": "BankAccount",
    DriversLicense: 7, "7": "DriversLicense",
    Passport: 8, "8": "Passport",
});
exports.CipherType = CipherType;

class CiphersClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CiphersClient.prototype);
        obj.__wbg_ptr = ptr;
        CiphersClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CiphersClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_ciphersclient_free(ptr, 0);
    }
    /**
     * Returns a new client for performing admin operations.
     * Uses the admin server API endpoints and does not modify local state.
     * @returns {CipherAdminClient}
     */
    admin() {
        const ret = wasm.ciphersclient_admin(this.__wbg_ptr);
        return CipherAdminClient.__wrap(ret);
    }
    /**
     * Updates collection membership for multiple [`Cipher`](crate::Cipher) objects.
     *
     * When `remove_collections` is `true`, the given collection IDs are removed from each cipher.
     * When `false`, they are added without introducing duplicates.
     * @param {OrganizationId} organization_id
     * @param {CipherId[]} cipher_ids
     * @param {CollectionId[]} collection_ids
     * @param {boolean} remove_collections
     * @returns {Promise<void>}
     */
    bulk_update_collections(organization_id, cipher_ids, collection_ids, remove_collections) {
        const ptr0 = passArrayJsValueToWasm0(cipher_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(collection_ids, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.ciphersclient_bulk_update_collections(this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0, ptr1, len1, remove_collections);
        return takeObject(ret);
    }
    /**
     * Creates a new [Cipher] and saves it to the server.
     * @param {CipherCreateRequest} request
     * @returns {Promise<CipherView>}
     */
    create(request) {
        const ret = wasm.ciphersclient_create(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * @param {Cipher} cipher
     * @returns {Promise<CipherView>}
     */
    decrypt(cipher) {
        const ret = wasm.ciphersclient_decrypt(this.__wbg_ptr, addHeapObject(cipher));
        return takeObject(ret);
    }
    /**
     * @param {Cipher[]} ciphers
     * @returns {Promise<CipherListView[]>}
     */
    decrypt_list(ciphers) {
        const ptr0 = passArrayJsValueToWasm0(ciphers, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ciphersclient_decrypt_list(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Decrypt full cipher list
     * Returns both successfully fully decrypted ciphers and any that failed to decrypt
     * @param {Cipher[]} ciphers
     * @returns {Promise<DecryptCipherResult>}
     */
    decrypt_list_full_with_failures(ciphers) {
        const ptr0 = passArrayJsValueToWasm0(ciphers, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ciphersclient_decrypt_list_full_with_failures(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Decrypt cipher list with failures
     * Returns both successfully decrypted ciphers and any that failed to decrypt
     * @param {Cipher[]} ciphers
     * @returns {Promise<DecryptCipherListResult>}
     */
    decrypt_list_with_failures(ciphers) {
        const ptr0 = passArrayJsValueToWasm0(ciphers, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ciphersclient_decrypt_list_with_failures(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Deletes the [Cipher] with the matching [CipherId] from the server.
     * @param {CipherId} cipher_id
     * @returns {Promise<void>}
     */
    delete(cipher_id) {
        const ret = wasm.ciphersclient_delete(this.__wbg_ptr, addHeapObject(cipher_id));
        return takeObject(ret);
    }
    /**
     * Deletes all [Cipher] objects with a matching [CipherId] from the server.
     * @param {CipherId[]} cipher_ids
     * @param {OrganizationId | null} [organization_id]
     * @returns {Promise<void>}
     */
    delete_many(cipher_ids, organization_id) {
        const ptr0 = passArrayJsValueToWasm0(cipher_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ciphersclient_delete_many(this.__wbg_ptr, ptr0, len0, isLikeNone(organization_id) ? 0 : addHeapObject(organization_id));
        return takeObject(ret);
    }
    /**
     * Edit an existing [Cipher] and save it to the server.
     * @param {CipherEditRequest} request
     * @returns {Promise<CipherView>}
     */
    edit(request) {
        const ret = wasm.ciphersclient_edit(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Edit a PAM-gated [`Cipher`] whose secrets were revealed under an active lease.
     *
     * [`CiphersClient::edit`] builds its original from local state, which for a gated cipher only
     * ever holds the partial copy, and so refuses. Pass the full view obtained from the
     * lease-authorised read as `original_cipher_view` — it is what password history is diffed
     * against.
     *
     * The returned view reflects what was persisted, so it is partial: the server withholds
     * secrets from a gated write-return. The caller keeps its own full copy in memory.
     * @param {CipherEditRequest} request
     * @param {CipherView} original_cipher_view
     * @returns {Promise<CipherView>}
     */
    edit_gated(request, original_cipher_view) {
        const ret = wasm.ciphersclient_edit_gated(this.__wbg_ptr, addHeapObject(request), addHeapObject(original_cipher_view));
        return takeObject(ret);
    }
    /**
     * Update only `folder_id` and `favorite` on an existing [Cipher].
     *
     * Intended for users who do not have edit permissions on the cipher, but
     * are still allowed to change these personal organization fields.
     * @param {CipherPartialEditRequest} request
     * @returns {Promise<CipherView>}
     */
    edit_partial(request) {
        const ret = wasm.ciphersclient_edit_partial(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * @param {CipherView} cipher_view
     * @returns {Promise<EncryptionContext>}
     */
    encrypt(cipher_view) {
        const ret = wasm.ciphersclient_encrypt(this.__wbg_ptr, addHeapObject(cipher_view));
        return takeObject(ret);
    }
    /**
     * Encrypt a cipher with the provided key. This should only be used when rotating encryption
     * keys in the Web client.
     *
     * Until key rotation is fully implemented in the SDK, this method must be provided the new
     * symmetric key in base64 format. See PM-23084
     *
     * If the cipher has a CipherKey, it will be re-encrypted with the new key.
     * If the cipher does not have a CipherKey and CipherKeyEncryption is enabled, one will be
     * generated using the new key. Otherwise, the cipher's data will be encrypted with the new
     * key directly.
     * @param {CipherView} cipher_view
     * @param {B64} new_key
     * @returns {Promise<EncryptionContext>}
     */
    encrypt_cipher_for_rotation(cipher_view, new_key) {
        const ret = wasm.ciphersclient_encrypt_cipher_for_rotation(this.__wbg_ptr, addHeapObject(cipher_view), addHeapObject(new_key));
        return takeObject(ret);
    }
    /**
     * Encrypt a list of cipher views.
     *
     * This method attempts to encrypt all ciphers in the list. If any cipher
     * fails to encrypt, the entire operation fails and an error is returned.
     * @param {CipherView[]} cipher_views
     * @returns {Promise<EncryptionContext[]>}
     */
    encrypt_list(cipher_views) {
        const ptr0 = passArrayJsValueToWasm0(cipher_views, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ciphersclient_encrypt_list(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Get [Cipher] by ID from state and decrypt it to a [CipherView].
     * @param {string} cipher_id
     * @returns {Promise<CipherView>}
     */
    get(cipher_id) {
        const ptr0 = passStringToWasm0(cipher_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ciphersclient_get(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Get all ciphers from state and decrypt them to full [CipherView], returning both
     * successes and failures. This method will not fail when some ciphers fail to decrypt,
     * allowing for graceful handling of corrupted or problematic cipher data.
     * @returns {Promise<DecryptCipherResult>}
     */
    get_all() {
        const ret = wasm.ciphersclient_get_all(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Get all ciphers from state and decrypt them to [crate::CipherListView], returning both
     * successes and failures. This method will not fail when some ciphers fail to decrypt,
     * allowing for graceful handling of corrupted or problematic cipher data.
     * @returns {Promise<DecryptCipherListResult>}
     */
    list() {
        const ret = wasm.ciphersclient_list(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Moves multiple [`Cipher`](crate::Cipher) objects to a folder, or clears their folder when
     * `folder_id` is `None`.
     * @param {CipherId[]} cipher_ids
     * @param {FolderId | null} [folder_id]
     * @returns {Promise<void>}
     */
    move_many(cipher_ids, folder_id) {
        const ptr0 = passArrayJsValueToWasm0(cipher_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ciphersclient_move_many(this.__wbg_ptr, ptr0, len0, isLikeNone(folder_id) ? 0 : addHeapObject(folder_id));
        return takeObject(ret);
    }
    /**
     * @param {CipherView} cipher_view
     * @param {OrganizationId} organization_id
     * @returns {CipherView}
     */
    move_to_organization(cipher_view, organization_id) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.ciphersclient_move_to_organization(retptr, this.__wbg_ptr, addHeapObject(cipher_view), addHeapObject(organization_id));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Restores a soft-deleted cipher on the server.
     * @param {CipherId} cipher_id
     * @returns {Promise<CipherView>}
     */
    restore(cipher_id) {
        const ret = wasm.ciphersclient_restore(this.__wbg_ptr, addHeapObject(cipher_id));
        return takeObject(ret);
    }
    /**
     * Restores multiple soft-deleted ciphers on the server.
     * @param {CipherId[]} cipher_ids
     * @returns {Promise<DecryptCipherListResult>}
     */
    restore_many(cipher_ids) {
        const ptr0 = passArrayJsValueToWasm0(cipher_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ciphersclient_restore_many(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Temporary method used to re-encrypt FIDO2 credentials for a cipher view.
     * Necessary until the TS clients utilize the SDK entirely for FIDO2 credentials management.
     * TS clients create decrypted FIDO2 credentials that need to be encrypted manually when
     * encrypting the rest of the CipherView.
     * TODO: Remove once TS passkey provider implementation uses SDK - PM-8313
     * @param {CipherView} cipher_view
     * @param {Fido2CredentialFullView[]} fido2_credentials
     * @returns {CipherView}
     */
    set_fido2_credentials(cipher_view, fido2_credentials) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArrayJsValueToWasm0(fido2_credentials, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.ciphersclient_set_fido2_credentials(retptr, this.__wbg_ptr, addHeapObject(cipher_view), ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Moves a cipher into an organization, adds it to collections, and calls the share_cipher API.
     * @param {CipherView} cipher_view
     * @param {OrganizationId} organization_id
     * @param {CollectionId[]} collection_ids
     * @param {CipherView | null} [original_cipher_view]
     * @returns {Promise<CipherView>}
     */
    share_cipher(cipher_view, organization_id, collection_ids, original_cipher_view) {
        const ptr0 = passArrayJsValueToWasm0(collection_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ciphersclient_share_cipher(this.__wbg_ptr, addHeapObject(cipher_view), addHeapObject(organization_id), ptr0, len0, isLikeNone(original_cipher_view) ? 0 : addHeapObject(original_cipher_view));
        return takeObject(ret);
    }
    /**
     * Moves a group of ciphers into an organization, adds them to collections, and calls the
     * share_ciphers API.
     * @param {CipherView[]} cipher_views
     * @param {OrganizationId} organization_id
     * @param {CollectionId[]} collection_ids
     * @returns {Promise<CipherView[]>}
     */
    share_ciphers_bulk(cipher_views, organization_id, collection_ids) {
        const ptr0 = passArrayJsValueToWasm0(cipher_views, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(collection_ids, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.ciphersclient_share_ciphers_bulk(this.__wbg_ptr, ptr0, len0, addHeapObject(organization_id), ptr1, len1);
        return takeObject(ret);
    }
    /**
     * Soft-deletes the [Cipher] with the matching [CipherId] from the server.
     * @param {CipherId} cipher_id
     * @returns {Promise<void>}
     */
    soft_delete(cipher_id) {
        const ret = wasm.ciphersclient_soft_delete(this.__wbg_ptr, addHeapObject(cipher_id));
        return takeObject(ret);
    }
    /**
     * Soft-deletes all [Cipher] objects for the given [CipherId]s from the server.
     * @param {CipherId[]} cipher_ids
     * @param {OrganizationId | null} [organization_id]
     * @returns {Promise<void>}
     */
    soft_delete_many(cipher_ids, organization_id) {
        const ptr0 = passArrayJsValueToWasm0(cipher_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ciphersclient_soft_delete_many(this.__wbg_ptr, ptr0, len0, isLikeNone(organization_id) ? 0 : addHeapObject(organization_id));
        return takeObject(ret);
    }
    /**
     * Adds the cipher matched by [CipherId] to any number of collections on the server.
     * @param {CipherId} cipher_id
     * @param {CollectionId[]} collection_ids
     * @param {boolean} is_admin
     * @returns {Promise<CipherView>}
     */
    update_collection(cipher_id, collection_ids, is_admin) {
        const ptr0 = passArrayJsValueToWasm0(collection_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ciphersclient_update_collection(this.__wbg_ptr, addHeapObject(cipher_id), ptr0, len0, is_admin);
        return takeObject(ret);
    }
}
if (Symbol.dispose) CiphersClient.prototype[Symbol.dispose] = CiphersClient.prototype.free;
exports.CiphersClient = CiphersClient;

/**
 * Type of collection
 * @enum {0 | 1}
 */
const CollectionType = Object.freeze({
    /**
     * Default collection type. Can be assigned by an organization to user(s) or group(s)
     */
    SharedCollection: 0, "0": "SharedCollection",
    /**
     * Default collection assigned to a user for an organization that has
     * OrganizationDataOwnership (formerly PersonalOwnership) policy enabled.
     */
    DefaultUserCollection: 1, "1": "DefaultUserCollection",
});
exports.CollectionType = CollectionType;

class CollectionViewNodeItem {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CollectionViewNodeItem.prototype);
        obj.__wbg_ptr = ptr;
        CollectionViewNodeItemFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CollectionViewNodeItemFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_collectionviewnodeitem_free(ptr, 0);
    }
    /**
     * @returns {AncestorMap}
     */
    get_ancestors() {
        const ret = wasm.collectionviewnodeitem_get_ancestors(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * @returns {CollectionView[]}
     */
    get_children() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.collectionviewnodeitem_get_children(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var v1 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * @returns {CollectionView}
     */
    get_item() {
        const ret = wasm.collectionviewnodeitem_get_item(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * @returns {CollectionView | undefined}
     */
    get_parent() {
        const ret = wasm.collectionviewnodeitem_get_parent(this.__wbg_ptr);
        return takeObject(ret);
    }
}
if (Symbol.dispose) CollectionViewNodeItem.prototype[Symbol.dispose] = CollectionViewNodeItem.prototype.free;
exports.CollectionViewNodeItem = CollectionViewNodeItem;

class CollectionViewTree {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CollectionViewTree.prototype);
        obj.__wbg_ptr = ptr;
        CollectionViewTreeFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CollectionViewTreeFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_collectionviewtree_free(ptr, 0);
    }
    /**
     * @returns {CollectionViewNodeItem[]}
     */
    get_flat_items() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.collectionviewtree_get_flat_items(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var v1 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * @param {CollectionView} collection_view
     * @returns {CollectionViewNodeItem | undefined}
     */
    get_item_for_view(collection_view) {
        const ret = wasm.collectionviewtree_get_item_for_view(this.__wbg_ptr, addHeapObject(collection_view));
        return ret === 0 ? undefined : CollectionViewNodeItem.__wrap(ret);
    }
    /**
     * @returns {CollectionViewNodeItem[]}
     */
    get_root_items() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.collectionviewtree_get_root_items(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var v1 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
}
if (Symbol.dispose) CollectionViewTree.prototype[Symbol.dispose] = CollectionViewTree.prototype.free;
exports.CollectionViewTree = CollectionViewTree;

class CollectionsClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CollectionsClient.prototype);
        obj.__wbg_ptr = ptr;
        CollectionsClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CollectionsClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_collectionsclient_free(ptr, 0);
    }
    /**
     * @param {Collection} collection
     * @returns {CollectionView}
     */
    decrypt(collection) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.collectionsclient_decrypt(retptr, this.__wbg_ptr, addHeapObject(collection));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * @param {Collection[]} collections
     * @returns {CollectionView[]}
     */
    decrypt_list(collections) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArrayJsValueToWasm0(collections, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.collectionsclient_decrypt_list(retptr, this.__wbg_ptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v2 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v2;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Decrypts a list of collections, returning successes and failures separately.
     *
     * Unlike `decrypt_list`, a single collection that fails to decrypt (e.g. due to a missing
     * organization key) does not abort the entire batch — it is returned in `failures` instead.
     * @param {Collection[]} collections
     * @returns {DecryptCollectionListResult}
     */
    decrypt_list_with_failures(collections) {
        const ptr0 = passArrayJsValueToWasm0(collections, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.collectionsclient_decrypt_list_with_failures(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Encrypts a [CollectionView] into an encrypted [Collection] using the organization key.
     * @param {CollectionView} collection_view
     * @returns {Collection}
     */
    encrypt(collection_view) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.collectionsclient_encrypt(retptr, this.__wbg_ptr, addHeapObject(collection_view));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Encrypts a list of [CollectionView]s into encrypted [Collection]s using the organization
     * key.
     * @param {CollectionView[]} collection_views
     * @returns {Collection[]}
     */
    encrypt_list(collection_views) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArrayJsValueToWasm0(collection_views, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.collectionsclient_encrypt_list(retptr, this.__wbg_ptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v2 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v2;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     *
     * Returns the vector of CollectionView objects in a tree structure based on its implemented
     * path().
     * @param {CollectionView[]} collections
     * @returns {CollectionViewTree}
     */
    get_collection_tree(collections) {
        const ptr0 = passArrayJsValueToWasm0(collections, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.collectionsclient_get_collection_tree(this.__wbg_ptr, ptr0, len0);
        return CollectionViewTree.__wrap(ret);
    }
}
if (Symbol.dispose) CollectionsClient.prototype[Symbol.dispose] = CollectionsClient.prototype.free;
exports.CollectionsClient = CollectionsClient;

/**
 * Tells you which cryptographic algorithms to use for the current account and environment.
 *
 * Some environments are restricted in which algorithms they may use — for example, government
 * (FedRAMP) deployments must use FIPS-approved algorithms. Ask this client which algorithm to use
 * instead of picking one yourself, so the choice stays correct as those rules change.
 */
class CryptoCipherSuiteClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CryptoCipherSuiteClient.prototype);
        obj.__wbg_ptr = ptr;
        CryptoCipherSuiteClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CryptoCipherSuiteClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_cryptociphersuiteclient_free(ptr, 0);
    }
    /**
     * Returns the KDF a new account should use in the current environment.
     *
     * In a FIPS (gov) environment the FIPS-approved PBKDF2 is used; otherwise the modern Argon2id
     * default.
     * @returns {Kdf}
     */
    default_kdf_for_new_account() {
        const ret = wasm.cryptociphersuiteclient_default_kdf_for_new_account(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Returns whether the given KDF is allowed in the current environment.
     *
     * Intended for surfaces that let a user pick a KDF (e.g. the Change KDF settings screen): the
     * caller can validate or filter the options it offers. In a FIPS (gov) environment only PBKDF2
     * is allowed; otherwise every supported KDF is allowed.
     * @param {Kdf} kdf
     * @returns {boolean}
     */
    is_kdf_compliant(kdf) {
        const ret = wasm.cryptociphersuiteclient_is_kdf_compliant(this.__wbg_ptr, addHeapObject(kdf));
        return ret !== 0;
    }
}
if (Symbol.dispose) CryptoCipherSuiteClient.prototype[Symbol.dispose] = CryptoCipherSuiteClient.prototype.free;
exports.CryptoCipherSuiteClient = CryptoCipherSuiteClient;

/**
 * A client for the crypto operations.
 */
class CryptoClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CryptoClient.prototype);
        obj.__wbg_ptr = ptr;
        CryptoClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CryptoClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_cryptoclient_free(ptr, 0);
    }
    /**
     * A stop gap-solution for decrypting with the local user data key, until the WASM client's
     * password generator history encryption and email forwarders encryption is fully migrated to
     * SDK.
     * @param {string} encrypted_plaintext
     * @returns {string}
     */
    decrypt_with_local_user_data_key(encrypted_plaintext) {
        let deferred3_0;
        let deferred3_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(encrypted_plaintext, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.cryptoclient_decrypt_with_local_user_data_key(retptr, this.__wbg_ptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr2 = r0;
            var len2 = r1;
            if (r3) {
                ptr2 = 0; len2 = 0;
                throw takeObject(r2);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * A stop gap-solution for encrypting with the local user data key, until the WASM client's
     * password generator history encryption and email forwarders encryption is fully migrated to
     * SDK.
     * @param {string} plaintext
     * @returns {string}
     */
    encrypt_with_local_user_data_key(plaintext) {
        let deferred3_0;
        let deferred3_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(plaintext, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.cryptoclient_encrypt_with_local_user_data_key(retptr, this.__wbg_ptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr2 = r0;
            var len2 = r1;
            if (r3) {
                ptr2 = 0; len2 = 0;
                throw takeObject(r2);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Protects the current user key with the provided PIN. The result can be stored and later
     * used to initialize another client instance by using the PIN and the PIN key with
     * `initialize_user_crypto`.
     * @param {string} pin
     * @returns {EnrollPinResponse}
     */
    enroll_pin(pin) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(pin, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.cryptoclient_enroll_pin(retptr, this.__wbg_ptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Protects the current user key with the provided PIN. The result can be stored and later
     * used to initialize another client instance by using the PIN and the PIN key with
     * `initialize_user_crypto`. The provided pin is encrypted with the user key.
     * @param {string} encrypted_pin
     * @returns {EnrollPinResponse}
     */
    enroll_pin_with_encrypted_pin(encrypted_pin) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(encrypted_pin, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.cryptoclient_enroll_pin_with_encrypted_pin(retptr, this.__wbg_ptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Takes a raw key and returns the corresponding key id. This is used for the biometrics
     * subsystem and should be removed after moving over biometric management to the SDK.
     * @param {Uint8Array} key
     * @returns {Uint8Array | undefined}
     */
    static get_key_id_for_symmetric_key(key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.cryptoclient_get_key_id_for_symmetric_key(retptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            let v2;
            if (r0 !== 0) {
                v2 = getArrayU8FromWasm0(r0, r1).slice();
                wasm.__wbindgen_free(r0, r1 * 1, 1);
            }
            return v2;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * ⚠️⚠️⚠️ HAZMAT WARNING: DO NOT USE THIS ⚠️⚠️⚠️
     *
     * Get the uses's decrypted encryption key. Note: It's very important
     * to keep this key safe, as it can be used to decrypt all of the user's data. It is
     * only permitted to use for a transition period where side effects such as biometrics
     * and never-lock are set from within the client code.
     * @returns {Promise<B64>}
     */
    get_user_encryption_key() {
        const ret = wasm.cryptoclient_get_user_encryption_key(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Creates a rotated set of account keys for the current state
     * @returns {UserCryptoV2KeysResponse}
     */
    get_v2_rotated_account_keys() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.cryptoclient_get_v2_rotated_account_keys(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Initialization method for the organization crypto. Needs to be called after
     * `initialize_user_crypto` but before any other crypto operations.
     * @param {InitOrgCryptoRequest} req
     * @returns {Promise<void>}
     */
    initialize_org_crypto(req) {
        const ret = wasm.cryptoclient_initialize_org_crypto(this.__wbg_ptr, addHeapObject(req));
        return takeObject(ret);
    }
    /**
     * Initialization method for the user crypto. Needs to be called before any other crypto
     * operations.
     * @param {InitUserCryptoRequest} req
     * @returns {Promise<void>}
     */
    initialize_user_crypto(req) {
        const ret = wasm.cryptoclient_initialize_user_crypto(this.__wbg_ptr, addHeapObject(req));
        return takeObject(ret);
    }
    /**
     * Makes a new signing key pair and signs the public key for the user
     * @returns {UserCryptoV2KeysResponse}
     */
    make_keys_for_user_crypto_v2() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.cryptoclient_make_keys_for_user_crypto_v2(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Create the data necessary to update the user's kdf settings. The user's encryption key is
     * re-encrypted for the password under the new kdf settings. This returns the re-encrypted
     * user key and the new password hash but does not update sdk state.
     *
     * Note: This is deprecated. Please use the user-crypto-management client instead.
     * @param {string} password
     * @param {Kdf} kdf
     * @returns {Promise<UpdateKdfResponse>}
     */
    make_update_kdf(password, kdf) {
        const ptr0 = passStringToWasm0(password, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.cryptoclient_make_update_kdf(this.__wbg_ptr, ptr0, len0, addHeapObject(kdf));
        return takeObject(ret);
    }
    /**
     * Decrypts a `PasswordProtectedKeyEnvelope`, returning the user key, if successful.
     * This is a stop-gap solution, until initialization of the SDK is used.
     * @param {string} pin
     * @param {string} envelope
     * @returns {Uint8Array}
     */
    unseal_password_protected_key_envelope(pin, envelope) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(pin, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(envelope, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.cryptoclient_unseal_password_protected_key_envelope(retptr, this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
}
if (Symbol.dispose) CryptoClient.prototype[Symbol.dispose] = CryptoClient.prototype.free;
exports.CryptoClient = CryptoClient;

/**
 * Client for the key management work that runs on every sync.
 */
class CryptoSyncHandlerClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CryptoSyncHandlerClient.prototype);
        obj.__wbg_ptr = ptr;
        CryptoSyncHandlerClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CryptoSyncHandlerClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_cryptosynchandlerclient_free(ptr, 0);
    }
    /**
     * Runs the key management sync work. Call this after each sync, once the user's cryptographic
     * state has been applied.
     * @param {CryptoSyncData} data
     * @returns {Promise<void>}
     */
    on_sync(data) {
        const ret = wasm.cryptosynchandlerclient_on_sync(this.__wbg_ptr, addHeapObject(data));
        return takeObject(ret);
    }
}
if (Symbol.dispose) CryptoSyncHandlerClient.prototype[Symbol.dispose] = CryptoSyncHandlerClient.prototype.free;
exports.CryptoSyncHandlerClient = CryptoSyncHandlerClient;

class ExporterClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ExporterClient.prototype);
        obj.__wbg_ptr = ptr;
        ExporterClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ExporterClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_exporterclient_free(ptr, 0);
    }
    /**
     * Credential Exchange Format (CXF)
     *
     * *Warning:* Expect this API to be unstable, and it will change in the future.
     *
     * For use with Apple using [ASCredentialExportManager](https://developer.apple.com/documentation/authenticationservices/ascredentialexportmanager).
     * Ideally, the input should be immediately serialized from [ASImportableAccount](https://developer.apple.com/documentation/authenticationservices/asimportableaccount).
     * @param {Account} account
     * @param {Cipher[]} ciphers
     * @returns {string}
     */
    export_cxf(account, ciphers) {
        let deferred3_0;
        let deferred3_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArrayJsValueToWasm0(ciphers, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.exporterclient_export_cxf(retptr, this.__wbg_ptr, addHeapObject(account), ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr2 = r0;
            var len2 = r1;
            if (r3) {
                ptr2 = 0; len2 = 0;
                throw takeObject(r2);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * @param {Collection[]} collections
     * @param {Cipher[]} ciphers
     * @param {ExportFormat} format
     * @returns {string}
     */
    export_organization_vault(collections, ciphers, format) {
        let deferred4_0;
        let deferred4_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArrayJsValueToWasm0(collections, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArrayJsValueToWasm0(ciphers, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.exporterclient_export_organization_vault(retptr, this.__wbg_ptr, ptr0, len0, ptr1, len1, addHeapObject(format));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr3 = r0;
            var len3 = r1;
            if (r3) {
                ptr3 = 0; len3 = 0;
                throw takeObject(r2);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * @param {Folder[]} folders
     * @param {Cipher[]} ciphers
     * @param {ExportFormat} format
     * @returns {Promise<string>}
     */
    export_vault(folders, ciphers, format) {
        const ptr0 = passArrayJsValueToWasm0(folders, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(ciphers, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.exporterclient_export_vault(this.__wbg_ptr, ptr0, len0, ptr1, len1, addHeapObject(format));
        return takeObject(ret);
    }
    /**
     * Credential Exchange Format (CXF)
     *
     * *Warning:* Expect this API to be unstable, and it will change in the future.
     *
     * For use with Apple using [ASCredentialExportManager](https://developer.apple.com/documentation/authenticationservices/ascredentialexportmanager).
     * Ideally, the input should be immediately serialized from [ASImportableAccount](https://developer.apple.com/documentation/authenticationservices/asimportableaccount).
     *
     * Each returned [`EncryptionContext`] carries the encrypted cipher along with the user it was
     * encrypted for and the id of the key it was wrapped under.
     * @param {string} payload
     * @returns {EncryptionContext[]}
     */
    import_cxf(payload) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(payload, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.exporterclient_import_cxf(retptr, this.__wbg_ptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v2 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v2;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
}
if (Symbol.dispose) ExporterClient.prototype[Symbol.dispose] = ExporterClient.prototype.free;
exports.ExporterClient = ExporterClient;

/**
 * Represents the type of a [FieldView].
 * @enum {0 | 1 | 2 | 3}
 */
const FieldType = Object.freeze({
    /**
     * Text field
     */
    Text: 0, "0": "Text",
    /**
     * Hidden text field
     */
    Hidden: 1, "1": "Hidden",
    /**
     * Boolean field
     */
    Boolean: 2, "2": "Boolean",
    /**
     * Linked field
     */
    Linked: 3, "3": "Linked",
});
exports.FieldType = FieldType;

/**
 * Where the client should upload the encrypted file bytes after [`SendClient::create_file_send`].
 * @enum {0 | 1}
 */
const FileUploadType = Object.freeze({
    /**
     * Upload directly to the Bitwarden server via `POST /sends/{id}/file/{file_id}`.
     */
    Direct: 0, "0": "Direct",
    /**
     * Upload to an Azure Blob Storage pre-signed URL.
     */
    Azure: 1, "1": "Azure",
});
exports.FileUploadType = FileUploadType;

/**
 * A client for inspecting and refreshing feature flags.
 */
class FlagsClient {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FlagsClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_flagsclient_free(ptr, 0);
    }
}
if (Symbol.dispose) FlagsClient.prototype[Symbol.dispose] = FlagsClient.prototype.free;
exports.FlagsClient = FlagsClient;

/**
 * WASM client for reading Flight Recorder logs.
 *
 * The underlying buffer is global (initialized in [`init_sdk`](crate::init_sdk)),
 * so this client is a stateless handle for WASM access.
 */
class FlightRecorderClient {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FlightRecorderClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_flightrecorderclient_free(ptr, 0);
    }
    /**
     * Get the current event count without reading event contents.
     * @returns {number}
     */
    count() {
        const ret = wasm.flightrecorderclient_count(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Create a new `FlightRecorderClient`.
     */
    constructor() {
        const ret = wasm.flightrecorderclient_new();
        this.__wbg_ptr = ret >>> 0;
        FlightRecorderClientFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Read all events currently in the Flight Recorder buffer.
     * @returns {FlightRecorderEvent[]}
     */
    read() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.flightrecorderclient_read(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var v1 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Ingest a single TypeScript-originated log event into the global buffer,
     * honoring the configured level floor.
     *
     * `timestamp` is milliseconds since the Unix epoch, supplied by the caller
     * (`Date.now()`).
     * @param {number} timestamp
     * @param {LogLevel} level
     * @param {string} target
     * @param {string} message
     */
    write(timestamp, level, target, message) {
        const ptr0 = passStringToWasm0(target, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(message, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        wasm.flightrecorderclient_write(this.__wbg_ptr, timestamp, level, ptr0, len0, ptr1, len1);
    }
}
if (Symbol.dispose) FlightRecorderClient.prototype[Symbol.dispose] = FlightRecorderClient.prototype.free;
exports.FlightRecorderClient = FlightRecorderClient;

/**
 * Wrapper for folder specific functionality.
 */
class FoldersClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(FoldersClient.prototype);
        obj.__wbg_ptr = ptr;
        FoldersClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FoldersClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_foldersclient_free(ptr, 0);
    }
    /**
     * Create a new [Folder] and save it to the server.
     * @param {FolderAddEditRequest} request
     * @returns {Promise<FolderView>}
     */
    create(request) {
        const ret = wasm.foldersclient_create(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Decrypt a [Folder] to [FolderView].
     * @param {Folder} folder
     * @returns {FolderView}
     */
    decrypt(folder) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.foldersclient_decrypt(retptr, this.__wbg_ptr, addHeapObject(folder));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Decrypt a list of [Folder]s to a list of [FolderView]s.
     * @param {Folder[]} folders
     * @returns {FolderView[]}
     */
    decrypt_list(folders) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArrayJsValueToWasm0(folders, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.foldersclient_decrypt_list(retptr, this.__wbg_ptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v2 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v2;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Edit the [Folder] and save it to the server.
     * @param {FolderId} folder_id
     * @param {FolderAddEditRequest} request
     * @returns {Promise<FolderView>}
     */
    edit(folder_id, request) {
        const ret = wasm.foldersclient_edit(this.__wbg_ptr, addHeapObject(folder_id), addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Encrypt a [FolderView] to a [Folder].
     * @param {FolderView} folder_view
     * @returns {Folder}
     */
    encrypt(folder_view) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.foldersclient_encrypt(retptr, this.__wbg_ptr, addHeapObject(folder_view));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Get a specific [crate::Folder] by its ID from state and decrypt it to a [FolderView].
     * @param {FolderId} folder_id
     * @returns {Promise<FolderView>}
     */
    get(folder_id) {
        const ret = wasm.foldersclient_get(this.__wbg_ptr, addHeapObject(folder_id));
        return takeObject(ret);
    }
    /**
     * Get all folders from state and decrypt them to a list of [FolderView].
     * @returns {Promise<FolderView[]>}
     */
    list() {
        const ret = wasm.foldersclient_list(this.__wbg_ptr);
        return takeObject(ret);
    }
}
if (Symbol.dispose) FoldersClient.prototype[Symbol.dispose] = FoldersClient.prototype.free;
exports.FoldersClient = FoldersClient;

class GeneratorClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(GeneratorClient.prototype);
        obj.__wbg_ptr = ptr;
        GeneratorClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GeneratorClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_generatorclient_free(ptr, 0);
    }
    /**
     * Generates a random passphrase.
     * A passphrase is a combination of random words separated by a character.
     * An example of passphrase is `correct horse battery staple`.
     *
     * The number of words and their case, the word separator, and the inclusion of
     * a number in the passphrase can be customized using the `input` parameter.
     *
     * # Examples
     *
     * ```
     * use bitwarden_core::Client;
     * use bitwarden_generators::{GeneratorClientsExt, PassphraseError, PassphraseGeneratorRequest};
     *
     * async fn test() -> Result<(), PassphraseError> {
     *     let input = PassphraseGeneratorRequest {
     *         num_words: 4,
     *         ..Default::default()
     *     };
     *     let passphrase = Client::new(None).generator().passphrase(input).unwrap();
     *     println!("{}", passphrase);
     *     Ok(())
     * }
     * ```
     * @param {PassphraseGeneratorRequest} input
     * @returns {string}
     */
    passphrase(input) {
        let deferred2_0;
        let deferred2_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.generatorclient_passphrase(retptr, this.__wbg_ptr, addHeapObject(input));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr1 = r0;
            var len1 = r1;
            if (r3) {
                ptr1 = 0; len1 = 0;
                throw takeObject(r2);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Generates a random password.
     *
     * The character sets and password length can be customized using the `input` parameter.
     *
     * # Examples
     *
     * ```
     * use bitwarden_core::Client;
     * use bitwarden_generators::{GeneratorClientsExt, PassphraseError, PasswordGeneratorRequest};
     *
     * async fn test() -> Result<(), PassphraseError> {
     *     let input = PasswordGeneratorRequest {
     *         lowercase: true,
     *         uppercase: true,
     *         numbers: true,
     *         length: 20,
     *         ..Default::default()
     *     };
     *     let password = Client::new(None).generator().password(input).unwrap();
     *     println!("{}", password);
     *     Ok(())
     * }
     * ```
     * @param {PasswordGeneratorRequest} input
     * @returns {string}
     */
    password(input) {
        let deferred2_0;
        let deferred2_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.generatorclient_password(retptr, this.__wbg_ptr, addHeapObject(input));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr1 = r0;
            var len1 = r1;
            if (r3) {
                ptr1 = 0; len1 = 0;
                throw takeObject(r2);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Parses an HTML `passwordrules` attribute string into a [`PasswordGeneratorRequest`].
     *
     * The returned request can be passed to [`GeneratorClient::password`] to produce a
     * password that satisfies the website's declared constraints.
     * @param {string} rules
     * @returns {PasswordGeneratorRequest}
     */
    password_rules(rules) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(rules, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.generatorclient_password_rules(retptr, this.__wbg_ptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
}
if (Symbol.dispose) GeneratorClient.prototype[Symbol.dispose] = GeneratorClient.prototype.free;
exports.GeneratorClient = GeneratorClient;

/**
 * @enum {400 | 401 | 402 | 403 | 404 | 405 | 406 | 407 | 408 | 409 | 410 | 411 | 412 | 413 | 414 | 415 | 416 | 417 | 418}
 */
const IdentityLinkedIdType = Object.freeze({
    Title: 400, "400": "Title",
    MiddleName: 401, "401": "MiddleName",
    Address1: 402, "402": "Address1",
    Address2: 403, "403": "Address2",
    Address3: 404, "404": "Address3",
    City: 405, "405": "City",
    State: 406, "406": "State",
    PostalCode: 407, "407": "PostalCode",
    Country: 408, "408": "Country",
    Company: 409, "409": "Company",
    Email: 410, "410": "Email",
    Phone: 411, "411": "Phone",
    Ssn: 412, "412": "Ssn",
    Username: 413, "413": "Username",
    PassportNumber: 414, "414": "PassportNumber",
    LicenseNumber: 415, "415": "LicenseNumber",
    FirstName: 416, "416": "FirstName",
    LastName: 417, "417": "LastName",
    FullName: 418, "418": "FullName",
});
exports.IdentityLinkedIdType = IdentityLinkedIdType;

class ImporterClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ImporterClient.prototype);
        obj.__wbg_ptr = ptr;
        ImporterClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ImporterClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_importerclient_free(ptr, 0);
    }
    /**
     * Import a KeePass KDBX (`.kdbx`) database and submit it to the server.
     *
     * Parses and decrypts the raw `.kdbx` bytes (unlocked with the password and/or key file),
     * encrypts the entries for the user's personal vault or the given organization, and submits
     * them to the import endpoint. Returns the counts of what was imported. Inputs larger than
     * 10 MiB are rejected with `KdbxFileTooLarge`.
     * @param {Uint8Array} file
     * @param {string | null | undefined} password
     * @param {Uint8Array | null | undefined} key_file
     * @param {ImportOptions} options
     * @returns {Promise<ImportSummary>}
     */
    import_kdbx(file, password, key_file, options) {
        const ptr0 = passArray8ToWasm0(file, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(password) ? 0 : passStringToWasm0(password, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(key_file) ? 0 : passArray8ToWasm0(key_file, wasm.__wbindgen_malloc);
        var len2 = WASM_VECTOR_LEN;
        const ret = wasm.importerclient_import_kdbx(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, addHeapObject(options));
        return takeObject(ret);
    }
}
if (Symbol.dispose) ImporterClient.prototype[Symbol.dispose] = ImporterClient.prototype.free;
exports.ImporterClient = ImporterClient;

/**
 * An untyped IPC message received from another endpoint.
 */
class IncomingMessage {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(IncomingMessage.prototype);
        obj.__wbg_ptr = ptr;
        IncomingMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IncomingMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_incomingmessage_free(ptr, 0);
    }
    /**
     * Destination endpoint that received this message.
     * @returns {Endpoint}
     */
    get destination() {
        const ret = wasm.__wbg_get_incomingmessage_destination(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Serialized payload bytes.
     * @returns {Uint8Array}
     */
    get payload() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.__wbg_get_incomingmessage_payload(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var v1 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Source that sent this message, with per-variant metadata.
     * @returns {Source}
     */
    get source() {
        const ret = wasm.__wbg_get_incomingmessage_source(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Optional topic used for routing/dispatch.
     * @returns {string | undefined}
     */
    get topic() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.__wbg_get_incomingmessage_topic(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            let v1;
            if (r0 !== 0) {
                v1 = getStringFromWasm0(r0, r1).slice();
                wasm.__wbindgen_free(r0, r1 * 1, 1);
            }
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Create an incoming IPC message from raw payload bytes.
     * @param {Uint8Array} payload
     * @param {Endpoint} destination
     * @param {Source} source
     * @param {string | null} [topic]
     */
    constructor(payload, destination, source, topic) {
        const ptr0 = passArray8ToWasm0(payload, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(topic) ? 0 : passStringToWasm0(topic, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.incomingmessage_new(ptr0, len0, addHeapObject(destination), addHeapObject(source), ptr1, len1);
        this.__wbg_ptr = ret >>> 0;
        IncomingMessageFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Try to parse the payload as JSON.
     * @returns {any} The parsed JSON value, or undefined if the payload is not valid JSON.
     */
    parse_payload_as_json() {
        const ret = wasm.incomingmessage_parse_payload_as_json(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Destination endpoint that received this message.
     * @param {Endpoint} arg0
     */
    set destination(arg0) {
        wasm.__wbg_set_incomingmessage_destination(this.__wbg_ptr, addHeapObject(arg0));
    }
    /**
     * Serialized payload bytes.
     * @param {Uint8Array} arg0
     */
    set payload(arg0) {
        const ptr0 = passArray8ToWasm0(arg0, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_incomingmessage_payload(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * Source that sent this message, with per-variant metadata.
     * @param {Source} arg0
     */
    set source(arg0) {
        wasm.__wbg_set_incomingmessage_source(this.__wbg_ptr, addHeapObject(arg0));
    }
    /**
     * Optional topic used for routing/dispatch.
     * @param {string | null} [arg0]
     */
    set topic(arg0) {
        var ptr0 = isLikeNone(arg0) ? 0 : passStringToWasm0(arg0, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_incomingmessage_topic(this.__wbg_ptr, ptr0, len0);
    }
}
if (Symbol.dispose) IncomingMessage.prototype[Symbol.dispose] = IncomingMessage.prototype.free;
exports.IncomingMessage = IncomingMessage;

class IntoUnderlyingByteSource {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingByteSourceFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingbytesource_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get autoAllocateChunkSize() {
        const ret = wasm.intounderlyingbytesource_autoAllocateChunkSize(this.__wbg_ptr);
        return ret >>> 0;
    }
    cancel() {
        const ptr = this.__destroy_into_raw();
        wasm.intounderlyingbytesource_cancel(ptr);
    }
    /**
     * @param {ReadableByteStreamController} controller
     * @returns {Promise<any>}
     */
    pull(controller) {
        const ret = wasm.intounderlyingbytesource_pull(this.__wbg_ptr, addHeapObject(controller));
        return takeObject(ret);
    }
    /**
     * @param {ReadableByteStreamController} controller
     */
    start(controller) {
        wasm.intounderlyingbytesource_start(this.__wbg_ptr, addHeapObject(controller));
    }
    /**
     * @returns {ReadableStreamType}
     */
    get type() {
        const ret = wasm.intounderlyingbytesource_type(this.__wbg_ptr);
        return __wbindgen_enum_ReadableStreamType[ret];
    }
}
if (Symbol.dispose) IntoUnderlyingByteSource.prototype[Symbol.dispose] = IntoUnderlyingByteSource.prototype.free;
exports.IntoUnderlyingByteSource = IntoUnderlyingByteSource;

class IntoUnderlyingSink {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingSinkFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingsink_free(ptr, 0);
    }
    /**
     * @param {any} reason
     * @returns {Promise<any>}
     */
    abort(reason) {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.intounderlyingsink_abort(ptr, addHeapObject(reason));
        return takeObject(ret);
    }
    /**
     * @returns {Promise<any>}
     */
    close() {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.intounderlyingsink_close(ptr);
        return takeObject(ret);
    }
    /**
     * @param {any} chunk
     * @returns {Promise<any>}
     */
    write(chunk) {
        const ret = wasm.intounderlyingsink_write(this.__wbg_ptr, addHeapObject(chunk));
        return takeObject(ret);
    }
}
if (Symbol.dispose) IntoUnderlyingSink.prototype[Symbol.dispose] = IntoUnderlyingSink.prototype.free;
exports.IntoUnderlyingSink = IntoUnderlyingSink;

class IntoUnderlyingSource {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingSourceFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingsource_free(ptr, 0);
    }
    cancel() {
        const ptr = this.__destroy_into_raw();
        wasm.intounderlyingsource_cancel(ptr);
    }
    /**
     * @param {ReadableStreamDefaultController} controller
     * @returns {Promise<any>}
     */
    pull(controller) {
        const ret = wasm.intounderlyingsource_pull(this.__wbg_ptr, addHeapObject(controller));
        return takeObject(ret);
    }
}
if (Symbol.dispose) IntoUnderlyingSource.prototype[Symbol.dispose] = IntoUnderlyingSource.prototype.free;
exports.IntoUnderlyingSource = IntoUnderlyingSource;

/**
 * Client for organization invite link administrative (organization-key) operations: creating,
 * refreshing, updating, deleting, and inspecting invite links, and recovering the invite secret.
 */
class InviteLinkAdminClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(InviteLinkAdminClient.prototype);
        obj.__wbg_ptr = ptr;
        InviteLinkAdminClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        InviteLinkAdminClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_invitelinkadminclient_free(ptr, 0);
    }
    /**
     * Creates a new organization invite link.
     * @param {OrganizationId} organization_id
     * @param {string[]} allowed_domains
     * @param {boolean} supports_confirmation
     * @returns {Promise<OrganizationInviteLinkView>}
     */
    create(organization_id, allowed_domains, supports_confirmation) {
        const ptr0 = passArrayJsValueToWasm0(allowed_domains, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.invitelinkadminclient_create(this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0, supports_confirmation);
        return takeObject(ret);
    }
    /**
     * Creates a new organization invite and posts it to the server, returning the full
     * [`OrganizationInviteLink`] persisted by the server.
     *
     * # Security
     * Only the sealed invite is posted to the server; the invite secret is never sent. Use
     * [`InviteLinkAdminClient::get_invite_secret`] to recover the secret needed to reconstruct the
     * invite link.
     * @param {OrganizationId} organization_id
     * @param {string[]} allowed_domains
     * @param {boolean} supports_confirmation
     * @returns {Promise<OrganizationInviteLink>}
     */
    create_invite_link(organization_id, allowed_domains, supports_confirmation) {
        const ptr0 = passArrayJsValueToWasm0(allowed_domains, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.invitelinkadminclient_create_invite_link(this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0, supports_confirmation);
        return takeObject(ret);
    }
    /**
     * Delete an existing invite link.
     * @param {OrganizationId} organization_id
     * @returns {Promise<void>}
     */
    delete(organization_id) {
        const ret = wasm.invitelinkadminclient_delete(this.__wbg_ptr, addHeapObject(organization_id));
        return takeObject(ret);
    }
    /**
     * Get an existing invite link.
     * @param {OrganizationId} organization_id
     * @returns {Promise<OrganizationInviteLinkView | undefined>}
     */
    get(organization_id) {
        const ret = wasm.invitelinkadminclient_get(this.__wbg_ptr, addHeapObject(organization_id));
        return takeObject(ret);
    }
    /**
     * Using the organization key, recovers the [`InviteSecret`] from the invite carried in the
     * given [`OrganizationInviteLink`] so an admin can reconstruct the invite link.
     * @param {OrganizationId} organization_id
     * @param {string} invite
     * @returns {InviteSecret}
     */
    get_invite_secret(organization_id, invite) {
        let deferred3_0;
        let deferred3_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(invite, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.invitelinkadminclient_get_invite_secret(retptr, this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr2 = r0;
            var len2 = r1;
            if (r3) {
                ptr2 = 0; len2 = 0;
                throw takeObject(r2);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Refreshes an existing invite link.
     * @param {OrganizationId} organization_id
     * @param {boolean} supports_confirmation
     * @returns {Promise<OrganizationInviteLinkView>}
     */
    refresh(organization_id, supports_confirmation) {
        const ret = wasm.invitelinkadminclient_refresh(this.__wbg_ptr, addHeapObject(organization_id), supports_confirmation);
        return takeObject(ret);
    }
    /**
     * Refresh an existing invite link.
     * This generates a new code and secret.
     * @param {OrganizationId} organization_id
     * @param {boolean} supports_confirmation
     * @returns {Promise<OrganizationInviteLink>}
     */
    refresh_invite_link(organization_id, supports_confirmation) {
        const ret = wasm.invitelinkadminclient_refresh_invite_link(this.__wbg_ptr, addHeapObject(organization_id), supports_confirmation);
        return takeObject(ret);
    }
    /**
     * Updates whether an existing invite link supports confirmation, re-sealing the given invite
     * accordingly and persisting it to the server.
     *
     * Enabling confirmation re-seals the organization key under the invite's existing invite key;
     * disabling it strips that envelope. Either way the invite key, code, and secret are left
     * untouched, so links already handed out stay valid. Use
     * [`InviteLinkAdminClient::refresh`] instead when the code and secret must be rotated.
     *
     * # Security
     * Only the re-sealed invite is posted to the server; the invite secret is never sent.
     * @param {OrganizationId} organization_id
     * @param {string} invite
     * @param {boolean} supports_confirmation
     * @returns {Promise<OrganizationInviteLink>}
     */
    set_invite_confirmation(organization_id, invite, supports_confirmation) {
        const ptr0 = passStringToWasm0(invite, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.invitelinkadminclient_set_invite_confirmation(this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0, supports_confirmation);
        return takeObject(ret);
    }
    /**
     * Updates the allowed domains for an existing organization invite link.
     * @param {OrganizationId} organization_id
     * @param {string[]} allowed_domains
     * @returns {Promise<OrganizationInviteLinkView>}
     */
    update_allowed_domains(organization_id, allowed_domains) {
        const ptr0 = passArrayJsValueToWasm0(allowed_domains, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.invitelinkadminclient_update_allowed_domains(this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Updates whether an existing invite link supports confirmation.
     *
     * If supports_confirmation is true, users gain immediate access to the organization.
     * If supports_confirmation is false, admins need to confirm all new users.
     *
     * Does not break the URL of the existing invite link.
     * @param {OrganizationId} organization_id
     * @param {boolean} supports_confirmation
     * @returns {Promise<OrganizationInviteLinkView>}
     */
    update_confirmation(organization_id, supports_confirmation) {
        const ret = wasm.invitelinkadminclient_update_confirmation(this.__wbg_ptr, addHeapObject(organization_id), supports_confirmation);
        return takeObject(ret);
    }
}
if (Symbol.dispose) InviteLinkAdminClient.prototype[Symbol.dispose] = InviteLinkAdminClient.prototype.free;
exports.InviteLinkAdminClient = InviteLinkAdminClient;

/**
 * Client for organization invite link operations.
 *
 * This is a thin entry point that exposes two focused sub-clients: [`InviteLinkAdminClient`] (via
 * [`admin`](Self::admin)) for administrator CRUD operations, and [`InviteLinkUserClient`] (via
 * [`user`](Self::user)) for invitee flows. The other methods on this type are deprecated redirects
 * kept for backwards compatibility.
 */
class InviteLinkClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(InviteLinkClient.prototype);
        obj.__wbg_ptr = ptr;
        InviteLinkClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        InviteLinkClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_invitelinkclient_free(ptr, 0);
    }
    /**
     * Accepts an organization invite for the current user, optionally enrolling into account
     * recovery (when `enroll_into_account_recovery` is set) and — when the invite supports
     * confirmation — self-confirming.
     * @param {OrganizationId} organization_id
     * @param {string} code
     * @param {string} invite_secret
     * @param {string} default_collection_name
     * @param {boolean} enroll_into_account_recovery
     * @returns {Promise<void>}
     */
    accept_and_optionally_confirm(organization_id, code, invite_secret, default_collection_name, enroll_into_account_recovery) {
        const ptr0 = passStringToWasm0(code, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(invite_secret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(default_collection_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.invitelinkclient_accept_and_optionally_confirm(this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0, ptr1, len1, ptr2, len2, enroll_into_account_recovery);
        return takeObject(ret);
    }
    /**
     * Administrative (organization-key) invite link operations.
     * @returns {InviteLinkAdminClient}
     */
    admin() {
        const ret = wasm.invitelinkclient_admin(this.__wbg_ptr);
        return InviteLinkAdminClient.__wrap(ret);
    }
    /**
     * Creates a new organization invite and posts it to the server.
     * @param {OrganizationId} organization_id
     * @param {string[]} allowed_domains
     * @param {boolean} supports_confirmation
     * @returns {Promise<OrganizationInviteLink>}
     */
    create_invite_link(organization_id, allowed_domains, supports_confirmation) {
        const ptr0 = passArrayJsValueToWasm0(allowed_domains, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.invitelinkclient_create_invite_link(this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0, supports_confirmation);
        return takeObject(ret);
    }
    /**
     * Using the organization key, recovers the [`InviteSecret`] from the invite carried in the
     * given [`OrganizationInviteLink`] so an admin can reconstruct the invite link.
     * @param {OrganizationId} organization_id
     * @param {string} invite
     * @returns {InviteSecret}
     */
    get_invite_secret(organization_id, invite) {
        let deferred3_0;
        let deferred3_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(invite, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.invitelinkclient_get_invite_secret(retptr, this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr2 = r0;
            var len2 = r1;
            if (r3) {
                ptr2 = 0; len2 = 0;
                throw takeObject(r2);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Refresh an existing invite link.
     * This generates a new code and secret.
     * @param {OrganizationId} organization_id
     * @param {boolean} supports_confirmation
     * @returns {Promise<OrganizationInviteLink>}
     */
    refresh_invite_link(organization_id, supports_confirmation) {
        const ret = wasm.invitelinkclient_refresh_invite_link(this.__wbg_ptr, addHeapObject(organization_id), supports_confirmation);
        return takeObject(ret);
    }
    /**
     * Updates whether an existing invite link supports confirmation, re-sealing the given invite
     * accordingly and persisting it to the server.
     * @param {OrganizationId} organization_id
     * @param {string} invite
     * @param {boolean} supports_confirmation
     * @returns {Promise<OrganizationInviteLink>}
     */
    set_invite_confirmation(organization_id, invite, supports_confirmation) {
        const ptr0 = passStringToWasm0(invite, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.invitelinkclient_set_invite_confirmation(this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0, supports_confirmation);
        return takeObject(ret);
    }
    /**
     * Invitee (user) invite link operations.
     * @returns {InviteLinkUserClient}
     */
    user() {
        const ret = wasm.invitelinkclient_user(this.__wbg_ptr);
        return InviteLinkUserClient.__wrap(ret);
    }
}
if (Symbol.dispose) InviteLinkClient.prototype[Symbol.dispose] = InviteLinkClient.prototype.free;
exports.InviteLinkClient = InviteLinkClient;

/**
 * Client for organization invite link invitee (user) operations: checking link status, validating
 * email eligibility, and accepting or self-confirming an invite.
 */
class InviteLinkUserClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(InviteLinkUserClient.prototype);
        obj.__wbg_ptr = ptr;
        InviteLinkUserClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        InviteLinkUserClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_invitelinkuserclient_free(ptr, 0);
    }
    /**
     * Accepts an organization invite for the current user, optionally enrolling into account
     * recovery (when `enroll_into_account_recovery` is set) and — when the invite supports
     * confirmation — self-confirming.
     * @param {OrganizationId} organization_id
     * @param {string} code
     * @param {string} invite_secret
     * @param {string} default_collection_name
     * @param {boolean} enroll_into_account_recovery
     * @returns {Promise<void>}
     */
    accept_and_optionally_confirm(organization_id, code, invite_secret, default_collection_name, enroll_into_account_recovery) {
        const ptr0 = passStringToWasm0(code, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(invite_secret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(default_collection_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.invitelinkuserclient_accept_and_optionally_confirm(this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0, ptr1, len1, ptr2, len2, enroll_into_account_recovery);
        return takeObject(ret);
    }
    /**
     * Retrieves the status of an invite link.
     * Used to verify basic availability before attempting to accept.
     * @param {OrganizationId} organization_id
     * @param {string} code
     * @returns {Promise<OrganizationInviteLinkStatusView>}
     */
    get_status(organization_id, code) {
        const ptr0 = passStringToWasm0(code, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.invitelinkuserclient_get_status(this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Returns whether the given email address is in the allowed domains for an invite link.
     * @param {OrganizationId} organization_id
     * @param {string} code
     * @param {string} email
     * @returns {Promise<boolean>}
     */
    is_email_allowed(organization_id, code, email) {
        const ptr0 = passStringToWasm0(code, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(email, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.invitelinkuserclient_is_email_allowed(this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0, ptr1, len1);
        return takeObject(ret);
    }
}
if (Symbol.dispose) InviteLinkUserClient.prototype[Symbol.dispose] = InviteLinkUserClient.prototype.free;
exports.InviteLinkUserClient = InviteLinkUserClient;

/**
 * JavaScript wrapper around the IPC client. For more information, see the
 * [`IpcClient`] trait documentation.
 */
class IpcClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(IpcClient.prototype);
        obj.__wbg_ptr = ptr;
        IpcClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IpcClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_ipcclient_free(ptr, 0);
    }
    /**
     * @returns {boolean}
     */
    isRunning() {
        const ret = wasm.ipcclient_isRunning(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Create a new `IpcClient` instance with a client-managed session repository for saving
     * sessions using State Provider.
     * @param {IpcCommunicationBackend} communication_provider
     * @param {IpcSessionRepository} session_repository
     * @returns {IpcClient}
     */
    static newWithClientManagedSessions(communication_provider, session_repository) {
        _assertClass(communication_provider, IpcCommunicationBackend);
        const ret = wasm.ipcclient_newWithClientManagedSessions(communication_provider.__wbg_ptr, addHeapObject(session_repository));
        return IpcClient.__wrap(ret);
    }
    /**
     * Create a new `IpcClient` instance with an in-memory session repository for saving
     * sessions within the SDK.
     * @param {IpcCommunicationBackend} communication_provider
     * @returns {IpcClient}
     */
    static newWithSdkInMemorySessions(communication_provider) {
        _assertClass(communication_provider, IpcCommunicationBackend);
        const ret = wasm.ipcclient_newWithSdkInMemorySessions(communication_provider.__wbg_ptr);
        return IpcClient.__wrap(ret);
    }
    /**
     * @param {OutgoingMessage} message
     * @returns {Promise<void>}
     */
    send(message) {
        _assertClass(message, OutgoingMessage);
        var ptr0 = message.__destroy_into_raw();
        const ret = wasm.ipcclient_send(this.__wbg_ptr, ptr0);
        return takeObject(ret);
    }
    /**
     * @param {AbortSignal | null} [abort_signal]
     * @returns {Promise<void>}
     */
    start(abort_signal) {
        const ret = wasm.ipcclient_start(this.__wbg_ptr, isLikeNone(abort_signal) ? 0 : addHeapObject(abort_signal));
        return takeObject(ret);
    }
    /**
     * @returns {Promise<IpcClientSubscription>}
     */
    subscribe() {
        const ret = wasm.ipcclient_subscribe(this.__wbg_ptr);
        return takeObject(ret);
    }
}
if (Symbol.dispose) IpcClient.prototype[Symbol.dispose] = IpcClient.prototype.free;
exports.IpcClient = IpcClient;

/**
 * JavaScript wrapper around the IPC client subscription. For more information, see the
 * [IpcClientSubscription](crate::IpcClientSubscription) documentation.
 */
class IpcClientSubscription {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(IpcClientSubscription.prototype);
        obj.__wbg_ptr = ptr;
        IpcClientSubscriptionFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IpcClientSubscriptionFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_ipcclientsubscription_free(ptr, 0);
    }
    /**
     * @param {AbortSignal | null} [abort_signal]
     * @returns {Promise<IncomingMessage>}
     */
    receive(abort_signal) {
        const ret = wasm.ipcclientsubscription_receive(this.__wbg_ptr, isLikeNone(abort_signal) ? 0 : addHeapObject(abort_signal));
        return takeObject(ret);
    }
}
if (Symbol.dispose) IpcClientSubscription.prototype[Symbol.dispose] = IpcClientSubscription.prototype.free;
exports.IpcClientSubscription = IpcClientSubscription;

/**
 * JavaScript implementation of the `CommunicationBackend` trait for IPC communication.
 */
class IpcCommunicationBackend {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IpcCommunicationBackendFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_ipccommunicationbackend_free(ptr, 0);
    }
    /**
     * Creates a new instance of the JavaScript communication backend.
     * @param {IpcCommunicationBackendSender} sender
     */
    constructor(sender) {
        const ret = wasm.ipccommunicationbackend_new(addHeapObject(sender));
        this.__wbg_ptr = ret >>> 0;
        IpcCommunicationBackendFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Used by JavaScript to provide an incoming message to the IPC framework.
     * @param {IncomingMessage} message
     */
    receive(message) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            _assertClass(message, IncomingMessage);
            var ptr0 = message.__destroy_into_raw();
            wasm.ipccommunicationbackend_receive(retptr, this.__wbg_ptr, ptr0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            if (r1) {
                throw takeObject(r0);
            }
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
}
if (Symbol.dispose) IpcCommunicationBackend.prototype[Symbol.dispose] = IpcCommunicationBackend.prototype.free;
exports.IpcCommunicationBackend = IpcCommunicationBackend;

/**
 * @enum {0 | 1 | 2 | 3 | 4}
 */
const LogLevel = Object.freeze({
    Trace: 0, "0": "Trace",
    Debug: 1, "1": "Debug",
    Info: 2, "2": "Info",
    Warn: 3, "3": "Warn",
    Error: 4, "4": "Error",
});
exports.LogLevel = LogLevel;

/**
 * Client for authenticating Bitwarden users.
 *
 * Handles unauthenticated operations to obtain access tokens from the Identity API.
 * After successful authentication, use the returned tokens to create an authenticated core client.
 *
 * # Lifecycle
 *
 * 1. Create `LoginClient` via `AuthClient`
 * 2. Call login method
 * 3. Use returned tokens with authenticated core client
 *
 * # Password Login Example
 *
 * ```rust,no_run
 * # use bitwarden_auth::{AuthClient, login::login_via_password::PasswordLoginRequest};
 * # use bitwarden_auth::login::models::{LoginRequest, LoginDeviceRequest, LoginResponse};
 * # use bitwarden_core::{Client, DeviceType};
 * # async fn example(email: String, password: String) -> Result<(), Box<dyn std::error::Error>> {
 * // Create auth client
 * let client = Client::new(None);
 * let auth_client = AuthClient::new(client);
 *
 * // Create login client, sharing the same backing client
 * let login_client = auth_client.login();
 *
 * // Get user's KDF config
 * let prelogin = login_client.get_password_prelogin(email.clone()).await?;
 *
 * // Login with credentials
 * let response = login_client.login_via_password(PasswordLoginRequest {
 *     login_request: LoginRequest {
 *         client_id: "connector".to_string(),
 *         device: LoginDeviceRequest {
 *             device_type: DeviceType::SDK,
 *             device_identifier: "device-id".to_string(),
 *             device_name: "My Device".to_string(),
 *             device_push_token: None,
 *         },
 *     },
 *     email,
 *     password,
 *     prelogin_response: prelogin,
 * }).await?;
 *
 * // Use tokens from response for authenticated requests
 * match response {
 *     LoginResponse::Authenticated(success) => {
 *         let access_token = success.access_token;
 *         // Use access_token for authenticated requests
 *     }
 * }
 * # Ok(())
 * # }
 * ```
 */
class LoginClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(LoginClient.prototype);
        obj.__wbg_ptr = ptr;
        LoginClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        LoginClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_loginclient_free(ptr, 0);
    }
    /**
     * Retrieves the data required before authenticating with a password.
     * This includes the user's KDF configuration needed to properly derive the master key.
     * @param {string} email
     * @returns {Promise<PasswordPreloginResponse>}
     */
    get_password_prelogin(email) {
        const ptr0 = passStringToWasm0(email, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.loginclient_get_password_prelogin(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Authenticates a user via email and master password.
     *
     * Derives the master password hash using KDF settings from prelogin, then sends
     * the authentication request to obtain access tokens and vault keys.
     * @param {PasswordLoginRequest} request
     * @returns {Promise<LoginResponse>}
     */
    login_via_password(request) {
        const ret = wasm.loginclient_login_via_password(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
}
if (Symbol.dispose) LoginClient.prototype[Symbol.dispose] = LoginClient.prototype.free;
exports.LoginClient = LoginClient;

/**
 * @enum {100 | 101}
 */
const LoginLinkedIdType = Object.freeze({
    Username: 100, "100": "Username",
    Password: 101, "101": "Password",
});
exports.LoginLinkedIdType = LoginLinkedIdType;

/**
 * Handle to the host system's Unified Endpoint Management profile.
 *
 * The host application constructs one of these at boot and pushes profiles into it, and hands its
 * [`cell`](ManagedSettingsClient::cell) to
 * [`bitwarden_core::ClientBuilder::with_managed_profile`] so the SDK reads the same profile.
 * Clones share the underlying profile, so an update pushed through one clone is observed by all of
 * them.
 */
class ManagedSettingsClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ManagedSettingsClient.prototype);
        obj.__wbg_ptr = ptr;
        ManagedSettingsClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ManagedSettingsClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_managedsettingsclient_free(ptr, 0);
    }
    /**
     * Raw JSON-encoded value for `key`, if a value is present.
     * @param {string} key
     * @returns {string | undefined}
     */
    get(key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.managedsettingsclient_get(retptr, this.__wbg_ptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            let v2;
            if (r0 !== 0) {
                v2 = getStringFromWasm0(r0, r1).slice();
                wasm.__wbindgen_free(r0, r1 * 1, 1);
            }
            return v2;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Returns `true` if `key` is present in the active profile.
     * @param {string} key
     * @returns {boolean}
     */
    is_managed(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.managedsettingsclient_is_managed(this.__wbg_ptr, ptr0, len0);
        return ret !== 0;
    }
    /**
     * Fresh handle with no active profile. The host should call this once at boot.
     */
    constructor() {
        const ret = wasm.managedsettingsclient_new();
        this.__wbg_ptr = ret >>> 0;
        ManagedSettingsClientFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Replace the active profile. Clear the profile with `None`.
     * @param {ManagementProfile | null} [profile]
     */
    update_profile(profile) {
        wasm.managedsettingsclient_update_profile(this.__wbg_ptr, isLikeNone(profile) ? 0 : addHeapObject(profile));
    }
}
if (Symbol.dispose) ManagedSettingsClient.prototype[Symbol.dispose] = ManagedSettingsClient.prototype.free;
exports.ManagedSettingsClient = ManagedSettingsClient;

/**
 * The method used to decrypt organization member data.
 * @enum {0 | 1 | 2}
 */
const MemberDecryptionType = Object.freeze({
    /**
     * Decryption using the user's master password.
     */
    MasterPassword: 0, "0": "MasterPassword",
    /**
     * Decryption via Key Connector.
     */
    KeyConnector: 1, "1": "KeyConnector",
    /**
     * Decryption via Trusted Device Encryption.
     */
    TrustedDeviceEncryption: 2, "2": "TrustedDeviceEncryption",
});
exports.MemberDecryptionType = MemberDecryptionType;

/**
 * The membership status of a user within an organization.
 * @enum {-1 | 0 | 1 | 2 | 3}
 */
const OrganizationUserStatusType = Object.freeze({
    /**
     * The user's access has been revoked. This may occur at any time from any other status.
     */
    Revoked: -1, "-1": "Revoked",
    /**
     * The user has been invited but has not yet accepted.
     */
    Invited: 0, "0": "Invited",
    /**
     * The user has accepted the invitation but has not yet been confirmed by an admin.
     */
    Accepted: 1, "1": "Accepted",
    /**
     * The user has been confirmed by an admin and has full access.
     */
    Confirmed: 2, "2": "Confirmed",
    /**
     * The user has been staged for provisioning but has not yet been invited.
     */
    Staged: 3, "3": "Staged",
});
exports.OrganizationUserStatusType = OrganizationUserStatusType;

/**
 * The role of a user within an organization.
 * @enum {0 | 1 | 2 | 4}
 */
const OrganizationUserType = Object.freeze({
    /**
     * Full administrative control over the organization.
     */
    Owner: 0, "0": "Owner",
    /**
     * Administrative access with most management capabilities.
     */
    Admin: 1, "1": "Admin",
    /**
     * Standard organization member.
     */
    User: 2, "2": "User",
    /**
     * User with a customized set of permissions as indicated by
     * [`ProfileOrganization::permissions`].
     */
    Custom: 4, "4": "Custom",
});
exports.OrganizationUserType = OrganizationUserType;

/**
 * Client for administering the members of an organization.
 */
class OrganizationUsersManagementClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(OrganizationUsersManagementClient.prototype);
        obj.__wbg_ptr = ptr;
        OrganizationUsersManagementClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        OrganizationUsersManagementClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_organizationusersmanagementclient_free(ptr, 0);
    }
    /**
     * Re-sends the invitation email to the given invited members.
     *
     * Returns an `Err` if the entire request fails. Otherwise returns `Ok` containing success or
     * failure information for each member.
     * @param {OrganizationId} organization_id
     * @param {OrganizationUserId[]} organization_user_ids
     * @returns {Promise<OrganizationUserBulkResponse[]>}
     */
    bulk_reinvite(organization_id, organization_user_ids) {
        const ptr0 = passArrayJsValueToWasm0(organization_user_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.organizationusersmanagementclient_bulk_reinvite(this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Re-sends the invitation email to a single invited member.
     * @param {OrganizationId} organization_id
     * @param {OrganizationUserId} organization_user_id
     * @returns {Promise<void>}
     */
    reinvite(organization_id, organization_user_id) {
        const ret = wasm.organizationusersmanagementclient_reinvite(this.__wbg_ptr, addHeapObject(organization_id), addHeapObject(organization_user_id));
        return takeObject(ret);
    }
    /**
     * Sends invites to the given staged members, promoting them to invited and consuming a seat.
     *
     * Returns an `Err` if the entire request fails. Otherwise returns `Ok` containing success or
     * failure information for each member.
     * @param {OrganizationId} organization_id
     * @param {OrganizationUserId[]} organization_user_ids
     * @returns {Promise<OrganizationUserBulkResponse[]>}
     */
    send_staged_invites(organization_id, organization_user_ids) {
        const ptr0 = passArrayJsValueToWasm0(organization_user_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.organizationusersmanagementclient_send_staged_invites(this.__wbg_ptr, addHeapObject(organization_id), ptr0, len0);
        return takeObject(ret);
    }
}
if (Symbol.dispose) OrganizationUsersManagementClient.prototype[Symbol.dispose] = OrganizationUsersManagementClient.prototype.free;
exports.OrganizationUsersManagementClient = OrganizationUsersManagementClient;

/**
 * An untyped IPC message to be sent to another endpoint.
 */
class OutgoingMessage {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(OutgoingMessage.prototype);
        obj.__wbg_ptr = ptr;
        OutgoingMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        OutgoingMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_outgoingmessage_free(ptr, 0);
    }
    /**
     * Destination endpoint for this message.
     * @returns {Endpoint}
     */
    get destination() {
        const ret = wasm.__wbg_get_outgoingmessage_destination(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Serialized payload bytes.
     * @returns {Uint8Array}
     */
    get payload() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.__wbg_get_outgoingmessage_payload(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var v1 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Optional topic used for routing/dispatch.
     * @returns {string | undefined}
     */
    get topic() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.__wbg_get_outgoingmessage_topic(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            let v1;
            if (r0 !== 0) {
                v1 = getStringFromWasm0(r0, r1).slice();
                wasm.__wbindgen_free(r0, r1 * 1, 1);
            }
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Create an outgoing IPC message from raw payload bytes.
     * @param {Uint8Array} payload
     * @param {Endpoint} destination
     * @param {string | null} [topic]
     */
    constructor(payload, destination, topic) {
        const ptr0 = passArray8ToWasm0(payload, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(topic) ? 0 : passStringToWasm0(topic, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.outgoingmessage_new(ptr0, len0, addHeapObject(destination), ptr1, len1);
        this.__wbg_ptr = ret >>> 0;
        OutgoingMessageFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Create a new message and encode the payload as JSON.
     * @param {any} payload
     * @param {Endpoint} destination
     * @param {string | null} [topic]
     * @returns {OutgoingMessage}
     */
    static new_json_payload(payload, destination, topic) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            var ptr0 = isLikeNone(topic) ? 0 : passStringToWasm0(topic, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len0 = WASM_VECTOR_LEN;
            wasm.outgoingmessage_new_json_payload(retptr, addHeapObject(payload), addHeapObject(destination), ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return OutgoingMessage.__wrap(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Destination endpoint for this message.
     * @param {Endpoint} arg0
     */
    set destination(arg0) {
        wasm.__wbg_set_outgoingmessage_destination(this.__wbg_ptr, addHeapObject(arg0));
    }
    /**
     * Serialized payload bytes.
     * @param {Uint8Array} arg0
     */
    set payload(arg0) {
        const ptr0 = passArray8ToWasm0(arg0, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_outgoingmessage_payload(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * Optional topic used for routing/dispatch.
     * @param {string | null} [arg0]
     */
    set topic(arg0) {
        var ptr0 = isLikeNone(arg0) ? 0 : passStringToWasm0(arg0, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_outgoingmessage_topic(this.__wbg_ptr, ptr0, len0);
    }
}
if (Symbol.dispose) OutgoingMessage.prototype[Symbol.dispose] = OutgoingMessage.prototype.free;
exports.OutgoingMessage = OutgoingMessage;

/**
 * The main entry point for the Bitwarden SDK in WebAssembly environments
 */
class PasswordManagerClient {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PasswordManagerClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_passwordmanagerclient_free(ptr, 0);
    }
    /**
     * Auth related operations.
     * @returns {AuthClient}
     */
    auth() {
        const ret = wasm.passwordmanagerclient_auth(this.__wbg_ptr);
        return AuthClient.__wrap(ret);
    }
    /**
     * Collection related operations.
     *
     * This is registered directly on the top-level client in addition to being nested under
     * [`vault`](Self::vault). Once consumers have migrated to this accessor, the nested one will
     * be removed.
     * @returns {CollectionsClient}
     */
    collections() {
        const ret = wasm.passwordmanagerclient_collections(this.__wbg_ptr);
        return CollectionsClient.__wrap(ret);
    }
    /**
     * Crypto related operations.
     * @returns {CryptoClient}
     */
    crypto() {
        const ret = wasm.passwordmanagerclient_crypto(this.__wbg_ptr);
        return CryptoClient.__wrap(ret);
    }
    /**
     * Crypto cipher suite operations.
     * @returns {CryptoCipherSuiteClient}
     */
    crypto_cipher_suite() {
        const ret = wasm.passwordmanagerclient_crypto_cipher_suite(this.__wbg_ptr);
        return CryptoCipherSuiteClient.__wrap(ret);
    }
    /**
     * Key management operations that run on every sync.
     * @returns {CryptoSyncHandlerClient}
     */
    crypto_sync_handler() {
        const ret = wasm.passwordmanagerclient_crypto_sync_handler(this.__wbg_ptr);
        return CryptoSyncHandlerClient.__wrap(ret);
    }
    /**
     * Test method, echoes back the input
     * @param {string} msg
     * @returns {string}
     */
    echo(msg) {
        let deferred2_0;
        let deferred2_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(msg, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.passwordmanagerclient_echo(retptr, this.__wbg_ptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            deferred2_0 = r0;
            deferred2_1 = r1;
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Exporter related operations.
     * @returns {ExporterClient}
     */
    exporters() {
        const ret = wasm.passwordmanagerclient_exporters(this.__wbg_ptr);
        return ExporterClient.__wrap(ret);
    }
    /**
     * Constructs a specific client for generating passwords and passphrases
     * @returns {GeneratorClient}
     */
    generator() {
        const ret = wasm.passwordmanagerclient_generator(this.__wbg_ptr);
        return GeneratorClient.__wrap(ret);
    }
    /**
     * Whether the client is in Gov Mode.
     * @returns {boolean}
     */
    gov_mode() {
        const ret = wasm.passwordmanagerclient_gov_mode(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Test method, calls http endpoint
     * @param {string} url
     * @returns {Promise<string>}
     */
    http_get(url) {
        const ptr0 = passStringToWasm0(url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.passwordmanagerclient_http_get(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Importer related operations.
     * @returns {ImporterClient}
     */
    importers() {
        const ret = wasm.passwordmanagerclient_importers(this.__wbg_ptr);
        return ImporterClient.__wrap(ret);
    }
    /**
     * Organization invite link operations.
     * @returns {InviteLinkClient}
     */
    invite_link() {
        const ret = wasm.passwordmanagerclient_invite_link(this.__wbg_ptr);
        return InviteLinkClient.__wrap(ret);
    }
    /**
     * Key management state bridge operations.
     * @returns {StateBridgeClient}
     */
    km_state_bridge() {
        const ret = wasm.passwordmanagerclient_km_state_bridge(this.__wbg_ptr);
        return StateBridgeClient.__wrap(ret);
    }
    /**
     * Administrator-enforced settings operations.
     * @returns {ManagedSettingsClient}
     */
    managed_settings() {
        const ret = wasm.passwordmanagerclient_managed_settings(this.__wbg_ptr);
        return ManagedSettingsClient.__wrap(ret);
    }
    /**
     * Initialize a new instance of the SDK client
     *
     * `managed_settings` is the host-owned handle onto the operating system's Unified Endpoint
     * Management profile. The client shares its profile, so profiles pushed after construction
     * are visible here. Pass a fresh `ManagedSettingsClient` where the host has no UEM source.
     * @param {any} token_provider
     * @param {ClientSettings | null | undefined} settings
     * @param {ManagedSettingsClient} managed_settings
     */
    constructor(token_provider, settings, managed_settings) {
        _assertClass(managed_settings, ManagedSettingsClient);
        const ret = wasm.passwordmanagerclient_new(addHeapObject(token_provider), isLikeNone(settings) ? 0 : addHeapObject(settings), managed_settings.__wbg_ptr);
        this.__wbg_ptr = ret >>> 0;
        PasswordManagerClientFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Organization member administration operations.
     * @returns {OrganizationUsersManagementClient}
     */
    organization_users_management() {
        const ret = wasm.passwordmanagerclient_organization_users_management(this.__wbg_ptr);
        return OrganizationUsersManagementClient.__wrap(ret);
    }
    /**
     * Constructs a specific client for platform-specific functionality
     * @returns {PlatformClient}
     */
    platform() {
        const ret = wasm.passwordmanagerclient_platform(this.__wbg_ptr);
        return PlatformClient.__wrap(ret);
    }
    /**
     * Policy related operations.
     * @returns {PolicyClient}
     */
    policies() {
        const ret = wasm.passwordmanagerclient_policies(this.__wbg_ptr);
        return PolicyClient.__wrap(ret);
    }
    /**
     * Send sync handler operations.
     * @returns {SendSyncHandlerClient}
     */
    send_sync_handler() {
        const ret = wasm.passwordmanagerclient_send_sync_handler(this.__wbg_ptr);
        return SendSyncHandlerClient.__wrap(ret);
    }
    /**
     * Send related operations.
     * @returns {SendClient}
     */
    sends() {
        const ret = wasm.passwordmanagerclient_sends(this.__wbg_ptr);
        return SendClient.__wrap(ret);
    }
    /**
     * Test method, always throws an error
     * @param {string} msg
     */
    throw(msg) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(msg, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.passwordmanagerclient_throw(retptr, this.__wbg_ptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            if (r1) {
                throw takeObject(r0);
            }
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * User crypto management related operations.
     * @returns {UserCryptoManagementClient}
     */
    user_crypto_management() {
        const ret = wasm.passwordmanagerclient_user_crypto_management(this.__wbg_ptr);
        return UserCryptoManagementClient.__wrap(ret);
    }
    /**
     * Vault item related operations.
     * @returns {VaultClient}
     */
    vault() {
        const ret = wasm.passwordmanagerclient_vault(this.__wbg_ptr);
        return VaultClient.__wrap(ret);
    }
    /**
     * Returns the current SDK version
     * @returns {string}
     */
    version() {
        let deferred1_0;
        let deferred1_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.passwordmanagerclient_version(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            deferred1_0 = r0;
            deferred1_1 = r1;
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) PasswordManagerClient.prototype[Symbol.dispose] = PasswordManagerClient.prototype.free;
exports.PasswordManagerClient = PasswordManagerClient;

/**
 * Sub-client for configuring PIN unlock behavior.
 */
class PinSettingsClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PinSettingsClient.prototype);
        obj.__wbg_ptr = ptr;
        PinSettingsClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PinSettingsClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pinsettingsclient_free(ptr, 0);
    }
    /**
     * Returns the configured PIN lock type, if a PIN lock is set.
     * @returns {Promise<PinLockType | undefined>}
     */
    get_lock_type() {
        const ret = wasm.pinsettingsclient_get_lock_type(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Returns the currently configured PIN, if available.
     * @returns {Promise<string | undefined>}
     */
    get_pin() {
        const ret = wasm.pinsettingsclient_get_pin(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Returns the current status of PIN unlock
     * @returns {Promise<PinUnlockStatus>}
     */
    get_status() {
        const ret = wasm.pinsettingsclient_get_status(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Sets or updates the account PIN and stores the corresponding unlock state.
     *
     * The `lock_type` determines how PIN unlock behaves for this account.
     * Returns an error when the PIN-protected state cannot be persisted.
     * @param {string} pin
     * @param {PinLockType} lock_type
     * @returns {Promise<void>}
     */
    set_pin(pin, lock_type) {
        const ptr0 = passStringToWasm0(pin, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.pinsettingsclient_set_pin(this.__wbg_ptr, ptr0, len0, addHeapObject(lock_type));
        return takeObject(ret);
    }
    /**
     * Unenrolls from PIN-based unlock
     * @returns {Promise<void>}
     */
    unset_pin() {
        const ret = wasm.pinsettingsclient_unset_pin(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Validates whether `pin` matches the currently configured unlock PIN.
     * @param {string} pin
     * @returns {Promise<boolean>}
     */
    validate_pin(pin) {
        const ptr0 = passStringToWasm0(pin, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.pinsettingsclient_validate_pin(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
}
if (Symbol.dispose) PinSettingsClient.prototype[Symbol.dispose] = PinSettingsClient.prototype.free;
exports.PinSettingsClient = PinSettingsClient;

class PlatformClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PlatformClient.prototype);
        obj.__wbg_ptr = ptr;
        PlatformClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PlatformClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_platformclient_free(ptr, 0);
    }
    /**
     * Load feature flags into the client
     * @param {FeatureFlags} flags
     * @returns {Promise<void>}
     */
    load_flags(flags) {
        const ret = wasm.platformclient_load_flags(this.__wbg_ptr, addHeapObject(flags));
        return takeObject(ret);
    }
    /**
     * @returns {StateClient}
     */
    state() {
        const ret = wasm.platformclient_state(this.__wbg_ptr);
        return StateClient.__wrap(ret);
    }
}
if (Symbol.dispose) PlatformClient.prototype[Symbol.dispose] = PlatformClient.prototype.free;
exports.PlatformClient = PlatformClient;

/**
 * Client for policy domain operations.
 *
 * Obtained via [`PoliciesClientExt::policies`] on a [`Client`].
 */
class PolicyClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PolicyClient.prototype);
        obj.__wbg_ptr = ptr;
        PolicyClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PolicyClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_policyclient_free(ptr, 0);
    }
    /**
     * Filter policies of the given type for the current user.
     * @param {Policy[]} policies
     * @param {OrganizationUserPolicyContext[]} organization_user_policy_contexts
     * @param {PolicyType} policy_type
     * @returns {Policy[]}
     */
    filter_by_type(policies, organization_user_policy_contexts, policy_type) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArrayJsValueToWasm0(policies, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArrayJsValueToWasm0(organization_user_policy_contexts, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.policyclient_filter_by_type(retptr, this.__wbg_ptr, ptr0, len0, ptr1, len1, policy_type);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var v3 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Evaluate enforcement of the given policy type across all organizations,
     * returning type-erased decisions for the FFI boundary.
     *
     * Not yet intended for consumer use: exposed across the FFI boundary for
     * testing and iteration only. Use [`filter_by_type`](Self::filter_by_type) for now.
     * @param {PolicyType} policy_type
     * @param {Policy[]} policies
     * @param {OrganizationUserPolicyContext[]} organization_user_policy_contexts
     * @returns {PolicyDecisionErased[]}
     */
    get_all_enforced(policy_type, policies, organization_user_policy_contexts) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArrayJsValueToWasm0(policies, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArrayJsValueToWasm0(organization_user_policy_contexts, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.policyclient_get_all_enforced(retptr, this.__wbg_ptr, policy_type, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var v3 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Evaluate enforcement of the given policy type for a single organization,
     * returning a type-erased decision for the FFI boundary.
     *
     * Not yet intended for consumer use: exposed across the FFI boundary for
     * testing only. Use [`filter_by_type`](Self::filter_by_type) for now.
     * @param {PolicyType} policy_type
     * @param {OrganizationId} organization_id
     * @param {Policy[]} policies
     * @param {OrganizationUserPolicyContext[]} organization_user_policy_contexts
     * @returns {PolicyDecisionErased}
     */
    get_enforced(policy_type, organization_id, policies, organization_user_policy_contexts) {
        const ptr0 = passArrayJsValueToWasm0(policies, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(organization_user_policy_contexts, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.policyclient_get_enforced(this.__wbg_ptr, policy_type, addHeapObject(organization_id), ptr0, len0, ptr1, len1);
        return takeObject(ret);
    }
}
if (Symbol.dispose) PolicyClient.prototype[Symbol.dispose] = PolicyClient.prototype.free;
exports.PolicyClient = PolicyClient;

/**
 * The type of an organization policy.
 *
 * The integer value matches the server's wire format.
 * @enum {0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22}
 */
const PolicyType = Object.freeze({
    /**
     * Requires members to have two-step login enabled on their account.
     */
    TwoFactorAuthentication: 0, "0": "TwoFactorAuthentication",
    /**
     * Sets minimum requirements for members' master passwords.
     */
    MasterPassword: 1, "1": "MasterPassword",
    /**
     * Sets minimum requirements for the password generator.
     */
    PasswordGenerator: 2, "2": "PasswordGenerator",
    /**
     * Restricts members to being part of a single organization.
     */
    SingleOrg: 3, "3": "SingleOrg",
    /**
     * Requires members to authenticate with single sign-on.
     */
    RequireSso: 4, "4": "RequireSso",
    /**
     * Forces newly added or cloned items to be owned by the organization rather than the
     * member's personal vault. Also enables My Items functionality.
     */
    OrganizationDataOwnership: 5, "5": "OrganizationDataOwnership",
    /**
     * Disables the ability to create and edit Bitwarden Sends.
     *
     * Superseded by [`SendControls`](Self::SendControls) when the
     * `pm-31885-send-controls` feature flag is active.
     */
    DisableSend: 6, "6": "DisableSend",
    /**
     * Sets restrictions or defaults for Bitwarden Sends.
     *
     * Superseded by [`SendControls`](Self::SendControls) when the
     * `pm-31885-send-controls` feature flag is active.
     */
    SendOptions: 7, "7": "SendOptions",
    /**
     * Allows administrators to recover member accounts.
     */
    ResetPassword: 8, "8": "ResetPassword",
    /**
     * Sets the maximum allowed vault timeout for members.
     */
    MaximumVaultTimeout: 9, "9": "MaximumVaultTimeout",
    /**
     * Disables members' ability to export their personal vault.
     */
    DisablePersonalVaultExport: 10, "10": "DisablePersonalVaultExport",
    /**
     * Activates autofill on page load in the browser extension.
     */
    ActivateAutofill: 11, "11": "ActivateAutofill",
    /**
     * Automatically logs members into apps using single sign-on.
     */
    AutomaticAppLogIn: 12, "12": "AutomaticAppLogIn",
    /**
     * Removes members' access to the free Bitwarden Families sponsorship benefit.
     */
    FreeFamiliesSponsorship: 13, "13": "FreeFamiliesSponsorship",
    /**
     * Prevents members from unlocking the app with a PIN.
     */
    RemoveUnlockWithPin: 14, "14": "RemoveUnlockWithPin",
    /**
     * Restricts the item types that members can create.
     */
    RestrictedItemTypes: 15, "15": "RestrictedItemTypes",
    /**
     * Sets the default URI match detection strategy for autofill.
     */
    UriMatchDefaults: 16, "16": "UriMatchDefaults",
    /**
     * Sets the default behavior for the autotype feature.
     */
    AutotypeDefaultSetting: 17, "17": "AutotypeDefaultSetting",
    /**
     * Automatically confirms invited users into the organization.
     */
    AutomaticUserConfirmation: 18, "18": "AutomaticUserConfirmation",
    /**
     * Blocks account creation for users with email addresses on claimed domains.
     */
    BlockClaimedDomainAccountCreation: 19, "19": "BlockClaimedDomainAccountCreation",
    /**
     * Displays an organization-configured banner message to members in their vault.
     */
    OrganizationUserNotification: 20, "20": "OrganizationUserNotification",
    /**
     * Configures Send-related behavior: disabling Sends, email visibility, access controls,
     * Send types, and deletion.
     *
     * Supersedes [`DisableSend`](Self::DisableSend) and [`SendOptions`](Self::SendOptions) when
     * the `pm-31885-send-controls` feature flag is active on the server.
     */
    SendControls: 21, "21": "SendControls",
    /**
     * Enables the Fill Assist targeting-rules autofill engine as the default for members who
     * have not explicitly set their Fill Assist preference, and optionally overrides the default
     * rules feed URL.
     */
    FillAssist: 22, "22": "FillAssist",
});
exports.PolicyType = PolicyType;

/**
 * The subscription tier of an organization.
 * @enum {0 | 1 | 2 | 3 | 4}
 */
const ProductTierType = Object.freeze({
    /**
     * Free tier with limited features.
     */
    Free: 0, "0": "Free",
    /**
     * Families plan for personal use.
     */
    Families: 1, "1": "Families",
    /**
     * Teams plan for small organizations.
     */
    Teams: 2, "2": "Teams",
    /**
     * Enterprise plan with full features.
     */
    Enterprise: 3, "3": "Enterprise",
    /**
     * Starter tier for small teams.
     */
    TeamsStarter: 4, "4": "TeamsStarter",
});
exports.ProductTierType = ProductTierType;

/**
 * The type of provider.
 * @enum {0 | 1 | 2}
 */
const ProviderType = Object.freeze({
    /**
     * Managed Service Provider - sells and manages its clients' Bitwarden organizations.
     */
    Msp: 0, "0": "Msp",
    /**
     * Reseller partner - sells Bitwarden to its clients but does not have any administrative
     * access.
     */
    Reseller: 1, "1": "Reseller",
    /**
     * Business unit provider - used to manage multiple organizations which form part of a single
     * large enterprise.
     */
    BusinessUnit: 2, "2": "BusinessUnit",
});
exports.ProviderType = ProviderType;

/**
 * This module represents a stopgap solution to provide access to primitive crypto functions for JS
 * clients. It is not intended to be used outside of the JS clients and this pattern should not be
 * proliferated. It is necessary because we want to use SDK crypto prior to the SDK being fully
 * responsible for state and keys.
 */
class PureCrypto {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PureCryptoFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_purecrypto_free(ptr, 0);
    }
    /**
     * Decapsulates (decrypts) a symmetric key using an decapsulation-key/private-key in PKCS8
     * DER format. Note: This is unsigned, so the sender's authenticity cannot be verified by the
     * recipient.
     * @param {string} encapsulated_key
     * @param {Uint8Array} decapsulation_key
     * @returns {Uint8Array}
     */
    static decapsulate_key_unsigned(encapsulated_key, decapsulation_key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(encapsulated_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(decapsulation_key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_decapsulate_key_unsigned(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * @param {string} encrypted_user_key
     * @param {Uint8Array} master_key
     * @returns {Uint8Array}
     */
    static decrypt_user_key_with_master_key(encrypted_user_key, master_key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(encrypted_user_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(master_key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_decrypt_user_key_with_master_key(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * @param {string} encrypted_user_key
     * @param {string} master_password
     * @param {string} email
     * @param {Kdf} kdf
     * @returns {Uint8Array}
     */
    static decrypt_user_key_with_master_password(encrypted_user_key, master_password, email, kdf) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(encrypted_user_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(master_password, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(email, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            wasm.purecrypto_decrypt_user_key_with_master_password(retptr, ptr0, len0, ptr1, len1, ptr2, len2, addHeapObject(kdf));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v4 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v4;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Derive output of the KDF for a [bitwarden_crypto::Kdf] configuration.
     * @param {Uint8Array} password
     * @param {Uint8Array} salt
     * @param {Kdf} kdf
     * @returns {Uint8Array}
     */
    static derive_kdf_material(password, salt, kdf) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(password, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(salt, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_derive_kdf_material(retptr, ptr0, len0, ptr1, len1, addHeapObject(kdf));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Encapsulates (encrypts) a symmetric key using an public-key/encapsulation-key
     * in SPKI format, returning the encapsulated key as a string. Note: This is unsigned, so
     * the sender's authenticity cannot be verified by the recipient.
     * @param {Uint8Array} shared_key
     * @param {Uint8Array} encapsulation_key
     * @returns {string}
     */
    static encapsulate_key_unsigned(shared_key, encapsulation_key) {
        let deferred4_0;
        let deferred4_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(shared_key, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(encapsulation_key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_encapsulate_key_unsigned(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr3 = r0;
            var len3 = r1;
            if (r3) {
                ptr3 = 0; len3 = 0;
                throw takeObject(r2);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * @param {Uint8Array} user_key
     * @param {string} master_password
     * @param {string} email
     * @param {Kdf} kdf
     * @returns {string}
     */
    static encrypt_user_key_with_master_password(user_key, master_password, email, kdf) {
        let deferred5_0;
        let deferred5_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(user_key, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(master_password, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ptr2 = passStringToWasm0(email, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len2 = WASM_VECTOR_LEN;
            wasm.purecrypto_encrypt_user_key_with_master_password(retptr, ptr0, len0, ptr1, len1, ptr2, len2, addHeapObject(kdf));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr4 = r0;
            var len4 = r1;
            if (r3) {
                ptr4 = 0; len4 = 0;
                throw takeObject(r2);
            }
            deferred5_0 = ptr4;
            deferred5_1 = len4;
            return getStringFromWasm0(ptr4, len4);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
        }
    }
    /**
     * Returns the algorithm used for the given verifying key.
     * @param {Uint8Array} verifying_key
     * @returns {SignatureAlgorithm}
     */
    static key_algorithm_for_verifying_key(verifying_key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(verifying_key, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.purecrypto_key_algorithm_for_verifying_key(retptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * @returns {SymmetricKey}
     */
    static make_aes256_cbc_hmac_key() {
        let deferred1_0;
        let deferred1_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.purecrypto_make_aes256_cbc_hmac_key(retptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            deferred1_0 = r0;
            deferred1_1 = r1;
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {Uint8Array}
     */
    static make_user_key_aes256_cbc_hmac() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.purecrypto_make_user_key_aes256_cbc_hmac(retptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var v1 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * @returns {Uint8Array}
     */
    static make_user_key_xchacha20_poly1305() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.purecrypto_make_user_key_xchacha20_poly1305(retptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var v1 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Generates a new v4 UUID using a cryptographically secure random number generator
     * @returns {string}
     */
    static new_guid() {
        let deferred1_0;
        let deferred1_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.purecrypto_new_guid(retptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            deferred1_0 = r0;
            deferred1_1 = r1;
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Generates a cryptographically secure random number between the given min and max
     * (inclusive).
     * @param {number} min
     * @param {number} max
     * @returns {number}
     */
    static random_number(min, max) {
        const ret = wasm.purecrypto_random_number(min, max);
        return ret >>> 0;
    }
    /**
     * Decrypts data using RSAES-OAEP with SHA-1
     * HAZMAT WARNING: Do not use outside of implementing cryptofunctionservice
     * @param {Uint8Array} encrypted_data
     * @param {Uint8Array} private_key
     * @returns {Uint8Array}
     */
    static rsa_decrypt_data(encrypted_data, private_key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(encrypted_data, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(private_key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_rsa_decrypt_data(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Encrypts data using RSAES-OAEP with SHA-1
     * HAZMAT WARNING: Do not use outside of implementing cryptofunctionservice
     * @param {Uint8Array} plain_data
     * @param {Uint8Array} public_key
     * @returns {Uint8Array}
     */
    static rsa_encrypt_data(plain_data, public_key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(plain_data, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(public_key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_rsa_encrypt_data(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Given a decrypted private RSA key PKCS8 DER this
     * returns the corresponding public RSA key in DER format.
     * HAZMAT WARNING: Do not use outside of implementing cryptofunctionservice
     * @param {Uint8Array} private_key
     * @returns {Uint8Array}
     */
    static rsa_extract_public_key(private_key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(private_key, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.purecrypto_rsa_extract_public_key(retptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v2 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v2;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Generates a new RSA key pair and returns the private key
     * HAZMAT WARNING: Do not use outside of implementing cryptofunctionservice
     * @returns {Uint8Array}
     */
    static rsa_generate_keypair() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.purecrypto_rsa_generate_keypair(retptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v1 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * DEPRECATED: Use `symmetric_decrypt_string` instead.
     * Cleanup ticket: <https://bitwarden.atlassian.net/browse/PM-21247>
     * @param {string} enc_string
     * @param {Uint8Array} key
     * @returns {string}
     */
    static symmetric_decrypt(enc_string, key) {
        let deferred4_0;
        let deferred4_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(enc_string, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_symmetric_decrypt(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr3 = r0;
            var len3 = r1;
            if (r3) {
                ptr3 = 0; len3 = 0;
                throw takeObject(r2);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * DEPRECATED: Use `symmetric_decrypt_filedata` instead.
     * Cleanup ticket: <https://bitwarden.atlassian.net/browse/PM-21247>
     * @param {Uint8Array} enc_bytes
     * @param {Uint8Array} key
     * @returns {Uint8Array}
     */
    static symmetric_decrypt_array_buffer(enc_bytes, key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(enc_bytes, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_symmetric_decrypt_array_buffer(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * @param {string} enc_string
     * @param {Uint8Array} key
     * @returns {Uint8Array}
     */
    static symmetric_decrypt_bytes(enc_string, key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(enc_string, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_symmetric_decrypt_bytes(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * @param {Uint8Array} enc_bytes
     * @param {Uint8Array} key
     * @returns {Uint8Array}
     */
    static symmetric_decrypt_filedata(enc_bytes, key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(enc_bytes, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_symmetric_decrypt_filedata(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * @param {string} enc_string
     * @param {Uint8Array} key
     * @returns {string}
     */
    static symmetric_decrypt_string(enc_string, key) {
        let deferred4_0;
        let deferred4_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(enc_string, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_symmetric_decrypt_string(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr3 = r0;
            var len3 = r1;
            if (r3) {
                ptr3 = 0; len3 = 0;
                throw takeObject(r2);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * DEPRECATED: Only used by send keys
     * @param {Uint8Array} plain
     * @param {Uint8Array} key
     * @returns {string}
     */
    static symmetric_encrypt_bytes(plain, key) {
        let deferred4_0;
        let deferred4_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(plain, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_symmetric_encrypt_bytes(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr3 = r0;
            var len3 = r1;
            if (r3) {
                ptr3 = 0; len3 = 0;
                throw takeObject(r2);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * @param {Uint8Array} plain
     * @param {Uint8Array} key
     * @returns {Uint8Array}
     */
    static symmetric_encrypt_filedata(plain, key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(plain, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_symmetric_encrypt_filedata(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * @param {string} plain
     * @param {Uint8Array} key
     * @returns {string}
     */
    static symmetric_encrypt_string(plain, key) {
        let deferred4_0;
        let deferred4_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(plain, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_symmetric_encrypt_string(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr3 = r0;
            var len3 = r1;
            if (r3) {
                ptr3 = 0; len3 = 0;
                throw takeObject(r2);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Unwraps (decrypts) a wrapped PKCS8 DER encoded decapsulation (private) key using a symmetric
     * wrapping key.
     * @param {string} wrapped_key
     * @param {Uint8Array} wrapping_key
     * @returns {Uint8Array}
     */
    static unwrap_decapsulation_key(wrapped_key, wrapping_key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(wrapped_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(wrapping_key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_unwrap_decapsulation_key(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Unwraps (decrypts) a wrapped SPKI DER encoded encapsulation (public) key using a symmetric
     * wrapping key.
     * @param {string} wrapped_key
     * @param {Uint8Array} wrapping_key
     * @returns {Uint8Array}
     */
    static unwrap_encapsulation_key(wrapped_key, wrapping_key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(wrapped_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(wrapping_key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_unwrap_encapsulation_key(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Unwraps (decrypts) a wrapped symmetric key using a symmetric wrapping key, returning the
     * unwrapped key as a serialized byte array.
     * @param {string} wrapped_key
     * @param {Uint8Array} wrapping_key
     * @returns {Uint8Array}
     */
    static unwrap_symmetric_key(wrapped_key, wrapping_key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(wrapped_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(wrapping_key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_unwrap_symmetric_key(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * For a given signing identity (verifying key), this function verifies that the signing
     * identity claimed ownership of the public key. This is a one-sided claim and merely shows
     * that the signing identity has the intent to receive messages encrypted to the public
     * key.
     * @param {Uint8Array} signed_public_key
     * @param {Uint8Array} verifying_key
     * @returns {Uint8Array}
     */
    static verify_and_unwrap_signed_public_key(signed_public_key, verifying_key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(signed_public_key, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(verifying_key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_verify_and_unwrap_signed_public_key(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Given a wrapped signing key and the symmetric key it is wrapped with, this returns
     * the corresponding verifying key.
     * @param {string} signing_key
     * @param {Uint8Array} wrapping_key
     * @returns {Uint8Array}
     */
    static verifying_key_for_signing_key(signing_key, wrapping_key) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(signing_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(wrapping_key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_verifying_key_for_signing_key(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v3 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v3;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Wraps (encrypts) a PKCS8 DER encoded decapsulation (private) key using a symmetric wrapping
     * key,
     * @param {Uint8Array} decapsulation_key
     * @param {Uint8Array} wrapping_key
     * @returns {string}
     */
    static wrap_decapsulation_key(decapsulation_key, wrapping_key) {
        let deferred4_0;
        let deferred4_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(decapsulation_key, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(wrapping_key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_wrap_decapsulation_key(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr3 = r0;
            var len3 = r1;
            if (r3) {
                ptr3 = 0; len3 = 0;
                throw takeObject(r2);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Wraps (encrypts) an SPKI DER encoded encapsulation (public) key using a symmetric wrapping
     * key. Note: Usually, a public key is - by definition - public, so this should not be
     * used. The specific use-case for this function is to enable rotateable key sets, where
     * the "public key" is not public, with the intent of preventing the server from being able
     * to overwrite the user key unlocked by the rotateable keyset.
     * @param {Uint8Array} encapsulation_key
     * @param {Uint8Array} wrapping_key
     * @returns {string}
     */
    static wrap_encapsulation_key(encapsulation_key, wrapping_key) {
        let deferred4_0;
        let deferred4_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(encapsulation_key, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(wrapping_key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_wrap_encapsulation_key(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr3 = r0;
            var len3 = r1;
            if (r3) {
                ptr3 = 0; len3 = 0;
                throw takeObject(r2);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Wraps (encrypts) a symmetric key using a symmetric wrapping key, returning the wrapped key
     * as an EncString.
     * @param {Uint8Array} key_to_be_wrapped
     * @param {Uint8Array} wrapping_key
     * @returns {string}
     */
    static wrap_symmetric_key(key_to_be_wrapped, wrapping_key) {
        let deferred4_0;
        let deferred4_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArray8ToWasm0(key_to_be_wrapped, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(wrapping_key, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            wasm.purecrypto_wrap_symmetric_key(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            var ptr3 = r0;
            var len3 = r1;
            if (r3) {
                ptr3 = 0; len3 = 0;
                throw takeObject(r2);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
}
if (Symbol.dispose) PureCrypto.prototype[Symbol.dispose] = PureCrypto.prototype.free;
exports.PureCrypto = PureCrypto;

/**
 * Client for initializing a user account.
 */
class RegistrationClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(RegistrationClient.prototype);
        obj.__wbg_ptr = ptr;
        RegistrationClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        RegistrationClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_registrationclient_free(ptr, 0);
    }
    /**
     * Initializes a new cryptographic state for a user and posts it to the server;
     * enrolls the user to master password unlock.
     * @param {JitMasterPasswordRegistrationRequest} request
     * @returns {Promise<JitMasterPasswordRegistrationResponse>}
     */
    post_keys_for_jit_password_registration(request) {
        const ret = wasm.registrationclient_post_keys_for_jit_password_registration(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Initializes a new cryptographic state for a user and posts it to the server; enrolls the
     * user to key connector unlock.
     * @param {string} key_connector_url
     * @param {string} sso_org_identifier
     * @returns {Promise<KeyConnectorRegistrationResult>}
     */
    post_keys_for_key_connector_registration(key_connector_url, sso_org_identifier) {
        const ptr0 = passStringToWasm0(key_connector_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(sso_org_identifier, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.registrationclient_post_keys_for_key_connector_registration(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return takeObject(ret);
    }
    /**
     * Initializes a new cryptographic state for a user and posts it to the server; enrolls in
     * admin password reset and finally enrolls the user to TDE unlock.
     * @param {TdeRegistrationRequest} request
     * @returns {Promise<TdeRegistrationResponse>}
     */
    post_keys_for_tde_registration(request) {
        const ret = wasm.registrationclient_post_keys_for_tde_registration(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Initializes new password-based cryptographic state for a user
     * and posts the state to the server
     * @param {UserMasterPasswordRegistrationRequest} request
     * @returns {Promise<UserMasterPasswordRegistrationResponse>}
     */
    post_keys_for_user_password_registration(request) {
        const ret = wasm.registrationclient_post_keys_for_user_password_registration(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Seals an [`OpenOrgInvite`] into a [`SealedOpenOrgInvite`]. The returned
     * `sealed_data` is safe to place on the verification-email link; the returned
     * `high_entropy_secret` must stay client-side.
     * @param {OpenOrgInvite} input
     * @returns {SealedOpenOrgInvite}
     */
    seal_open_org_invite_data(input) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.registrationclient_seal_open_org_invite_data(retptr, this.__wbg_ptr, addHeapObject(input));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Unseals a [`SealedOpenOrgInvite`] back into an [`OpenOrgInvite`]. Returns
     * [`RegistrationError::Crypto`] if the paired secret does not match the sealed payload or
     * the payload has been tampered with.
     * @param {SealedOpenOrgInvite} sealed
     * @returns {OpenOrgInvite}
     */
    unseal_open_org_invite_data(sealed) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.registrationclient_unseal_open_org_invite_data(retptr, this.__wbg_ptr, addHeapObject(sealed));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
}
if (Symbol.dispose) RegistrationClient.prototype[Symbol.dispose] = RegistrationClient.prototype.free;
exports.RegistrationClient = RegistrationClient;

/**
 * @enum {0 | 1 | 2 | 3}
 */
const RsaError = Object.freeze({
    Decryption: 0, "0": "Decryption",
    Encryption: 1, "1": "Encryption",
    KeyParse: 2, "2": "KeyParse",
    KeySerialize: 3, "3": "KeySerialize",
});
exports.RsaError = RsaError;

/**
 * Client exposing random-number generation to cross-platform bindings.
 */
class SdkRandomNumberClient {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SdkRandomNumberClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sdkrandomnumberclient_free(ptr, 0);
    }
    /**
     * Generate `len` cryptographically-secure random bytes.
     *
     * Returns [`GenBytesError::TooManyBytes`] if `len` exceeds 1 KiB. If you want over 1KiB of
     * randomness, please reconsider your design.
     * @param {number} len
     * @returns {Uint8Array}
     */
    gen_bytes(len) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.sdkrandomnumberclient_gen_bytes(retptr, this.__wbg_ptr, len);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
            if (r3) {
                throw takeObject(r2);
            }
            var v1 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1, 1);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Generate a cryptographically-secure random number in the range `[min, max]` (inclusive).
     *
     * Returns [`GenRangeError::InvalidRange`] if `min > max`.
     * @param {number} min
     * @param {number} max
     * @returns {number}
     */
    gen_range(min, max) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.sdkrandomnumberclient_gen_range(retptr, this.__wbg_ptr, min, max);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return r0 >>> 0;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Generate a random v4 UUID, sampled from a CRNG
     *
     * This has 122 random bits of entropy.
     * @returns {string}
     */
    gen_uuid() {
        let deferred1_0;
        let deferred1_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.sdkrandomnumberclient_gen_uuid(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            deferred1_0 = r0;
            deferred1_1 = r1;
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Construct a new client.
     */
    constructor() {
        const ret = wasm.sdkrandomnumberclient_new();
        this.__wbg_ptr = ret >>> 0;
        SdkRandomNumberClientFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) SdkRandomNumberClient.prototype[Symbol.dispose] = SdkRandomNumberClient.prototype.free;
exports.SdkRandomNumberClient = SdkRandomNumberClient;

/**
 * @enum {0}
 */
const SecureNoteType = Object.freeze({
    Generic: 0, "0": "Generic",
});
exports.SecureNoteType = SecureNoteType;

/**
 * The `SendAccessClient` is used to interact with the Bitwarden API to get send access tokens.
 */
class SendAccessClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(SendAccessClient.prototype);
        obj.__wbg_ptr = ptr;
        SendAccessClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SendAccessClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sendaccessclient_free(ptr, 0);
    }
    /**
     * Requests a new send access token.
     * @param {SendAccessTokenRequest} request
     * @returns {Promise<SendAccessTokenResponse>}
     */
    request_send_access_token(request) {
        const ret = wasm.sendaccessclient_request_send_access_token(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
}
if (Symbol.dispose) SendAccessClient.prototype[Symbol.dispose] = SendAccessClient.prototype.free;
exports.SendAccessClient = SendAccessClient;

class SendClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(SendClient.prototype);
        obj.__wbg_ptr = ptr;
        SendClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SendClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sendclient_free(ptr, 0);
    }
    /**
     * Accesses a send, authenticated with a send access token.
     * The returned [SendAccessResponse] contains encrypted fields that must be decrypted
     * client-side using the key derived from the URL fragment.
     * @param {string} access_token
     * @returns {Promise<SendAccessResponse>}
     */
    access_send(access_token) {
        const ptr0 = passStringToWasm0(access_token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sendclient_access_send(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Create a new [Send] and save it to the server.
     * @param {SendAddRequest} request
     * @returns {Promise<SendView>}
     */
    create(request) {
        const ret = wasm.sendclient_create(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Create a new file [Send] and save it to the server.
     *
     * `file_buffer` is the *plaintext* file content. It is encrypted internally under the send key
     * derived for this send, and its ciphertext length is sent to the server as `file_length` so
     * the server can enforce storage quotas before the upload (matching the legacy client's
     * encrypt-then-create ordering).
     *
     * Returns the created send, the encrypted file bytes, and the metadata needed to upload them.
     * After calling this, hand [`CreateFileSendResponse::encrypted_file_buffer`] and the upload
     * metadata to [`SendClient::upload_send_file`].
     * @param {SendAddRequest} request
     * @param {Uint8Array} file_buffer
     * @returns {Promise<CreateFileSendResponse>}
     */
    create_file_send(request, file_buffer) {
        const ptr0 = passArray8ToWasm0(file_buffer, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sendclient_create_file_send(this.__wbg_ptr, addHeapObject(request), ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Decrypt a [`Send`] into a [`SendView`].
     * This is a temporary function to support the transition to fully using the SDK for Send logic
     * @param {Send} send
     * @returns {SendView}
     */
    decrypt_send(send) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.sendclient_decrypt_send(retptr, this.__wbg_ptr, addHeapObject(send));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Decrypt a [`SendAccessResponse`] into a [`SendAccessView`].
     *
     * `key_b64` is the URL-safe-base64 send key from the trailing segment of the send URL
     * fragment (16 bytes when decoded) — the same form [`SendAccessKey::from_url_b64`] accepts
     *
     * This is a temporary function to support the transition to fully using the SDK for Send logic
     * @param {string} key_b64
     * @param {SendAccessResponse} response
     * @returns {SendAccessView}
     */
    static decrypt_send_access(key_b64, response) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(key_b64, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.sendclient_decrypt_send_access(retptr, ptr0, len0, addHeapObject(response));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Delete a [Send] from the server and remove it from local state.
     * @param {SendId} send_id
     * @returns {Promise<void>}
     */
    delete(send_id) {
        const ret = wasm.sendclient_delete(this.__wbg_ptr, addHeapObject(send_id));
        return takeObject(ret);
    }
    /**
     * Edit the [Send] and save it to the server.
     * @param {SendId} send_id
     * @param {SendEditRequest} request
     * @returns {Promise<SendView>}
     */
    edit(send_id, request) {
        const ret = wasm.sendclient_edit(this.__wbg_ptr, addHeapObject(send_id), addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Encrypt a send with the provided key. This should only be used when rotating encryption
     * keys in the Web client.
     *
     * Until Typescript based key-rotation is removed after completing the rollout of sdk-based
     * key-rotation, this method must be provided the new symmetric key in base64 format. See
     * PM-23084
     * @param {SendView} send_view
     * @param {B64} new_key
     * @returns {Promise<Send>}
     */
    encrypt_send_for_rotation(send_view, new_key) {
        const ret = wasm.sendclient_encrypt_send_for_rotation(this.__wbg_ptr, addHeapObject(send_view), addHeapObject(new_key));
        return takeObject(ret);
    }
    /**
     * Fetch a single [Send] by its ID from the server and persist it to local state.
     *
     * Unlike [`SendClient::get`], which only reads from local state, this makes a network request
     * and refreshes the locally stored copy. Returns the still-encrypted [Send] — matching what a
     * sync-notification diff needs to compare `revision_date` and update encrypted state without
     * a decrypt round-trip — rather than a [`SendView`](crate::SendView); callers that want the
     * decrypted form can pass the result to [`SendClient::decrypt`].
     * @param {SendId} send_id
     * @returns {Promise<Send>}
     */
    fetch(send_id) {
        const ret = wasm.sendclient_fetch(this.__wbg_ptr, addHeapObject(send_id));
        return takeObject(ret);
    }
    /**
     * Get a specific [Send] by its ID from state and decrypt it to a [SendView].
     * @param {SendId} send_id
     * @returns {Promise<SendView>}
     */
    get(send_id) {
        const ret = wasm.sendclient_get(this.__wbg_ptr, addHeapObject(send_id));
        return takeObject(ret);
    }
    /**
     * Gets file download data for a file send, authenticated with a send access token.
     * @param {string} access_token
     * @param {string} file_id
     * @returns {Promise<SendFileDownloadData>}
     */
    get_file_download_data(access_token, file_id) {
        const ptr0 = passStringToWasm0(access_token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(file_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.sendclient_get_file_download_data(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return takeObject(ret);
    }
    /**
     * Get all sends from state and decrypt them to a list of [SendView].
     * @returns {Promise<SendView[]>}
     */
    list() {
        const ret = wasm.sendclient_list(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Remove the password from a [Send], saving the updated state to the server and local state.
     * @param {SendId} send_id
     * @returns {Promise<SendView>}
     */
    remove_password(send_id) {
        const ret = wasm.sendclient_remove_password(this.__wbg_ptr, addHeapObject(send_id));
        return takeObject(ret);
    }
    /**
     * Renew the upload URL for a file [Send].
     *
     * Returns a fresh upload URL if the previous one has expired.
     * @param {SendId} send_id
     * @param {string} file_id
     * @returns {Promise<string>}
     */
    renew_file_upload_url(send_id, file_id) {
        const ptr0 = passStringToWasm0(file_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sendclient_renew_file_upload_url(this.__wbg_ptr, addHeapObject(send_id), ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Retry any [Send] deletions that previously failed (e.g. while offline), removing each from
     * the pending queue once the server confirms it is gone.
     * @returns {Promise<void>}
     */
    retry_pending_deletions() {
        const ret = wasm.sendclient_retry_pending_deletions(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Upload the encrypted file data for a file [Send].
     *
     * `data` must be the encrypted file content (encrypted with the send key).
     * `encrypted_file_name` is the encrypted file name string from [`CreateFileSendResponse`].
     *
     * `file_upload_type` and `upload_url` come from [`CreateFileSendResponse`] and select the
     * upload backend:
     * - [`FileUploadType::Direct`] uploads directly to the Bitwarden server via a multipart POST.
     *   The `upload_url` is ignored in this case (the direct endpoint is derived from the send and
     *   file IDs).
     * - [`FileUploadType::Azure`] `PUT`s the ciphertext to the pre-signed Azure Blob Storage
     *   `upload_url`. If that URL has expired, it is renewed once via
     *   [`SendClient::renew_file_upload_url`] and the upload is retried.
     * @param {SendId} send_id
     * @param {string} file_id
     * @param {string} encrypted_file_name
     * @param {FileUploadType} file_upload_type
     * @param {string} upload_url
     * @param {Uint8Array} data
     * @returns {Promise<void>}
     */
    upload_send_file(send_id, file_id, encrypted_file_name, file_upload_type, upload_url, data) {
        const ptr0 = passStringToWasm0(file_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(encrypted_file_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(upload_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len3 = WASM_VECTOR_LEN;
        const ret = wasm.sendclient_upload_send_file(this.__wbg_ptr, addHeapObject(send_id), ptr0, len0, ptr1, len1, file_upload_type, ptr2, len2, ptr3, len3);
        return takeObject(ret);
    }
}
if (Symbol.dispose) SendClient.prototype[Symbol.dispose] = SendClient.prototype.free;
exports.SendClient = SendClient;

/**
 * Indicates the version of Send data encryption that is being used
 * @enum {1}
 */
const SendEncryptionType = Object.freeze({
    /**
     * V1 encryption (field by field)
     */
    V1: 1, "1": "V1",
});
exports.SendEncryptionType = SendEncryptionType;

/**
 * Client for the Send sync handler, for callers that fetch sync data themselves (e.g. the Web
 * client) and only want the Send-persistence part of a sync run.
 */
class SendSyncHandlerClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(SendSyncHandlerClient.prototype);
        obj.__wbg_ptr = ptr;
        SendSyncHandlerClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SendSyncHandlerClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sendsynchandlerclient_free(ptr, 0);
    }
    /**
     * Persists the sends from a sync response. Call this after each sync.
     * @param {Send[]} sends
     * @returns {Promise<void>}
     */
    on_sync(sends) {
        const ptr0 = passArrayJsValueToWasm0(sends, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sendsynchandlerclient_on_sync(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
}
if (Symbol.dispose) SendSyncHandlerClient.prototype[Symbol.dispose] = SendSyncHandlerClient.prototype.free;
exports.SendSyncHandlerClient = SendSyncHandlerClient;

/**
 * The type of Send, either text, file, or item
 * @enum {0 | 1 | 2}
 */
const SendType = Object.freeze({
    /**
     * Text-based send
     */
    Text: 0, "0": "Text",
    /**
     * File-based send
     */
    File: 1, "1": "File",
    /**
     * Item-based send
     */
    Item: 2, "2": "Item",
});
exports.SendType = SendType;

/**
 * JavaScript wrapper for ServerCommunicationConfigClient
 *
 * This provides TypeScript access to the server communication configuration client,
 * allowing clients to check bootstrap requirements and retrieve cookies for HTTP requests.
 */
class ServerCommunicationConfigClient {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ServerCommunicationConfigClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_servercommunicationconfigclient_free(ptr, 0);
    }
    /**
     * Acquires a cookie from the platform and saves it to the repository
     *
     * This method calls the platform API to trigger cookie acquisition (e.g., browser
     * redirect to IdP), then validates and stores the acquired cookie in the repository.
     *
     * # Arguments
     *
     * * `domain` - The server domain (e.g., "vault.acme.com")
     *
     * # Errors
     *
     * Returns an error if:
     * - Cookie acquisition was cancelled by the user
     * - Server configuration doesn't support SSO cookies (Direct bootstrap)
     * - Acquired cookie name doesn't match expected name
     * - Repository operations fail
     * @param {string} domain
     * @returns {Promise<AcquiredCookie[]>}
     */
    acquireCookie(domain) {
        const ptr0 = passStringToWasm0(domain, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.servercommunicationconfigclient_acquireCookie(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Returns all cookies that should be included in requests to this server
     *
     * Returns an array of [cookie_name, cookie_value] pairs.
     *
     * # Arguments
     *
     * * `domain` - The server domain (e.g., "vault.acme.com")
     * @param {string} domain
     * @returns {Promise<any>}
     */
    cookies(domain) {
        const ptr0 = passStringToWasm0(domain, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.servercommunicationconfigclient_cookies(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Retrieves the server communication configuration for a domain
     *
     * If no configuration exists, returns a default Direct bootstrap configuration.
     *
     * # Arguments
     *
     * * `domain` - The server domain (e.g., "vault.acme.com")
     *
     * # Errors
     *
     * Returns an error if the repository fails to retrieve the configuration.
     * @param {string} domain
     * @returns {Promise<ServerCommunicationConfig>}
     */
    getConfig(domain) {
        const ptr0 = passStringToWasm0(domain, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.servercommunicationconfigclient_getConfig(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Returns all cookies that should be included in requests to this server
     * and triggers cookie acquisition if needed
     *
     * # Arguments
     *
     * * `domain` - The server domain (e.g., "vault.acme.com")
     * @param {string} domain
     * @returns {Promise<AcquiredCookie[]>}
     */
    getCookies(domain) {
        const ptr0 = passStringToWasm0(domain, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.servercommunicationconfigclient_getCookies(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Determines if cookie bootstrapping is needed for this domain
     *
     * # Arguments
     *
     * * `domain` - The server domain (e.g., "vault.acme.com")
     * @param {string} domain
     * @returns {Promise<boolean>}
     */
    needsBootstrap(domain) {
        const ptr0 = passStringToWasm0(domain, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.servercommunicationconfigclient_needsBootstrap(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Creates a new ServerCommunicationConfigClient with a JavaScript repository and platform API
     *
     * The repository should be backed by StateProvider (or equivalent
     * storage mechanism) for persistence.
     *
     * # Arguments
     *
     * * `repository` - JavaScript implementation of the repository interface
     * * `platform_api` - JavaScript implementation of the platform API interface
     * @param {ServerCommunicationConfigRepository} repository
     * @param {ServerCommunicationConfigPlatformApi} platform_api
     */
    constructor(repository, platform_api) {
        const ret = wasm.servercommunicationconfigclient_new(addHeapObject(repository), addHeapObject(platform_api));
        this.__wbg_ptr = ret >>> 0;
        ServerCommunicationConfigClientFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Sets the server communication configuration for a domain
     *
     * This method saves the provided communication configuration to the repository.
     * Typically called when receiving the `/api/config` response from the server.
     * Previously acquired cookies are preserved automatically.
     *
     * # Arguments
     *
     * * `domain` - The server domain (e.g., "vault.acme.com")
     * * `request` - The server communication configuration to store
     *
     * # Errors
     *
     * Returns an error if the repository save operation fails
     * @param {string} domain
     * @param {SetCommunicationTypeRequest} request
     * @returns {Promise<void>}
     */
    setCommunicationType(domain, request) {
        const ptr0 = passStringToWasm0(domain, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.servercommunicationconfigclient_setCommunicationType(this.__wbg_ptr, ptr0, len0, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Sets the server communication configuration using the domain from the config
     *
     * Extracts the `cookie_domain` from the `SsoCookieVendor` config and uses it as the
     * storage key. If the config is `Direct` or `cookie_domain` is not set, the call
     * is silently ignored.
     *
     * # Arguments
     *
     * * `config` - The server communication configuration to store
     *
     * # Errors
     *
     * Returns an error if the repository save operation fails
     * @param {SetCommunicationTypeRequest} request
     * @returns {Promise<void>}
     */
    setCommunicationTypeV2(request) {
        const ret = wasm.servercommunicationconfigclient_setCommunicationTypeV2(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
}
if (Symbol.dispose) ServerCommunicationConfigClient.prototype[Symbol.dispose] = ServerCommunicationConfigClient.prototype.free;
exports.ServerCommunicationConfigClient = ServerCommunicationConfigClient;

/**
 * Shared-unlock peer for WASM clients.
 */
class SharedUnlockPeer {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SharedUnlockPeerFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sharedunlockpeer_free(ptr, 0);
    }
    /**
     * Forwards a device event to the shared-unlock peer state machine.
     * @param {DeviceEvent} event
     * @returns {Promise<void>}
     */
    handle_device_event(event) {
        const ret = wasm.sharedunlockpeer_handle_device_event(this.__wbg_ptr, addHeapObject(event));
        return takeObject(ret);
    }
    /**
     * Creates a new shared-unlock peer
     * @param {IpcClient} ipc_client
     * @param {SharedUnlockDriver} driver
     */
    constructor(ipc_client, driver) {
        _assertClass(ipc_client, IpcClient);
        const ret = wasm.sharedunlockpeer_new(ipc_client.__wbg_ptr, addHeapObject(driver));
        this.__wbg_ptr = ret >>> 0;
        SharedUnlockPeerFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Sets which clients this peer shares one user's unlock state with. Defaults to none.
     * @param {UserId} user_id
     * @param {SharedUnlockClient[]} destinations
     */
    set_destinations(user_id, destinations) {
        const ptr0 = passArrayJsValueToWasm0(destinations, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.sharedunlockpeer_set_destinations(this.__wbg_ptr, addHeapObject(user_id), ptr0, len0);
    }
    /**
     * Starts the shared-unlock peer
     * @param {AbortController | null} [abort_controller]
     * @returns {Promise<void>}
     */
    start(abort_controller) {
        const ret = wasm.sharedunlockpeer_start(this.__wbg_ptr, isLikeNone(abort_controller) ? 0 : addHeapObject(abort_controller));
        return takeObject(ret);
    }
}
if (Symbol.dispose) SharedUnlockPeer.prototype[Symbol.dispose] = SharedUnlockPeer.prototype.free;
exports.SharedUnlockPeer = SharedUnlockPeer;

/**
 * Client for interacting with the key-management state bridge. This is used to read and write
 * state held by the clients
 */
class StateBridgeClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(StateBridgeClient.prototype);
        obj.__wbg_ptr = ptr;
        StateBridgeClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        StateBridgeClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_statebridgeclient_free(ptr, 0);
    }
    /**
     * Registers a the state bridge implementation provided by the host environment.
     * @param {WasmStateBridge} bridge_impl
     */
    register_bridge_impl(bridge_impl) {
        wasm.statebridgeclient_register_bridge_impl(this.__wbg_ptr, addHeapObject(bridge_impl));
    }
}
if (Symbol.dispose) StateBridgeClient.prototype[Symbol.dispose] = StateBridgeClient.prototype.free;
exports.StateBridgeClient = StateBridgeClient;

class StateClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(StateClient.prototype);
        obj.__wbg_ptr = ptr;
        StateClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        StateClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_stateclient_free(ptr, 0);
    }
    /**
     * @param {Repositories} repositories
     */
    register_client_managed_repositories(repositories) {
        wasm.stateclient_register_client_managed_repositories(this.__wbg_ptr, addHeapObject(repositories));
    }
}
if (Symbol.dispose) StateClient.prototype[Symbol.dispose] = StateClient.prototype.free;
exports.StateClient = StateClient;

class TotpClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(TotpClient.prototype);
        obj.__wbg_ptr = ptr;
        TotpClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TotpClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_totpclient_free(ptr, 0);
    }
    /**
     * Generates a TOTP code from a provided key
     *
     * # Arguments
     * - `key` - Can be:
     *     - A base32 encoded string
     *     - OTP Auth URI
     *     - Steam URI
     * - `time_ms` - Optional timestamp in milliseconds
     * @param {string} key
     * @param {number | null} [time_ms]
     * @returns {TotpResponse}
     */
    generate_totp(key, time_ms) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.totpclient_generate_totp(retptr, this.__wbg_ptr, ptr0, len0, !isLikeNone(time_ms), isLikeNone(time_ms) ? 0 : time_ms);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return takeObject(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
}
if (Symbol.dispose) TotpClient.prototype[Symbol.dispose] = TotpClient.prototype.free;
exports.TotpClient = TotpClient;

/**
 * @enum {0 | 1 | 2 | 3 | 4 | 5}
 */
const UriMatchType = Object.freeze({
    Domain: 0, "0": "Domain",
    Host: 1, "1": "Host",
    StartsWith: 2, "2": "StartsWith",
    Exact: 3, "3": "Exact",
    RegularExpression: 4, "4": "RegularExpression",
    Never: 5, "5": "Never",
});
exports.UriMatchType = UriMatchType;

/**
 * Client for managing the cryptographic machinery of a user account, including key-rotation.
 */
class UserCryptoManagementClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(UserCryptoManagementClient.prototype);
        obj.__wbg_ptr = ptr;
        UserCryptoManagementClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        UserCryptoManagementClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_usercryptomanagementclient_free(ptr, 0);
    }
    /**
     * Changes the account's KDF settings, and sets them on the server.
     * @param {string} password
     * @param {Kdf} new_kdf
     * @returns {Promise<void>}
     */
    change_kdf(password, new_kdf) {
        const ptr0 = passStringToWasm0(password, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.usercryptomanagementclient_change_kdf(this.__wbg_ptr, ptr0, len0, addHeapObject(new_kdf));
        return takeObject(ret);
    }
    /**
     * Fetches the emergency access public keys for V1 emergency access memberships for the user.
     * These have to be trusted manually be the user before rotating.
     * @returns {Promise<V1EmergencyAccessMembership[]>}
     */
    get_untrusted_emergency_access_public_keys() {
        const ret = wasm.usercryptomanagementclient_get_untrusted_emergency_access_public_keys(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * The organization and emergency access public keys the user has to confirm as trusted before
     * a key rotation.
     *
     * When the rotation creates a V2 upgrade token, the organization list is empty. Organization
     * admins update account recovery from that token, so the user confirms nothing. Every other
     * rotation returns one entry per organization the user is enrolled in for account recovery.
     *
     * Emergency access grantees always need a confirmation, because every rotation shares the new
     * user key with each of them.
     * @param {UpgradeTokenAction} upgrade_token_action
     * @returns {Promise<UntrustedMembershipsResponse>}
     */
    get_untrusted_memberships(upgrade_token_action) {
        const ret = wasm.usercryptomanagementclient_get_untrusted_memberships(this.__wbg_ptr, addHeapObject(upgrade_token_action));
        return takeObject(ret);
    }
    /**
     * The organization public keys the user has to confirm as trusted before a key rotation.
     *
     * When the rotation creates a V2 upgrade token, the list is empty. Organization admins update
     * account recovery from that token, so the user confirms nothing. Every other rotation returns
     * one entry per organization the user is enrolled in for account recovery.
     * @param {UpgradeTokenAction} upgrade_token_action
     * @returns {Promise<V1OrganizationMembership[]>}
     */
    get_untrusted_organization_public_keys(upgrade_token_action) {
        const ret = wasm.usercryptomanagementclient_get_untrusted_organization_public_keys(this.__wbg_ptr, addHeapObject(upgrade_token_action));
        return takeObject(ret);
    }
    /**
     * Migrates an initialized account to Key Connector unlock.
     *
     * Requires the client to be unlocked so the current user key is available in memory.
     * @param {string} key_connector_url
     * @returns {Promise<void>}
     */
    migrate_to_key_connector(key_connector_url) {
        const ptr0 = passStringToWasm0(key_connector_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.usercryptomanagementclient_migrate_to_key_connector(this.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * Combines a password change and user key rotation into a single request.
     *
     * Before rotating, this checks whether the user's public key encryption key pair needs
     * regeneration and fixes it if necessary. This ensures that key rotation can proceed even
     * if the existing private key is corrupt.
     * @param {PasswordChangeAndRotateUserKeysRequest} request
     * @returns {Promise<void>}
     */
    password_change_and_rotate_user_keys(request) {
        const ret = wasm.usercryptomanagementclient_password_change_and_rotate_user_keys(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Returns the PIN settings sub-client.
     * @returns {PinSettingsClient}
     */
    pin_settings() {
        const ret = wasm.usercryptomanagementclient_pin_settings(this.__wbg_ptr);
        return PinSettingsClient.__wrap(ret);
    }
    /**
     * Checks whether the user's public key encryption key pair needs regeneration, and if so,
     * generates a new key pair and submits it to the server.
     *
     * If regeneration is performed, the updated [`WrappedAccountCryptographicState`] is
     * persisted via the state bridge (when registered).
     *
     * Requires the client to be unlocked so the current user key is available in memory.
     * Only applicable to V1 encryption accounts.
     * @returns {Promise<boolean>}
     */
    regenerate_public_key_encryption_key_pair_if_needed() {
        const ret = wasm.usercryptomanagementclient_regenerate_public_key_encryption_key_pair_if_needed(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Returns whether the client may prompt the user to migrate to v2 encryption.
     *
     * [`MigrationPermission::Wait`] means the user is still inside the two-week grace period and
     * the prompt must not be shown. [`MigrationPermission::Migrate`] means the grace period has
     * elapsed.
     *
     * The first call has a side effect: when no timestamp is stored, it writes
     * the current timestamp and returns [`MigrationPermission::Wait`]. The
     * window is therefore two weeks from the first call, not from login. A
     * client that never calls this method never opens the window.
     *
     * The SDK never clears the timestamp. Clearing is the client's decision
     * and resets the window. The timestamp is persisted so a user who logs out
     * often cannot avoid the prompt indefinitely.
     *
     * Panics when no state bridge is registered.
     * @returns {Promise<MigrationPermission>}
     */
    request_permission_to_migrate_to_v2() {
        const ret = wasm.usercryptomanagementclient_request_permission_to_migrate_to_v2(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Rotates the user's encryption keys without a password change.
     * @param {RotateUserKeysRequest} request
     * @returns {Promise<void>}
     */
    rotate_user_keys(request) {
        const ret = wasm.usercryptomanagementclient_rotate_user_keys(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Checks whether the user's public key encryption key pair needs regeneration.
     *
     * Returns `true` if the key pair is missing, corrupt, or doesn't match the public key on
     * the server. Returns `false` if the key pair is valid or if regeneration is not applicable
     * (e.g., user key not available, V2 encryption account).
     * @returns {Promise<boolean>}
     */
    should_regenerate_public_key_encryption_key_pair() {
        const ret = wasm.usercryptomanagementclient_should_regenerate_public_key_encryption_key_pair(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Records the id of the user's current user key with the server, and stores it as the id the
     * server knows.
     *
     * Safe to call when no backfill is needed, but [`Self::user_key_id_needs_backfill`] avoids the
     * round trip.
     *
     * Requires the client to be unlocked so the current user key is available in memory.
     * @returns {Promise<void>}
     */
    user_key_id_backfill() {
        const ret = wasm.usercryptomanagementclient_user_key_id_backfill(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Returns whether the server is missing the id of the user's current user key.
     * @returns {Promise<boolean>}
     */
    user_key_id_needs_backfill() {
        const ret = wasm.usercryptomanagementclient_user_key_id_needs_backfill(this.__wbg_ptr);
        return takeObject(ret);
    }
}
if (Symbol.dispose) UserCryptoManagementClient.prototype[Symbol.dispose] = UserCryptoManagementClient.prototype.free;
exports.UserCryptoManagementClient = UserCryptoManagementClient;

class VaultClient {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(VaultClient.prototype);
        obj.__wbg_ptr = ptr;
        VaultClientFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        VaultClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_vaultclient_free(ptr, 0);
    }
    /**
     * Attachment related operations.
     * @returns {AttachmentsClient}
     */
    attachments() {
        const ret = wasm.vaultclient_attachments(this.__wbg_ptr);
        return AttachmentsClient.__wrap(ret);
    }
    /**
     * Cipher risk evaluation operations.
     * @returns {CipherRiskClient}
     */
    cipher_risk() {
        const ret = wasm.vaultclient_cipher_risk(this.__wbg_ptr);
        return CipherRiskClient.__wrap(ret);
    }
    /**
     * Cipher related operations.
     * @returns {CiphersClient}
     */
    ciphers() {
        const ret = wasm.vaultclient_ciphers(this.__wbg_ptr);
        return CiphersClient.__wrap(ret);
    }
    /**
     * Collection related operations.
     *
     * This nested accessor is kept for backwards compatibility. New callers should prefer the
     * `collections()` accessor registered directly on the top-level Password Manager client.
     * @returns {CollectionsClient}
     */
    collections() {
        const ret = wasm.vaultclient_collections(this.__wbg_ptr);
        return CollectionsClient.__wrap(ret);
    }
    /**
     * Folder related operations.
     * @returns {FoldersClient}
     */
    folders() {
        const ret = wasm.vaultclient_folders(this.__wbg_ptr);
        return FoldersClient.__wrap(ret);
    }
    /**
     * TOTP related operations.
     * @returns {TotpClient}
     */
    totp() {
        const ret = wasm.vaultclient_totp(this.__wbg_ptr);
        return TotpClient.__wrap(ret);
    }
}
if (Symbol.dispose) VaultClient.prototype[Symbol.dispose] = VaultClient.prototype.free;
exports.VaultClient = VaultClient;

/**
 * Atomically validates and applies a reconciliation plan to owned decrypted ciphers.
 * @param {AliasReconciliationPlan} plan
 * @param {Alias[]} aliases
 * @param {CipherView[]} ciphers
 * @returns {AliasReconciliationApplyOutput}
 */
function apply_alias_reconciliation(plan, aliases, ciphers) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passArrayJsValueToWasm0(aliases, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(ciphers, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        wasm.apply_alias_reconciliation(retptr, addHeapObject(plan), ptr0, len0, ptr1, len1);
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
        if (r2) {
            throw takeObject(r1);
        }
        return takeObject(r0);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}
exports.apply_alias_reconciliation = apply_alias_reconciliation;

/**
 * Binds a canonical reference to a decrypted login cipher after username integrity validation.
 * @param {string} value
 * @param {CipherView} cipher
 * @returns {AliasCipherMutationResult}
 */
function bind_alias_reference(value, cipher) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0(value, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.bind_alias_reference(retptr, ptr0, len0, addHeapObject(cipher));
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
        if (r2) {
            throw takeObject(r1);
        }
        return takeObject(r0);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}
exports.bind_alias_reference = bind_alias_reference;

/**
 * Validates and deterministically orders an encrypted provider-neutral journal.
 * @param {AliasJournal} journal
 * @returns {AliasJournal}
 */
function canonicalize_alias_journal(journal) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.canonicalize_alias_journal(retptr, addHeapObject(journal));
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
        if (r2) {
            throw takeObject(r1);
        }
        return takeObject(r0);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}
exports.canonicalize_alias_journal = canonicalize_alias_journal;

/**
 * Clears a binding before save when the login username no longer matches its bound address.
 * @param {CipherView} cipher
 * @returns {AliasCipherMutationResult}
 */
function clear_alias_reference_if_username_changed(cipher) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.clear_alias_reference_if_username_changed(retptr, addHeapObject(cipher));
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
        if (r2) {
            throw takeObject(r1);
        }
        return takeObject(r0);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}
exports.clear_alias_reference_if_username_changed = clear_alias_reference_if_username_changed;

/**
 * Creates the canonical serialized v1 alias reference from neutral alias identity.
 * @param {AliasIdentity} identity
 * @returns {string}
 */
function create_alias_reference(identity) {
    let deferred2_0;
    let deferred2_1;
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.create_alias_reference(retptr, addHeapObject(identity));
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
        var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
        var ptr1 = r0;
        var len1 = r1;
        if (r3) {
            ptr1 = 0; len1 = 0;
            throw takeObject(r2);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}
exports.create_alias_reference = create_alias_reference;

/**
 * Generate a new SSH key pair
 *
 * # Arguments
 * - `key_algorithm` - The algorithm to use for the key pair
 *
 * # Returns
 * - `Ok(SshKey)` if the key was successfully generated
 * - `Err(KeyGenerationError)` if the key could not be generated
 * @param {KeyAlgorithm} key_algorithm
 * @returns {SshKeyView}
 */
function generate_ssh_key(key_algorithm) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.generate_ssh_key(retptr, addHeapObject(key_algorithm));
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
        if (r2) {
            throw takeObject(r1);
        }
        return takeObject(r0);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}
exports.generate_ssh_key = generate_ssh_key;

/**
 * Convert a PCKS8 or OpenSSH encrypted or unencrypted private key
 * to an OpenSSH private key with public key and fingerprint
 *
 * # Arguments
 * - `imported_key` - The private key to convert
 * - `password` - The password to use for decrypting the key
 *
 * # Returns
 * - `Ok(SshKey)` if the key was successfully coneverted
 * - `Err(PasswordRequired)` if the key is encrypted and no password was provided
 * - `Err(WrongPassword)` if the password provided is incorrect
 * - `Err(Parsing)` if the key could not be parsed
 * - `Err(UnsupportedKeyType)` if the key type is not supported
 * @param {string} imported_key
 * @param {string | null} [password]
 * @returns {SshKeyView}
 */
function import_ssh_key(imported_key, password) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0(imported_key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(password) ? 0 : passStringToWasm0(password, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        wasm.import_ssh_key(retptr, ptr0, len0, ptr1, len1);
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
        if (r2) {
            throw takeObject(r1);
        }
        return takeObject(r0);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}
exports.import_ssh_key = import_ssh_key;

/**
 * Initialize the SDK. Must be called before using any other API.
 * Only the first invocation has effect; subsequent calls are ignored.
 *
 * - `log_level`: Minimum level for console output. Defaults to `Info`.
 * - `flight_recorder_level`: Minimum level for the flight recorder. Defaults to `Info`.
 * - `flight_recorder_buffer_size`: Ring-buffer capacity for the flight recorder. Defaults to 1000.
 *   Pass `0` to disable the flight recorder entirely.
 * @param {LogLevel | null} [log_level]
 * @param {LogLevel | null} [flight_recorder_level]
 * @param {number | null} [flight_recorder_buffer_size]
 */
function init_sdk(log_level, flight_recorder_level, flight_recorder_buffer_size) {
    wasm.init_sdk(isLikeNone(log_level) ? 5 : log_level, isLikeNone(flight_recorder_level) ? 5 : flight_recorder_level, isLikeNone(flight_recorder_buffer_size) ? 0x100000001 : (flight_recorder_buffer_size) >>> 0);
}
exports.init_sdk = init_sdk;

/**
 * Registers shared-unlock biometrics RPC handlers on the IPC client.
 * @param {IpcClient} ipc_client
 * @param {BiometricsUnlock} biometrics_unlock
 * @returns {Promise<void>}
 */
function ipcRegisterBiometricsHandlers(ipc_client, biometrics_unlock) {
    _assertClass(ipc_client, IpcClient);
    const ret = wasm.ipcRegisterBiometricsHandlers(ipc_client.__wbg_ptr, addHeapObject(biometrics_unlock));
    return takeObject(ret);
}
exports.ipcRegisterBiometricsHandlers = ipcRegisterBiometricsHandlers;

/**
 * Registers a DiscoverHandler so that the client can respond to DiscoverRequests.
 * @param {IpcClient} ipc_client
 * @param {DiscoverResponse} response
 * @returns {Promise<void>}
 */
function ipcRegisterDiscoverHandler(ipc_client, response) {
    _assertClass(ipc_client, IpcClient);
    const ret = wasm.ipcRegisterDiscoverHandler(ipc_client.__wbg_ptr, addHeapObject(response));
    return takeObject(ret);
}
exports.ipcRegisterDiscoverHandler = ipcRegisterDiscoverHandler;

/**
 * Sends an `AuthenticateBiometrics` RPC request to the desktop renderer.
 * @param {IpcClient} ipc_client
 * @param {AbortSignal | null} [abort_signal]
 * @returns {Promise<boolean>}
 */
function ipcRequestAuthenticateBiometrics(ipc_client, abort_signal) {
    _assertClass(ipc_client, IpcClient);
    const ret = wasm.ipcRequestAuthenticateBiometrics(ipc_client.__wbg_ptr, isLikeNone(abort_signal) ? 0 : addHeapObject(abort_signal));
    return takeObject(ret);
}
exports.ipcRequestAuthenticateBiometrics = ipcRequestAuthenticateBiometrics;

/**
 * Sends a DiscoverRequest to the specified destination and returns the response.
 * @param {IpcClient} ipc_client
 * @param {Endpoint} destination
 * @param {AbortSignal | null} [abort_signal]
 * @returns {Promise<DiscoverResponse>}
 */
function ipcRequestDiscover(ipc_client, destination, abort_signal) {
    _assertClass(ipc_client, IpcClient);
    const ret = wasm.ipcRequestDiscover(ipc_client.__wbg_ptr, addHeapObject(destination), isLikeNone(abort_signal) ? 0 : addHeapObject(abort_signal));
    return takeObject(ret);
}
exports.ipcRequestDiscover = ipcRequestDiscover;

/**
 * Sends a `GetBiometricsStatus` RPC request to the desktop renderer
 * @param {IpcClient} ipc_client
 * @param {UserId} user_id
 * @param {AbortSignal | null} [abort_signal]
 * @returns {Promise<BiometricsStatus>}
 */
function ipcRequestGetBiometricsStatus(ipc_client, user_id, abort_signal) {
    _assertClass(ipc_client, IpcClient);
    const ret = wasm.ipcRequestGetBiometricsStatus(ipc_client.__wbg_ptr, addHeapObject(user_id), isLikeNone(abort_signal) ? 0 : addHeapObject(abort_signal));
    return takeObject(ret);
}
exports.ipcRequestGetBiometricsStatus = ipcRequestGetBiometricsStatus;

/**
 * Sends an `UnlockBiometrics` RPC request to the desktop renderer.
 * @param {IpcClient} ipc_client
 * @param {UserId} user_id
 * @param {AbortSignal | null} [abort_signal]
 * @returns {Promise<UnlockBiometricsResponse>}
 */
function ipcRequestUnlockBiometrics(ipc_client, user_id, abort_signal) {
    _assertClass(ipc_client, IpcClient);
    const ret = wasm.ipcRequestUnlockBiometrics(ipc_client.__wbg_ptr, addHeapObject(user_id), isLikeNone(abort_signal) ? 0 : addHeapObject(abort_signal));
    return takeObject(ret);
}
exports.ipcRequestUnlockBiometrics = ipcRequestUnlockBiometrics;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isAccessSendError(error) {
    try {
        const ret = wasm.isAccessSendError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isAccessSendError = isAccessSendError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isAccountCryptographyInitializationError(error) {
    try {
        const ret = wasm.isAccountCryptographyInitializationError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isAccountCryptographyInitializationError = isAccountCryptographyInitializationError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isAcquireCookieError(error) {
    try {
        const ret = wasm.isAcquireCookieError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isAcquireCookieError = isAcquireCookieError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isAlreadyRunningError(error) {
    try {
        const ret = wasm.isAlreadyRunningError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isAlreadyRunningError = isAlreadyRunningError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isBulkUpdateCollectionsCipherError(error) {
    try {
        const ret = wasm.isBulkUpdateCollectionsCipherError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isBulkUpdateCollectionsCipherError = isBulkUpdateCollectionsCipherError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCallError(error) {
    try {
        const ret = wasm.isCallError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCallError = isCallError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isChangeKdfError(error) {
    try {
        const ret = wasm.isChangeKdfError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isChangeKdfError = isChangeKdfError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isChannelError(error) {
    try {
        const ret = wasm.isChannelError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isChannelError = isChannelError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCipherAdminGetAttachmentDownloadUrlError(error) {
    try {
        const ret = wasm.isCipherAdminGetAttachmentDownloadUrlError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCipherAdminGetAttachmentDownloadUrlError = isCipherAdminGetAttachmentDownloadUrlError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCipherCreateAttachmentError(error) {
    try {
        const ret = wasm.isCipherCreateAttachmentError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCipherCreateAttachmentError = isCipherCreateAttachmentError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCipherDeleteAttachmentError(error) {
    try {
        const ret = wasm.isCipherDeleteAttachmentError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCipherDeleteAttachmentError = isCipherDeleteAttachmentError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCipherError(error) {
    try {
        const ret = wasm.isCipherError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCipherError = isCipherError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCipherGetAttachmentDownloadUrlError(error) {
    try {
        const ret = wasm.isCipherGetAttachmentDownloadUrlError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCipherGetAttachmentDownloadUrlError = isCipherGetAttachmentDownloadUrlError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCipherRenewFileUploadUrlError(error) {
    try {
        const ret = wasm.isCipherRenewFileUploadUrlError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCipherRenewFileUploadUrlError = isCipherRenewFileUploadUrlError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCipherRiskError(error) {
    try {
        const ret = wasm.isCipherRiskError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCipherRiskError = isCipherRiskError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCipherUpgradeAttachmentError(error) {
    try {
        const ret = wasm.isCipherUpgradeAttachmentError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCipherUpgradeAttachmentError = isCipherUpgradeAttachmentError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCollectionDecryptError(error) {
    try {
        const ret = wasm.isCollectionDecryptError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCollectionDecryptError = isCollectionDecryptError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCollectionEncryptError(error) {
    try {
        const ret = wasm.isCollectionEncryptError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCollectionEncryptError = isCollectionEncryptError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCreateCipherAdminError(error) {
    try {
        const ret = wasm.isCreateCipherAdminError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCreateCipherAdminError = isCreateCipherAdminError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCreateCipherError(error) {
    try {
        const ret = wasm.isCreateCipherError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCreateCipherError = isCreateCipherError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCreateFileSendError(error) {
    try {
        const ret = wasm.isCreateFileSendError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCreateFileSendError = isCreateFileSendError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCreateFolderError(error) {
    try {
        const ret = wasm.isCreateFolderError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCreateFolderError = isCreateFolderError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCreateSendError(error) {
    try {
        const ret = wasm.isCreateSendError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCreateSendError = isCreateSendError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCryptoClientError(error) {
    try {
        const ret = wasm.isCryptoClientError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCryptoClientError = isCryptoClientError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isCryptoError(error) {
    try {
        const ret = wasm.isCryptoError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isCryptoError = isCryptoError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isDatabaseError(error) {
    try {
        const ret = wasm.isDatabaseError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isDatabaseError = isDatabaseError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isDecryptError(error) {
    try {
        const ret = wasm.isDecryptError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isDecryptError = isDecryptError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isDecryptFileError(error) {
    try {
        const ret = wasm.isDecryptFileError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isDecryptFileError = isDecryptFileError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isDeleteAttachmentAdminError(error) {
    try {
        const ret = wasm.isDeleteAttachmentAdminError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isDeleteAttachmentAdminError = isDeleteAttachmentAdminError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isDeleteCipherAdminError(error) {
    try {
        const ret = wasm.isDeleteCipherAdminError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isDeleteCipherAdminError = isDeleteCipherAdminError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isDeleteCipherError(error) {
    try {
        const ret = wasm.isDeleteCipherError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isDeleteCipherError = isDeleteCipherError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isDeleteSendError(error) {
    try {
        const ret = wasm.isDeleteSendError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isDeleteSendError = isDeleteSendError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isDeriveKeyConnectorError(error) {
    try {
        const ret = wasm.isDeriveKeyConnectorError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isDeriveKeyConnectorError = isDeriveKeyConnectorError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isDeserializeError(error) {
    try {
        const ret = wasm.isDeserializeError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isDeserializeError = isDeserializeError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isEditCipherAdminError(error) {
    try {
        const ret = wasm.isEditCipherAdminError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isEditCipherAdminError = isEditCipherAdminError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isEditCipherError(error) {
    try {
        const ret = wasm.isEditCipherError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isEditCipherError = isEditCipherError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isEditFolderError(error) {
    try {
        const ret = wasm.isEditFolderError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isEditFolderError = isEditFolderError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isEditSendError(error) {
    try {
        const ret = wasm.isEditSendError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isEditSendError = isEditSendError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isEncryptError(error) {
    try {
        const ret = wasm.isEncryptError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isEncryptError = isEncryptError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isEncryptFileError(error) {
    try {
        const ret = wasm.isEncryptFileError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isEncryptFileError = isEncryptFileError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isEncryptionSettingsError(error) {
    try {
        const ret = wasm.isEncryptionSettingsError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isEncryptionSettingsError = isEncryptionSettingsError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isEnrollAdminPasswordResetError(error) {
    try {
        const ret = wasm.isEnrollAdminPasswordResetError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isEnrollAdminPasswordResetError = isEnrollAdminPasswordResetError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isExportError(error) {
    try {
        const ret = wasm.isExportError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isExportError = isExportError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isFetchSendError(error) {
    try {
        const ret = wasm.isFetchSendError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isFetchSendError = isFetchSendError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isGenBytesError(error) {
    try {
        const ret = wasm.isGenBytesError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isGenBytesError = isGenBytesError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isGenRangeError(error) {
    try {
        const ret = wasm.isGenRangeError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isGenRangeError = isGenRangeError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isGetAssignedOrgCiphersAdminError(error) {
    try {
        const ret = wasm.isGetAssignedOrgCiphersAdminError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isGetAssignedOrgCiphersAdminError = isGetAssignedOrgCiphersAdminError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isGetCipherError(error) {
    try {
        const ret = wasm.isGetCipherError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isGetCipherError = isGetCipherError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isGetFileDownloadDataError(error) {
    try {
        const ret = wasm.isGetFileDownloadDataError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isGetFileDownloadDataError = isGetFileDownloadDataError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isGetFolderError(error) {
    try {
        const ret = wasm.isGetFolderError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isGetFolderError = isGetFolderError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isGetOrganizationCiphersAdminError(error) {
    try {
        const ret = wasm.isGetOrganizationCiphersAdminError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isGetOrganizationCiphersAdminError = isGetOrganizationCiphersAdminError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isGetSendError(error) {
    try {
        const ret = wasm.isGetSendError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isGetSendError = isGetSendError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isImportError(error) {
    try {
        const ret = wasm.isImportError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isImportError = isImportError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isInviteLinkError(error) {
    try {
        const ret = wasm.isInviteLinkError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isInviteLinkError = isInviteLinkError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isKeyGenerationError(error) {
    try {
        const ret = wasm.isKeyGenerationError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isKeyGenerationError = isKeyGenerationError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isKeyIdBackfillError(error) {
    try {
        const ret = wasm.isKeyIdBackfillError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isKeyIdBackfillError = isKeyIdBackfillError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isKeyPairRegenerationError(error) {
    try {
        const ret = wasm.isKeyPairRegenerationError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isKeyPairRegenerationError = isKeyPairRegenerationError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isMakeKeysError(error) {
    try {
        const ret = wasm.isMakeKeysError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isMakeKeysError = isMakeKeysError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isManagedSettingsError(error) {
    try {
        const ret = wasm.isManagedSettingsError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isManagedSettingsError = isManagedSettingsError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isMasterPasswordError(error) {
    try {
        const ret = wasm.isMasterPasswordError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isMasterPasswordError = isMasterPasswordError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isMigrateToKeyConnectorError(error) {
    try {
        const ret = wasm.isMigrateToKeyConnectorError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isMigrateToKeyConnectorError = isMigrateToKeyConnectorError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isMoveCipherError(error) {
    try {
        const ret = wasm.isMoveCipherError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isMoveCipherError = isMoveCipherError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isOrganizationUsersManagementError(error) {
    try {
        const ret = wasm.isOrganizationUsersManagementError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isOrganizationUsersManagementError = isOrganizationUsersManagementError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isPasswordError(error) {
    try {
        const ret = wasm.isPasswordError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isPasswordError = isPasswordError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isPasswordLoginError(error) {
    try {
        const ret = wasm.isPasswordLoginError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isPasswordLoginError = isPasswordLoginError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isPasswordPreloginError(error) {
    try {
        const ret = wasm.isPasswordPreloginError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isPasswordPreloginError = isPasswordPreloginError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isPasswordRulesError(error) {
    try {
        const ret = wasm.isPasswordRulesError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isPasswordRulesError = isPasswordRulesError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isPeerStartError(error) {
    try {
        const ret = wasm.isPeerStartError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isPeerStartError = isPeerStartError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isPinSettingsError(error) {
    try {
        const ret = wasm.isPinSettingsError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isPinSettingsError = isPinSettingsError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isReceiveError(error) {
    try {
        const ret = wasm.isReceiveError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isReceiveError = isReceiveError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isRegistrationError(error) {
    try {
        const ret = wasm.isRegistrationError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isRegistrationError = isRegistrationError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isRemoveSendPasswordError(error) {
    try {
        const ret = wasm.isRemoveSendPasswordError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isRemoveSendPasswordError = isRemoveSendPasswordError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isRenewFileUploadUrlError(error) {
    try {
        const ret = wasm.isRenewFileUploadUrlError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isRenewFileUploadUrlError = isRenewFileUploadUrlError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isRequestError(error) {
    try {
        const ret = wasm.isRequestError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isRequestError = isRequestError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isRestoreCipherAdminError(error) {
    try {
        const ret = wasm.isRestoreCipherAdminError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isRestoreCipherAdminError = isRestoreCipherAdminError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isRestoreCipherError(error) {
    try {
        const ret = wasm.isRestoreCipherError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isRestoreCipherError = isRestoreCipherError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isRotateCryptographyStateError(error) {
    try {
        const ret = wasm.isRotateCryptographyStateError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isRotateCryptographyStateError = isRotateCryptographyStateError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isRotateUserKeysError(error) {
    try {
        const ret = wasm.isRotateUserKeysError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isRotateUserKeysError = isRotateUserKeysError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isSendAccessDecryptError(error) {
    try {
        const ret = wasm.isSendAccessDecryptError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isSendAccessDecryptError = isSendAccessDecryptError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isSendAccessKeyError(error) {
    try {
        const ret = wasm.isSendAccessKeyError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isSendAccessKeyError = isSendAccessKeyError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isSendDecryptError(error) {
    try {
        const ret = wasm.isSendDecryptError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isSendDecryptError = isSendDecryptError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isSendEncryptError(error) {
    try {
        const ret = wasm.isSendEncryptError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isSendEncryptError = isSendEncryptError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isSendSyncError(error) {
    try {
        const ret = wasm.isSendSyncError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isSendSyncError = isSendSyncError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isServerCommunicationConfigRepositoryError(error) {
    try {
        const ret = wasm.isServerCommunicationConfigRepositoryError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isServerCommunicationConfigRepositoryError = isServerCommunicationConfigRepositoryError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isSshKeyExportError(error) {
    try {
        const ret = wasm.isSshKeyExportError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isSshKeyExportError = isSshKeyExportError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isSshKeyImportError(error) {
    try {
        const ret = wasm.isSshKeyImportError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isSshKeyImportError = isSshKeyImportError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isStateRegistryError(error) {
    try {
        const ret = wasm.isStateRegistryError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isStateRegistryError = isStateRegistryError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isStatefulCryptoError(error) {
    try {
        const ret = wasm.isStatefulCryptoError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isStatefulCryptoError = isStatefulCryptoError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isSubscribeError(error) {
    try {
        const ret = wasm.isSubscribeError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isSubscribeError = isSubscribeError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isSyncError(error) {
    try {
        const ret = wasm.isSyncError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isSyncError = isSyncError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isTestError(error) {
    try {
        const ret = wasm.isTestError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isTestError = isTestError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isTotpError(error) {
    try {
        const ret = wasm.isTotpError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isTotpError = isTotpError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isTypedReceiveError(error) {
    try {
        const ret = wasm.isTypedReceiveError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isTypedReceiveError = isTypedReceiveError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isUploadSendFileError(error) {
    try {
        const ret = wasm.isUploadSendFileError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isUploadSendFileError = isUploadSendFileError;

/**
 * @param {any} error
 * @returns {boolean}
 */
function isUsernameError(error) {
    try {
        const ret = wasm.isUsernameError(addBorrowedObject(error));
        return ret !== 0;
    } finally {
        heap[stack_pointer++] = undefined;
    }
}
exports.isUsernameError = isUsernameError;

/**
 * Pure set-union merge for two journals belonging to the same stable connection.
 * @param {AliasJournal} left
 * @param {AliasJournal} right
 * @returns {AliasJournal}
 */
function merge_alias_journals(left, right) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.merge_alias_journals(retptr, addHeapObject(left), addHeapObject(right));
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
        if (r2) {
            throw takeObject(r1);
        }
        return takeObject(r0);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}
exports.merge_alias_journals = merge_alias_journals;

/**
 * Parses and validates a canonical v1 alias reference without exposing its payload in errors.
 * @param {string} value
 * @returns {AliasReference}
 */
function parse_alias_reference(value) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0(value, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.parse_alias_reference(retptr, ptr0, len0);
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
        if (r2) {
            throw takeObject(r1);
        }
        return takeObject(r0);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}
exports.parse_alias_reference = parse_alias_reference;

/**
 * Computes a deterministic, read-only reconciliation plan for one stable connection.
 * @param {string} connection_id
 * @param {Alias[]} aliases
 * @param {CipherView[]} ciphers
 * @returns {AliasReconciliationPlan}
 */
function plan_alias_reconciliation(connection_id, aliases, ciphers) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0(connection_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(aliases, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArrayJsValueToWasm0(ciphers, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        wasm.plan_alias_reconciliation(retptr, ptr0, len0, ptr1, len1, ptr2, len2);
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
        if (r2) {
            throw takeObject(r1);
        }
        return takeObject(r0);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}
exports.plan_alias_reconciliation = plan_alias_reconciliation;

/**
 * Pure deterministic reduction of canonical journal facts into operation and resource state.
 * @param {AliasJournal} journal
 * @returns {AliasJournalState}
 */
function reduce_alias_journal(journal) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.reduce_alias_journal(retptr, addHeapObject(journal));
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
        if (r2) {
            throw takeObject(r1);
        }
        return takeObject(r0);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}
exports.reduce_alias_journal = reduce_alias_journal;

/**
 * Re-serializes a parsed reference into the one canonical JSON representation.
 * @param {AliasReference} reference
 * @returns {string}
 */
function serialize_alias_reference(reference) {
    let deferred2_0;
    let deferred2_1;
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.serialize_alias_reference(retptr, addHeapObject(reference));
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
        var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
        var ptr1 = r0;
        var len1 = r1;
        if (r3) {
            ptr1 = 0; len1 = 0;
            throw takeObject(r2);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}
exports.serialize_alias_reference = serialize_alias_reference;

function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg_Error_83742b46f01ce22d: function(arg0, arg1) {
            const ret = Error(getStringFromWasm0(arg0, arg1));
            return addHeapObject(ret);
        },
        __wbg_Number_a5a435bd7bbec835: function(arg0) {
            const ret = Number(getObject(arg0));
            return ret;
        },
        __wbg_String_8564e559799eccda: function(arg0, arg1) {
            const ret = String(getObject(arg1));
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_bigint_get_as_i64_447a76b5c6ef7bda: function(arg0, arg1) {
            const v = getObject(arg1);
            const ret = typeof(v) === 'bigint' ? v : undefined;
            getDataViewMemory0().setBigInt64(arg0 + 8 * 1, isLikeNone(ret) ? BigInt(0) : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_boolean_get_c0f3f60bac5a78d1: function(arg0) {
            const v = getObject(arg0);
            const ret = typeof(v) === 'boolean' ? v : undefined;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg___wbindgen_debug_string_5398f5bb970e0daa: function(arg0, arg1) {
            const ret = debugString(getObject(arg1));
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_in_41dbb8413020e076: function(arg0, arg1) {
            const ret = getObject(arg0) in getObject(arg1);
            return ret;
        },
        __wbg___wbindgen_is_bigint_e2141d4f045b7eda: function(arg0) {
            const ret = typeof(getObject(arg0)) === 'bigint';
            return ret;
        },
        __wbg___wbindgen_is_function_3c846841762788c1: function(arg0) {
            const ret = typeof(getObject(arg0)) === 'function';
            return ret;
        },
        __wbg___wbindgen_is_null_0b605fc6b167c56f: function(arg0) {
            const ret = getObject(arg0) === null;
            return ret;
        },
        __wbg___wbindgen_is_object_781bc9f159099513: function(arg0) {
            const val = getObject(arg0);
            const ret = typeof(val) === 'object' && val !== null;
            return ret;
        },
        __wbg___wbindgen_is_string_7ef6b97b02428fae: function(arg0) {
            const ret = typeof(getObject(arg0)) === 'string';
            return ret;
        },
        __wbg___wbindgen_is_undefined_52709e72fb9f179c: function(arg0) {
            const ret = getObject(arg0) === undefined;
            return ret;
        },
        __wbg___wbindgen_jsval_eq_ee31bfad3e536463: function(arg0, arg1) {
            const ret = getObject(arg0) === getObject(arg1);
            return ret;
        },
        __wbg___wbindgen_jsval_loose_eq_5bcc3bed3c69e72b: function(arg0, arg1) {
            const ret = getObject(arg0) == getObject(arg1);
            return ret;
        },
        __wbg___wbindgen_number_get_34bb9d9dcfa21373: function(arg0, arg1) {
            const obj = getObject(arg1);
            const ret = typeof(obj) === 'number' ? obj : undefined;
            getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_string_get_395e606bd0ee4427: function(arg0, arg1) {
            const obj = getObject(arg1);
            const ret = typeof(obj) === 'string' ? obj : undefined;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_throw_6ddd609b62940d55: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg__wbg_cb_unref_6b5b6b8576d35cb1: function(arg0) {
            getObject(arg0)._wbg_cb_unref();
        },
        __wbg_abort_5ef96933660780b7: function(arg0) {
            getObject(arg0).abort();
        },
        __wbg_abort_60dcb252ae0031fc: function() { return handleError(function (arg0) {
            getObject(arg0).abort();
        }, arguments); },
        __wbg_abort_6479c2d794ebf2ee: function(arg0, arg1) {
            getObject(arg0).abort(getObject(arg1));
        },
        __wbg_acquireCookies_885af914fa9a89b1: function() { return handleError(function (arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).acquireCookies(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_addEventListener_3d8de3b0a3355b64: function(arg0, arg1, arg2, arg3) {
            getObject(arg0).addEventListener(getStringFromWasm0(arg1, arg2), getObject(arg3));
        },
        __wbg_append_48b3d4fc4c97ab8d: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
            getObject(arg0).append(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
        }, arguments); },
        __wbg_append_608dfb635ee8998f: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
            getObject(arg0).append(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
        }, arguments); },
        __wbg_append_83e47d4b428d97aa: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            getObject(arg0).append(getStringFromWasm0(arg1, arg2), getObject(arg3));
        }, arguments); },
        __wbg_append_bbf73d7e78ce268c: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4, arg5) {
            getObject(arg0).append(getStringFromWasm0(arg1, arg2), getObject(arg3), getStringFromWasm0(arg4, arg5));
        }, arguments); },
        __wbg_apply_ac9afb97ca32f169: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = getObject(arg0).apply(getObject(arg1), getObject(arg2));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_arrayBuffer_eb8e9ca620af2a19: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).arrayBuffer();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_authenticate_biometrics_351ee7a7bb4da23d: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).authenticate_biometrics();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_body_ac1dad652946e6da: function(arg0) {
            const ret = getObject(arg0).body;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        },
        __wbg_buffer_60b8043cd926067d: function(arg0) {
            const ret = getObject(arg0).buffer;
            return addHeapObject(ret);
        },
        __wbg_byobRequest_6342e5f2b232c0f9: function(arg0) {
            const ret = getObject(arg0).byobRequest;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        },
        __wbg_byteLength_607b856aa6c5a508: function(arg0) {
            const ret = getObject(arg0).byteLength;
            return ret;
        },
        __wbg_byteOffset_b26b63681c83856c: function(arg0) {
            const ret = getObject(arg0).byteOffset;
            return ret;
        },
        __wbg_call_2d781c1f4d5c0ef8: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = getObject(arg0).call(getObject(arg1), getObject(arg2));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_call_e133b57c9155d22c: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).call(getObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_cancel_79b3bea07a1028e7: function(arg0) {
            const ret = getObject(arg0).cancel();
            return addHeapObject(ret);
        },
        __wbg_catch_d7ed0375ab6532a5: function(arg0, arg1) {
            const ret = getObject(arg0).catch(getObject(arg1));
            return addHeapObject(ret);
        },
        __wbg_cipher_b79b345295c0d165: function(arg0) {
            const ret = getObject(arg0).cipher;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        },
        __wbg_clearTimeout_333bba87532ab9d3: function(arg0) {
            const ret = clearTimeout(takeObject(arg0));
            return addHeapObject(ret);
        },
        __wbg_clearTimeout_3629d6209dfcc46e: function(arg0) {
            const ret = clearTimeout(takeObject(arg0));
            return addHeapObject(ret);
        },
        __wbg_clear_1885f7bf35006b0c: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).clear();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_clear_account_cryptographic_state_d24691e2f188bcc5: function(arg0) {
            const ret = getObject(arg0).clear_account_cryptographic_state();
            return addHeapObject(ret);
        },
        __wbg_clear_encrypted_pin_71bf85f1d7414e45: function(arg0) {
            const ret = getObject(arg0).clear_encrypted_pin();
            return addHeapObject(ret);
        },
        __wbg_clear_ephemeral_pin_envelope_cb708c379bdf22e7: function(arg0) {
            const ret = getObject(arg0).clear_ephemeral_pin_envelope();
            return addHeapObject(ret);
        },
        __wbg_clear_kdf_config_ca1f225e7d72c3a3: function(arg0) {
            const ret = getObject(arg0).clear_kdf_config();
            return addHeapObject(ret);
        },
        __wbg_clear_masterpassword_unlock_data_0b51c4c2827a6cf9: function(arg0) {
            const ret = getObject(arg0).clear_masterpassword_unlock_data();
            return addHeapObject(ret);
        },
        __wbg_clear_persistent_pin_envelope_9af9ce9923a7b3e6: function(arg0) {
            const ret = getObject(arg0).clear_persistent_pin_envelope();
            return addHeapObject(ret);
        },
        __wbg_clear_user_key_271853b8a695d882: function(arg0) {
            const ret = getObject(arg0).clear_user_key();
            return addHeapObject(ret);
        },
        __wbg_clear_user_key_id_4730e1f79988e200: function(arg0) {
            const ret = getObject(arg0).clear_user_key_id();
            return addHeapObject(ret);
        },
        __wbg_clear_v2_encrypted_migrations_grace_period_start_530e7763f685b4f5: function(arg0) {
            const ret = getObject(arg0).clear_v2_encrypted_migrations_grace_period_start();
            return addHeapObject(ret);
        },
        __wbg_clear_v2_upgrade_token_c6d1a4582707adc3: function(arg0) {
            const ret = getObject(arg0).clear_v2_upgrade_token();
            return addHeapObject(ret);
        },
        __wbg_clear_webauthn_prf_unlock_data_9874964548144716: function(arg0) {
            const ret = getObject(arg0).clear_webauthn_prf_unlock_data();
            return addHeapObject(ret);
        },
        __wbg_close_690d36108c557337: function() { return handleError(function (arg0) {
            getObject(arg0).close();
        }, arguments); },
        __wbg_close_737b4b1fbc658540: function() { return handleError(function (arg0) {
            getObject(arg0).close();
        }, arguments); },
        __wbg_close_cbf870bdad0aad99: function(arg0) {
            getObject(arg0).close();
        },
        __wbg_collectionviewnodeitem_new: function(arg0) {
            const ret = CollectionViewNodeItem.__wrap(arg0);
            return addHeapObject(ret);
        },
        __wbg_create_e9e35ffcb49d7084: function(arg0) {
            const ret = Object.create(getObject(arg0));
            return addHeapObject(ret);
        },
        __wbg_debug_271c16e6de0bc226: function(arg0, arg1, arg2, arg3) {
            console.debug(getObject(arg0), getObject(arg1), getObject(arg2), getObject(arg3));
        },
        __wbg_debug_4b9b1a2d5972be57: function(arg0) {
            console.debug(getObject(arg0));
        },
        __wbg_delete_40db93c05c546fb9: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).delete(getObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_done_08ce71ee07e3bd17: function(arg0) {
            const ret = getObject(arg0).done;
            return ret;
        },
        __wbg_enqueue_ec3552838b4b7fbf: function() { return handleError(function (arg0, arg1) {
            getObject(arg0).enqueue(getObject(arg1));
        }, arguments); },
        __wbg_entries_5b8fe91cea59610e: function(arg0) {
            const ret = getObject(arg0).entries();
            return addHeapObject(ret);
        },
        __wbg_entries_e8a20ff8c9757101: function(arg0) {
            const ret = Object.entries(getObject(arg0));
            return addHeapObject(ret);
        },
        __wbg_error_1eece6b0039034ce: function(arg0, arg1, arg2, arg3) {
            console.error(getObject(arg0), getObject(arg1), getObject(arg2), getObject(arg3));
        },
        __wbg_error_74898554122344a8: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).error;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        }, arguments); },
        __wbg_error_8d9a8e04cd1d3588: function(arg0) {
            console.error(getObject(arg0));
        },
        __wbg_error_a6fa202b58aa1cd3: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.error(getStringFromWasm0(arg0, arg1));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_fetch_074561c3e313c86f: function(arg0) {
            const ret = fetch(getObject(arg0));
            return addHeapObject(ret);
        },
        __wbg_fetch_5550a88cf343aaa9: function(arg0, arg1) {
            const ret = getObject(arg0).fetch(getObject(arg1));
            return addHeapObject(ret);
        },
        __wbg_folder_95e4c1ad9a66ef08: function(arg0) {
            const ret = getObject(arg0).folder;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        },
        __wbg_from_4bdf88943703fd48: function(arg0) {
            const ret = Array.from(getObject(arg0));
            return addHeapObject(ret);
        },
        __wbg_getAll_690f659b57ae2d51: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).getAll();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_getFullYear_f6d84c054eee1543: function(arg0) {
            const ret = getObject(arg0).getFullYear();
            return ret;
        },
        __wbg_getRandomValues_cc7f052a444bb2ce: function() { return handleError(function (arg0, arg1) {
            globalThis.crypto.getRandomValues(getArrayU8FromWasm0(arg0, arg1));
        }, arguments); },
        __wbg_getRandomValues_ceb34d8ffce7e87f: function() { return handleError(function (arg0, arg1) {
            globalThis.crypto.getRandomValues(getArrayU8FromWasm0(arg0, arg1));
        }, arguments); },
        __wbg_getReader_9facd4f899beac89: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).getReader();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_getTime_1dad7b5386ddd2d9: function(arg0) {
            const ret = getObject(arg0).getTime();
            return ret;
        },
        __wbg_get_0d4ff3c0a439bf5d: function() { return handleError(function (arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).get(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_get_326e41e095fb2575: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(getObject(arg0), getObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_get_3ef1eba1850ade27: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(getObject(arg0), getObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_get_417b576752f76b04: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).get(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_get_5eff6444a359c7d9: function() { return handleError(function (arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).get(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_get_6ac8c8119f577720: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).get(getObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_get_702e1c5c48489288: function() { return handleError(function (arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).get(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_get_75a5c950dbac6807: function() { return handleError(function (arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).get(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_get_a8ee5c45dabc1b3b: function(arg0, arg1) {
            const ret = getObject(arg0)[arg1 >>> 0];
            return addHeapObject(ret);
        },
        __wbg_get_access_token_d8305d5af06f10eb: function(arg0) {
            const ret = getObject(arg0).get_access_token();
            return addHeapObject(ret);
        },
        __wbg_get_account_cryptographic_state_0c9b64fd91a07b73: function(arg0) {
            const ret = getObject(arg0).get_account_cryptographic_state();
            return addHeapObject(ret);
        },
        __wbg_get_biometrics_status_7440f7f0874c6044: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).get_biometrics_status(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_get_c9bda7efc6284f90: function() { return handleError(function (arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).get(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_get_ccc545ead540bca9: function() { return handleError(function (arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).get(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_get_client_name_9cd0c5575296f1b2: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).get_client_name();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_get_done_d0ab690f8df5501f: function(arg0) {
            const ret = getObject(arg0).done;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg_get_encrypted_pin_05411136d124139d: function(arg0) {
            const ret = getObject(arg0).get_encrypted_pin();
            return addHeapObject(ret);
        },
        __wbg_get_ephemeral_pin_envelope_f4be0da59411d0fa: function(arg0) {
            const ret = getObject(arg0).get_ephemeral_pin_envelope();
            return addHeapObject(ret);
        },
        __wbg_get_kdf_config_6019fae791cde2a6: function(arg0) {
            const ret = getObject(arg0).get_kdf_config();
            return addHeapObject(ret);
        },
        __wbg_get_masterpassword_unlock_data_06171cf90ccde503: function(arg0) {
            const ret = getObject(arg0).get_masterpassword_unlock_data();
            return addHeapObject(ret);
        },
        __wbg_get_persistent_pin_envelope_8db7ede9792f9a10: function(arg0) {
            const ret = getObject(arg0).get_persistent_pin_envelope();
            return addHeapObject(ret);
        },
        __wbg_get_unchecked_329cfe50afab7352: function(arg0, arg1) {
            const ret = getObject(arg0)[arg1 >>> 0];
            return addHeapObject(ret);
        },
        __wbg_get_user_key_08f334b2f58bb3e6: function(arg0) {
            const ret = getObject(arg0).get_user_key();
            return addHeapObject(ret);
        },
        __wbg_get_user_key_id_c11cc58b27b0401d: function(arg0) {
            const ret = getObject(arg0).get_user_key_id();
            return addHeapObject(ret);
        },
        __wbg_get_v2_encrypted_migrations_grace_period_start_78c54d6d821ffcf6: function(arg0) {
            const ret = getObject(arg0).get_v2_encrypted_migrations_grace_period_start();
            return addHeapObject(ret);
        },
        __wbg_get_v2_upgrade_token_01248971e9bc249a: function(arg0) {
            const ret = getObject(arg0).get_v2_upgrade_token();
            return addHeapObject(ret);
        },
        __wbg_get_value_548ae6adf5a174e4: function(arg0) {
            const ret = getObject(arg0).value;
            return addHeapObject(ret);
        },
        __wbg_get_vault_url_24ef944d1c433b8b: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).get_vault_url(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_get_webauthn_prf_unlock_data_d269f0a6bd73867b: function(arg0) {
            const ret = getObject(arg0).get_webauthn_prf_unlock_data();
            return addHeapObject(ret);
        },
        __wbg_get_with_ref_key_6412cf3094599694: function(arg0, arg1) {
            const ret = getObject(arg0)[getObject(arg1)];
            return addHeapObject(ret);
        },
        __wbg_has_926ef2ff40b308cf: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.has(getObject(arg0), getObject(arg1));
            return ret;
        }, arguments); },
        __wbg_headers_eb2234545f9ff993: function(arg0) {
            const ret = getObject(arg0).headers;
            return addHeapObject(ret);
        },
        __wbg_incomingmessage_new: function(arg0) {
            const ret = IncomingMessage.__wrap(arg0);
            return addHeapObject(ret);
        },
        __wbg_info_0194681687b5ab04: function(arg0, arg1, arg2, arg3) {
            console.info(getObject(arg0), getObject(arg1), getObject(arg2), getObject(arg3));
        },
        __wbg_info_7d4e223bb1a7e671: function(arg0) {
            console.info(getObject(arg0));
        },
        __wbg_instanceof_ArrayBuffer_101e2bf31071a9f6: function(arg0) {
            let result;
            try {
                result = getObject(arg0) instanceof ArrayBuffer;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_DomException_2bdcf7791a2d7d09: function(arg0) {
            let result;
            try {
                result = getObject(arg0) instanceof DOMException;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_IdbRequest_6a0e24572d4f1d46: function(arg0) {
            let result;
            try {
                result = getObject(arg0) instanceof IDBRequest;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Map_f194b366846aca0c: function(arg0) {
            let result;
            try {
                result = getObject(arg0) instanceof Map;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Response_9b4d9fd451e051b1: function(arg0) {
            let result;
            try {
                result = getObject(arg0) instanceof Response;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Uint8Array_740438561a5b956d: function(arg0) {
            let result;
            try {
                result = getObject(arg0) instanceof Uint8Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_ipcclientsubscription_new: function(arg0) {
            const ret = IpcClientSubscription.__wrap(arg0);
            return addHeapObject(ret);
        },
        __wbg_isArray_33b91feb269ff46e: function(arg0) {
            const ret = Array.isArray(getObject(arg0));
            return ret;
        },
        __wbg_isSafeInteger_ecd6a7f9c3e053cd: function(arg0) {
            const ret = Number.isSafeInteger(getObject(arg0));
            return ret;
        },
        __wbg_iterator_d8f549ec8fb061b1: function() {
            const ret = Symbol.iterator;
            return addHeapObject(ret);
        },
        __wbg_length_b3416cf66a5452c8: function(arg0) {
            const ret = getObject(arg0).length;
            return ret;
        },
        __wbg_length_ea16607d7b61445b: function(arg0) {
            const ret = getObject(arg0).length;
            return ret;
        },
        __wbg_list_157f26a4e3cbc5ca: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).list();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_list_24528b1aefdc1adb: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).list();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_list_7b80e74fa17dd2b3: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).list();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_list_857601801eb31738: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).list();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_list_ae963dab7703d840: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).list();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_list_users_ffbaeb1cdfb59680: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).list_users();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_local_user_data_key_state_61824f72b1a4ef5a: function(arg0) {
            const ret = getObject(arg0).local_user_data_key_state;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        },
        __wbg_lock_user_b204349d2e0e9452: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).lock_user(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_mark_310e9a031ccc84ff: function() { return handleError(function (arg0, arg1, arg2) {
            getObject(arg0).mark(getStringFromWasm0(arg1, arg2));
        }, arguments); },
        __wbg_mark_742962d66a858cc5: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            getObject(arg0).mark(getStringFromWasm0(arg1, arg2), getObject(arg3));
        }, arguments); },
        __wbg_measure_54743279e77e77bb: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
            getObject(arg0).measure(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4), getStringFromWasm0(arg5, arg6));
        }, arguments); },
        __wbg_measure_cd1f7667d5f5517d: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            getObject(arg0).measure(getStringFromWasm0(arg1, arg2), getObject(arg3));
        }, arguments); },
        __wbg_name_7a3bbd030d0afa16: function(arg0, arg1) {
            const ret = getObject(arg1).name;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_new_0837727332ac86ba: function() { return handleError(function () {
            const ret = new Headers();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_new_0_1dcafdf5e786e876: function() {
            const ret = new Date();
            return addHeapObject(ret);
        },
        __wbg_new_227d7c05414eb861: function() {
            const ret = new Error();
            return addHeapObject(ret);
        },
        __wbg_new_49d5571bd3f0c4d4: function() {
            const ret = new Map();
            return addHeapObject(ret);
        },
        __wbg_new_5cfc6a14488ab25a: function() { return handleError(function () {
            const ret = new FormData();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_new_5f486cdf45a04d78: function(arg0) {
            const ret = new Uint8Array(getObject(arg0));
            return addHeapObject(ret);
        },
        __wbg_new_98e187f8aa8916fe: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                const ret = new Error(getStringFromWasm0(arg0, arg1));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_new_a70fbab9066b301f: function() {
            const ret = new Array();
            return addHeapObject(ret);
        },
        __wbg_new_ab79df5bd7c26067: function() {
            const ret = new Object();
            return addHeapObject(ret);
        },
        __wbg_new_c518c60af666645b: function() { return handleError(function () {
            const ret = new AbortController();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_new_d15cb560a6a0e5f0: function(arg0, arg1) {
            const ret = new Error(getStringFromWasm0(arg0, arg1));
            return addHeapObject(ret);
        },
        __wbg_new_from_slice_22da9388ac046e50: function(arg0, arg1) {
            const ret = new Uint8Array(getArrayU8FromWasm0(arg0, arg1));
            return addHeapObject(ret);
        },
        __wbg_new_typed_aaaeaf29cf802876: function(arg0, arg1) {
            try {
                var state0 = {a: arg0, b: arg1};
                var cb0 = (arg0, arg1) => {
                    const a = state0.a;
                    state0.a = 0;
                    try {
                        return wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___js_sys_edf1db4c96748966___Function_fn_wasm_bindgen_e2bd5c2e47c01711___JsValue_____wasm_bindgen_e2bd5c2e47c01711___sys__Undefined___js_sys_edf1db4c96748966___Function_fn_wasm_bindgen_e2bd5c2e47c01711___JsValue_____wasm_bindgen_e2bd5c2e47c01711___sys__Undefined_______true_(a, state0.b, arg0, arg1);
                    } finally {
                        state0.a = a;
                    }
                };
                const ret = new Promise(cb0);
                return addHeapObject(ret);
            } finally {
                state0.a = state0.b = 0;
            }
        },
        __wbg_new_with_byte_offset_and_length_b2ec5bf7b2f35743: function(arg0, arg1, arg2) {
            const ret = new Uint8Array(getObject(arg0), arg1 >>> 0, arg2 >>> 0);
            return addHeapObject(ret);
        },
        __wbg_new_with_length_3259a525196bd8cc: function(arg0) {
            const ret = new Array(arg0 >>> 0);
            return addHeapObject(ret);
        },
        __wbg_new_with_length_825018a1616e9e55: function(arg0) {
            const ret = new Uint8Array(arg0 >>> 0);
            return addHeapObject(ret);
        },
        __wbg_new_with_str_and_init_b4b54d1a819bc724: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = new Request(getStringFromWasm0(arg0, arg1), getObject(arg2));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_new_with_u8_array_sequence_and_options_de38f663e19ad899: function() { return handleError(function (arg0, arg1) {
            const ret = new Blob(getObject(arg0), getObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_next_11b99ee6237339e3: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).next();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_next_e01a967809d1aa68: function(arg0) {
            const ret = getObject(arg0).next;
            return addHeapObject(ret);
        },
        __wbg_now_16f0c993d5dd6c27: function() {
            const ret = Date.now();
            return ret;
        },
        __wbg_now_c6d7a7d35f74f6f1: function(arg0) {
            const ret = getObject(arg0).now();
            return ret;
        },
        __wbg_now_e7c6795a7f81e10f: function(arg0) {
            const ret = getObject(arg0).now();
            return ret;
        },
        __wbg_objectStore_f314ab152a5c7bd0: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = getObject(arg0).objectStore(getStringFromWasm0(arg1, arg2));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_organization_shared_key_af052c266ba512ed: function(arg0) {
            const ret = getObject(arg0).organization_shared_key;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        },
        __wbg_parse_e9eddd2a82c706eb: function() { return handleError(function (arg0, arg1) {
            const ret = JSON.parse(getStringFromWasm0(arg0, arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_performance_3fcf6e32a7e1ed0a: function(arg0) {
            const ret = getObject(arg0).performance;
            return addHeapObject(ret);
        },
        __wbg_performance_757310249566272b: function() {
            const ret = globalThis.performance;
            return addHeapObject(ret);
        },
        __wbg_preventDefault_25a229bfe5c510f8: function(arg0) {
            getObject(arg0).preventDefault();
        },
        __wbg_prototypesetcall_d62e5099504357e6: function(arg0, arg1, arg2) {
            Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), getObject(arg2));
        },
        __wbg_push_e87b0e732085a946: function(arg0, arg1) {
            const ret = getObject(arg0).push(getObject(arg1));
            return ret;
        },
        __wbg_put_f1673d719f93ce22: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = getObject(arg0).put(getObject(arg1), getObject(arg2));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_queueMicrotask_0c399741342fb10f: function(arg0) {
            const ret = getObject(arg0).queueMicrotask;
            return addHeapObject(ret);
        },
        __wbg_queueMicrotask_a082d78ce798393e: function(arg0) {
            queueMicrotask(getObject(arg0));
        },
        __wbg_read_7f593a961a7f80ed: function(arg0) {
            const ret = getObject(arg0).read();
            return addHeapObject(ret);
        },
        __wbg_releaseLock_ef7766a5da654ff8: function(arg0) {
            getObject(arg0).releaseLock();
        },
        __wbg_removeAll_0b1fc486184990b3: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).removeAll();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_removeAll_161f4437c34648bd: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).removeAll();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_removeAll_1c13d30fb02d042d: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).removeAll();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_removeAll_501f5d72c3814b76: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).removeAll();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_removeAll_68a9d576679adae2: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).removeAll();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_removeBulk_1b26c22aadfc870c: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).removeBulk(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_removeBulk_2ae2437779887725: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).removeBulk(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_removeBulk_9e807b7d504acb56: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).removeBulk(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_removeBulk_d90dd4e7d7eae1a4: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).removeBulk(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_removeBulk_e61482df730de0a6: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).removeBulk(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_remove_257e3436b7948e5c: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).remove(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_remove_2768455253f12c7a: function() { return handleError(function (arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).remove(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_remove_5f9ba73047c19d7e: function() { return handleError(function (arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).remove(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_remove_655f355902c62bc5: function() { return handleError(function (arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).remove(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_remove_80344d2315090906: function() { return handleError(function (arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).remove(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_remove_d517ea2221a21f00: function() { return handleError(function (arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).remove(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_resolve_ae8d83246e5bcc12: function(arg0) {
            const ret = Promise.resolve(getObject(arg0));
            return addHeapObject(ret);
        },
        __wbg_respond_e286ee502e7cf7e4: function() { return handleError(function (arg0, arg1) {
            getObject(arg0).respond(arg1 >>> 0);
        }, arguments); },
        __wbg_result_c5baa2d3d690a01a: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).result;
            return addHeapObject(ret);
        }, arguments); },
        __wbg_save_60aa257e5f92e97d: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).save(getStringFromWasm0(arg1, arg2), takeObject(arg3));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_save_6386e4c2a792df62: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = getObject(arg0).save(takeObject(arg1), takeObject(arg2));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_send_4162283e06171b1a: function(arg0) {
            const ret = getObject(arg0).send;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        },
        __wbg_send_dff48d066ea20b55: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).send(OutgoingMessage.__wrap(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_setBulk_2111fcafcf587417: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).setBulk(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_setBulk_4a1c4200d9f886cc: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).setBulk(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_setBulk_61d3714c7187eb7b: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).setBulk(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_setBulk_9e0ef9e60c35667b: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).setBulk(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_setBulk_ec0e1d0255ea5744: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).setBulk(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_setTimeout_3a808dd861dd3c12: function(arg0, arg1) {
            const ret = setTimeout(getObject(arg0), arg1);
            return addHeapObject(ret);
        },
        __wbg_setTimeout_56bcdccbad22fd44: function() { return handleError(function (arg0, arg1) {
            const ret = setTimeout(getObject(arg0), arg1);
            return addHeapObject(ret);
        }, arguments); },
        __wbg_set_282384002438957f: function(arg0, arg1, arg2) {
            getObject(arg0)[arg1 >>> 0] = takeObject(arg2);
        },
        __wbg_set_3f83707b37bbab7f: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).set(getStringFromWasm0(arg1, arg2), takeObject(arg3));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_set_557e8fe9f7a8b59e: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).set(getStringFromWasm0(arg1, arg2), takeObject(arg3));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_set_6be42768c690e380: function(arg0, arg1, arg2) {
            getObject(arg0)[takeObject(arg1)] = takeObject(arg2);
        },
        __wbg_set_7eaa4f96924fd6b3: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = Reflect.set(getObject(arg0), getObject(arg1), getObject(arg2));
            return ret;
        }, arguments); },
        __wbg_set_8c0b3ffcf05d61c2: function(arg0, arg1, arg2) {
            getObject(arg0).set(getArrayU8FromWasm0(arg1, arg2));
        },
        __wbg_set_account_cryptographic_state_a074784ff2f86543: function(arg0, arg1) {
            const ret = getObject(arg0).set_account_cryptographic_state(takeObject(arg1));
            return addHeapObject(ret);
        },
        __wbg_set_ad9c4f567a69390f: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).set(getStringFromWasm0(arg1, arg2), takeObject(arg3));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_set_b0c4371cc6471ebb: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).set(getStringFromWasm0(arg1, arg2), takeObject(arg3));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_set_bf7251625df30a02: function(arg0, arg1, arg2) {
            const ret = getObject(arg0).set(getObject(arg1), getObject(arg2));
            return addHeapObject(ret);
        },
        __wbg_set_body_a3d856b097dfda04: function(arg0, arg1) {
            getObject(arg0).body = getObject(arg1);
        },
        __wbg_set_cache_ec7e430c6056ebda: function(arg0, arg1) {
            getObject(arg0).cache = __wbindgen_enum_RequestCache[arg1];
        },
        __wbg_set_credentials_ed63183445882c65: function(arg0, arg1) {
            getObject(arg0).credentials = __wbindgen_enum_RequestCredentials[arg1];
        },
        __wbg_set_d54864d0fc05071e: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).set(getStringFromWasm0(arg1, arg2), takeObject(arg3));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_set_encrypted_pin_34ada8a1153de63c: function(arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).set_encrypted_pin(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_set_ephemeral_pin_envelope_042d02d71b441b25: function(arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).set_ephemeral_pin_envelope(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_set_headers_3c8fecc693b75327: function(arg0, arg1) {
            getObject(arg0).headers = getObject(arg1);
        },
        __wbg_set_kdf_config_79183cc3d5267a88: function(arg0, arg1) {
            const ret = getObject(arg0).set_kdf_config(takeObject(arg1));
            return addHeapObject(ret);
        },
        __wbg_set_masterpassword_unlock_data_1c95fb9bc42b96cc: function(arg0, arg1) {
            const ret = getObject(arg0).set_masterpassword_unlock_data(takeObject(arg1));
            return addHeapObject(ret);
        },
        __wbg_set_method_8c015e8bcafd7be1: function(arg0, arg1, arg2) {
            getObject(arg0).method = getStringFromWasm0(arg1, arg2);
        },
        __wbg_set_mode_5a87f2c809cf37c2: function(arg0, arg1) {
            getObject(arg0).mode = __wbindgen_enum_RequestMode[arg1];
        },
        __wbg_set_name_55070a3388f8b72f: function(arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                getObject(arg0).name = getStringFromWasm0(arg1, arg2);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_set_name_7ef37fe858379aaf: function(arg0, arg1, arg2) {
            getObject(arg0).name = getStringFromWasm0(arg1, arg2);
        },
        __wbg_set_onerror_8a268cb237177bba: function(arg0, arg1) {
            getObject(arg0).onerror = getObject(arg1);
        },
        __wbg_set_onsuccess_fca94ded107b64af: function(arg0, arg1) {
            getObject(arg0).onsuccess = getObject(arg1);
        },
        __wbg_set_persistent_pin_envelope_d39b5c1abd31bab7: function(arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).set_persistent_pin_envelope(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_set_signal_0cebecb698f25d21: function(arg0, arg1) {
            getObject(arg0).signal = getObject(arg1);
        },
        __wbg_set_type_33e79f1b45a78c37: function(arg0, arg1, arg2) {
            getObject(arg0).type = getStringFromWasm0(arg1, arg2);
        },
        __wbg_set_user_key_8abdbcc46cc6ad78: function(arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).set_user_key(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_set_user_key_id_dbdc7af2c05e46b4: function(arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                const ret = getObject(arg0).set_user_key_id(getStringFromWasm0(arg1, arg2));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_set_v2_encrypted_migrations_grace_period_start_815bd5ff11f3c9b3: function(arg0, arg1) {
            const ret = getObject(arg0).set_v2_encrypted_migrations_grace_period_start(takeObject(arg1));
            return addHeapObject(ret);
        },
        __wbg_set_v2_upgrade_token_409bc758f69738af: function(arg0, arg1) {
            const ret = getObject(arg0).set_v2_upgrade_token(takeObject(arg1));
            return addHeapObject(ret);
        },
        __wbg_set_variant_ff54f670c6ba7b2e: function(arg0, arg1, arg2) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg1;
                deferred0_1 = arg2;
                getObject(arg0).variant = getStringFromWasm0(arg1, arg2);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_set_webauthn_prf_unlock_data_b953bb3ee69ff431: function(arg0, arg1) {
            const ret = getObject(arg0).set_webauthn_prf_unlock_data(takeObject(arg1));
            return addHeapObject(ret);
        },
        __wbg_signal_166e1da31adcac18: function(arg0) {
            const ret = getObject(arg0).signal;
            return addHeapObject(ret);
        },
        __wbg_signal_1d082171358a3104: function(arg0) {
            const ret = getObject(arg0).signal;
            return addHeapObject(ret);
        },
        __wbg_slice_f3fd3c2bec9310f6: function(arg0, arg1, arg2) {
            const ret = getObject(arg0).slice(arg1 >>> 0, arg2 >>> 0);
            return addHeapObject(ret);
        },
        __wbg_stack_3b0d974bbf31e44f: function(arg0, arg1) {
            const ret = getObject(arg1).stack;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_static_accessor_GLOBAL_8adb955bd33fac2f: function() {
            const ret = typeof global === 'undefined' ? null : global;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        },
        __wbg_static_accessor_GLOBAL_THIS_ad356e0db91c7913: function() {
            const ret = typeof globalThis === 'undefined' ? null : globalThis;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        },
        __wbg_static_accessor_SELF_f207c857566db248: function() {
            const ret = typeof self === 'undefined' ? null : self;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        },
        __wbg_static_accessor_WINDOW_bb9f1ba69d61b386: function() {
            const ret = typeof window === 'undefined' ? null : window;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        },
        __wbg_static_accessor_performance_7f6ecf1ec56b9bbe: function() {
            const ret = performance;
            return addHeapObject(ret);
        },
        __wbg_status_318629ab93a22955: function(arg0) {
            const ret = getObject(arg0).status;
            return ret;
        },
        __wbg_stringify_5ae93966a84901ac: function() { return handleError(function (arg0) {
            const ret = JSON.stringify(getObject(arg0));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_subarray_a068d24e39478a8a: function(arg0, arg1, arg2) {
            const ret = getObject(arg0).subarray(arg1 >>> 0, arg2 >>> 0);
            return addHeapObject(ret);
        },
        __wbg_suppress_vault_timeout_27b3df935087e2a7: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = getObject(arg0).suppress_vault_timeout(takeObject(arg1), arg2);
            return addHeapObject(ret);
        }, arguments); },
        __wbg_target_7bc90f314634b37b: function(arg0) {
            const ret = getObject(arg0).target;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        },
        __wbg_text_372f5b91442c50f9: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).text();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_then_098abe61755d12f6: function(arg0, arg1) {
            const ret = getObject(arg0).then(getObject(arg1));
            return addHeapObject(ret);
        },
        __wbg_then_9e335f6dd892bc11: function(arg0, arg1, arg2) {
            const ret = getObject(arg0).then(getObject(arg1), getObject(arg2));
            return addHeapObject(ret);
        },
        __wbg_transaction_3223f7c8d0f40129: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = getObject(arg0).transaction(getObject(arg1), __wbindgen_enum_IdbTransactionMode[arg2]);
            return addHeapObject(ret);
        }, arguments); },
        __wbg_unlock_biometrics_ef9846ac18e3eae8: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).unlock_biometrics(takeObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_unlock_user_bbb3a44f2a0e9bae: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg2;
                deferred0_1 = arg3;
                const ret = getObject(arg0).unlock_user(takeObject(arg1), getStringFromWasm0(arg2, arg3));
                return addHeapObject(ret);
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        }, arguments); },
        __wbg_url_7fefc1820fba4e0c: function(arg0, arg1) {
            const ret = getObject(arg1).url;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_value_21fc78aab0322612: function(arg0) {
            const ret = getObject(arg0).value;
            return addHeapObject(ret);
        },
        __wbg_view_f68a712e7315f8b2: function(arg0) {
            const ret = getObject(arg0).view;
            return isLikeNone(ret) ? 0 : addHeapObject(ret);
        },
        __wbg_warn_69424c2d92a2fa73: function(arg0) {
            console.warn(getObject(arg0));
        },
        __wbg_warn_809cad1bfc2b3a42: function(arg0, arg1, arg2, arg3) {
            console.warn(getObject(arg0), getObject(arg1), getObject(arg2), getObject(arg3));
        },
        __wbindgen_cast_0000000000000001: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { dtor_idx: 262, function: Function { arguments: [NamedExternref("Event")], shim_idx: 263, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm.wasm_bindgen_e2bd5c2e47c01711___closure__destroy___dyn_core_d80f319693eeb575___ops__function__FnMut__web_sys_f7a780d7a7e7225e___features__gen_Event__Event____Output_______, wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___wasm_bindgen_e2bd5c2e47c01711___JsValue______true_);
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000002: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { dtor_idx: 382, function: Function { arguments: [Externref], shim_idx: 263, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm.wasm_bindgen_e2bd5c2e47c01711___closure__destroy___dyn_core_d80f319693eeb575___ops__function__FnMut__wasm_bindgen_e2bd5c2e47c01711___JsValue____Output___core_d80f319693eeb575___result__Result_____wasm_bindgen_e2bd5c2e47c01711___JsError___, wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___wasm_bindgen_e2bd5c2e47c01711___JsValue______true__1);
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000003: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { dtor_idx: 382, function: Function { arguments: [Externref], shim_idx: 437, ret: Result(Unit), inner_ret: Some(Result(Unit)) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm.wasm_bindgen_e2bd5c2e47c01711___closure__destroy___dyn_core_d80f319693eeb575___ops__function__FnMut__wasm_bindgen_e2bd5c2e47c01711___JsValue____Output___core_d80f319693eeb575___result__Result_____wasm_bindgen_e2bd5c2e47c01711___JsError___, wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___wasm_bindgen_e2bd5c2e47c01711___JsValue__core_d80f319693eeb575___result__Result_____wasm_bindgen_e2bd5c2e47c01711___JsError___true_);
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000004: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { dtor_idx: 382, function: Function { arguments: [], shim_idx: 453, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm.wasm_bindgen_e2bd5c2e47c01711___closure__destroy___dyn_core_d80f319693eeb575___ops__function__FnMut__wasm_bindgen_e2bd5c2e47c01711___JsValue____Output___core_d80f319693eeb575___result__Result_____wasm_bindgen_e2bd5c2e47c01711___JsError___, wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke_______true_);
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000005: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { dtor_idx: 436, function: Function { arguments: [NamedExternref("Array<any>")], shim_idx: 437, ret: Result(Unit), inner_ret: Some(Result(Unit)) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm.wasm_bindgen_e2bd5c2e47c01711___closure__destroy___dyn_core_d80f319693eeb575___ops__function__FnMut__js_sys_edf1db4c96748966___Array____Output___core_d80f319693eeb575___result__Result_____wasm_bindgen_e2bd5c2e47c01711___JsError___, wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___wasm_bindgen_e2bd5c2e47c01711___JsValue__core_d80f319693eeb575___result__Result_____wasm_bindgen_e2bd5c2e47c01711___JsError___true__4);
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000006: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { dtor_idx: 850, function: Function { arguments: [], shim_idx: 453, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm.wasm_bindgen_e2bd5c2e47c01711___closure__destroy___dyn_core_d80f319693eeb575___ops__function__FnMut_____Output_______, wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke_______true_);
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000007: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000008: function(arg0) {
            // Cast intrinsic for `I64 -> Externref`.
            const ret = arg0;
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000009: function(arg0, arg1) {
            // Cast intrinsic for `Ref(Slice(U8)) -> NamedExternref("Uint8Array")`.
            const ret = getArrayU8FromWasm0(arg0, arg1);
            return addHeapObject(ret);
        },
        __wbindgen_cast_000000000000000a: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return addHeapObject(ret);
        },
        __wbindgen_cast_000000000000000b: function(arg0) {
            // Cast intrinsic for `U64 -> Externref`.
            const ret = BigInt.asUintN(64, arg0);
            return addHeapObject(ret);
        },
        __wbindgen_cast_000000000000000c: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("AcquiredCookie")) -> Externref`.
            const ret = v0;
            return addHeapObject(ret);
        },
        __wbindgen_cast_000000000000000d: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("CipherListView")) -> Externref`.
            const ret = v0;
            return addHeapObject(ret);
        },
        __wbindgen_cast_000000000000000e: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("CipherRiskResult")) -> Externref`.
            const ret = v0;
            return addHeapObject(ret);
        },
        __wbindgen_cast_000000000000000f: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("CipherView")) -> Externref`.
            const ret = v0;
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000010: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("EncryptionContext")) -> Externref`.
            const ret = v0;
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000011: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("FolderView")) -> Externref`.
            const ret = v0;
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000012: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("OrganizationUserBulkResponse")) -> Externref`.
            const ret = v0;
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000013: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("SendView")) -> Externref`.
            const ret = v0;
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000014: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("V1EmergencyAccessMembership")) -> Externref`.
            const ret = v0;
            return addHeapObject(ret);
        },
        __wbindgen_cast_0000000000000015: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("V1OrganizationMembership")) -> Externref`.
            const ret = v0;
            return addHeapObject(ret);
        },
        __wbindgen_object_clone_ref: function(arg0) {
            const ret = getObject(arg0);
            return addHeapObject(ret);
        },
        __wbindgen_object_drop_ref: function(arg0) {
            takeObject(arg0);
        },
    };
    return {
        __proto__: null,
        "./bitwarden_wasm_internal_bg.js": import0,
    };
}

function wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke_______true_(arg0, arg1) {
    wasm.wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke_______true_(arg0, arg1);
}

function wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___wasm_bindgen_e2bd5c2e47c01711___JsValue______true_(arg0, arg1, arg2) {
    wasm.wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___wasm_bindgen_e2bd5c2e47c01711___JsValue______true_(arg0, arg1, addHeapObject(arg2));
}

function wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___wasm_bindgen_e2bd5c2e47c01711___JsValue______true__1(arg0, arg1, arg2) {
    wasm.wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___wasm_bindgen_e2bd5c2e47c01711___JsValue______true__1(arg0, arg1, addHeapObject(arg2));
}

function wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___wasm_bindgen_e2bd5c2e47c01711___JsValue__core_d80f319693eeb575___result__Result_____wasm_bindgen_e2bd5c2e47c01711___JsError___true_(arg0, arg1, arg2) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___wasm_bindgen_e2bd5c2e47c01711___JsValue__core_d80f319693eeb575___result__Result_____wasm_bindgen_e2bd5c2e47c01711___JsError___true_(retptr, arg0, arg1, addHeapObject(arg2));
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        if (r1) {
            throw takeObject(r0);
        }
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}

function wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___wasm_bindgen_e2bd5c2e47c01711___JsValue__core_d80f319693eeb575___result__Result_____wasm_bindgen_e2bd5c2e47c01711___JsError___true__4(arg0, arg1, arg2) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___wasm_bindgen_e2bd5c2e47c01711___JsValue__core_d80f319693eeb575___result__Result_____wasm_bindgen_e2bd5c2e47c01711___JsError___true__4(retptr, arg0, arg1, addHeapObject(arg2));
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        if (r1) {
            throw takeObject(r0);
        }
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}

function wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___js_sys_edf1db4c96748966___Function_fn_wasm_bindgen_e2bd5c2e47c01711___JsValue_____wasm_bindgen_e2bd5c2e47c01711___sys__Undefined___js_sys_edf1db4c96748966___Function_fn_wasm_bindgen_e2bd5c2e47c01711___JsValue_____wasm_bindgen_e2bd5c2e47c01711___sys__Undefined_______true_(arg0, arg1, arg2, arg3) {
    wasm.wasm_bindgen_e2bd5c2e47c01711___convert__closures_____invoke___js_sys_edf1db4c96748966___Function_fn_wasm_bindgen_e2bd5c2e47c01711___JsValue_____wasm_bindgen_e2bd5c2e47c01711___sys__Undefined___js_sys_edf1db4c96748966___Function_fn_wasm_bindgen_e2bd5c2e47c01711___JsValue_____wasm_bindgen_e2bd5c2e47c01711___sys__Undefined_______true_(arg0, arg1, addHeapObject(arg2), addHeapObject(arg3));
}


const __wbindgen_enum_IdbTransactionMode = ["readonly", "readwrite", "versionchange", "readwriteflush", "cleanup"];


const __wbindgen_enum_ReadableStreamType = ["bytes"];


const __wbindgen_enum_RequestCache = ["default", "no-store", "reload", "no-cache", "force-cache", "only-if-cached"];


const __wbindgen_enum_RequestCredentials = ["omit", "same-origin", "include"];


const __wbindgen_enum_RequestMode = ["same-origin", "no-cors", "cors", "navigate"];
const AliasClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_aliasclient_free(ptr >>> 0, 1));
const AttachmentAdminClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_attachmentadminclient_free(ptr >>> 0, 1));
const AttachmentsClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_attachmentsclient_free(ptr >>> 0, 1));
const AuthClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_authclient_free(ptr >>> 0, 1));
const CipherAdminClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_cipheradminclient_free(ptr >>> 0, 1));
const CipherRiskClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_cipherriskclient_free(ptr >>> 0, 1));
const CiphersClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_ciphersclient_free(ptr >>> 0, 1));
const CollectionViewNodeItemFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_collectionviewnodeitem_free(ptr >>> 0, 1));
const CollectionViewTreeFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_collectionviewtree_free(ptr >>> 0, 1));
const CollectionsClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_collectionsclient_free(ptr >>> 0, 1));
const CryptoCipherSuiteClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_cryptociphersuiteclient_free(ptr >>> 0, 1));
const CryptoClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_cryptoclient_free(ptr >>> 0, 1));
const CryptoSyncHandlerClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_cryptosynchandlerclient_free(ptr >>> 0, 1));
const ExporterClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_exporterclient_free(ptr >>> 0, 1));
const FlagsClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_flagsclient_free(ptr >>> 0, 1));
const FlightRecorderClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_flightrecorderclient_free(ptr >>> 0, 1));
const FoldersClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_foldersclient_free(ptr >>> 0, 1));
const GeneratorClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_generatorclient_free(ptr >>> 0, 1));
const ImporterClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_importerclient_free(ptr >>> 0, 1));
const IncomingMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_incomingmessage_free(ptr >>> 0, 1));
const IntoUnderlyingByteSourceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingbytesource_free(ptr >>> 0, 1));
const IntoUnderlyingSinkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingsink_free(ptr >>> 0, 1));
const IntoUnderlyingSourceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingsource_free(ptr >>> 0, 1));
const InviteLinkAdminClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_invitelinkadminclient_free(ptr >>> 0, 1));
const InviteLinkClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_invitelinkclient_free(ptr >>> 0, 1));
const InviteLinkUserClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_invitelinkuserclient_free(ptr >>> 0, 1));
const IpcCommunicationBackendFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_ipccommunicationbackend_free(ptr >>> 0, 1));
const IpcClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_ipcclient_free(ptr >>> 0, 1));
const IpcClientSubscriptionFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_ipcclientsubscription_free(ptr >>> 0, 1));
const ServerCommunicationConfigClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_servercommunicationconfigclient_free(ptr >>> 0, 1));
const LoginClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_loginclient_free(ptr >>> 0, 1));
const ManagedSettingsClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_managedsettingsclient_free(ptr >>> 0, 1));
const OrganizationUsersManagementClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_organizationusersmanagementclient_free(ptr >>> 0, 1));
const OutgoingMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_outgoingmessage_free(ptr >>> 0, 1));
const PasswordManagerClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_passwordmanagerclient_free(ptr >>> 0, 1));
const PinSettingsClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pinsettingsclient_free(ptr >>> 0, 1));
const PlatformClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_platformclient_free(ptr >>> 0, 1));
const PolicyClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_policyclient_free(ptr >>> 0, 1));
const PureCryptoFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_purecrypto_free(ptr >>> 0, 1));
const RegistrationClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_registrationclient_free(ptr >>> 0, 1));
const SdkRandomNumberClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sdkrandomnumberclient_free(ptr >>> 0, 1));
const SendAccessClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sendaccessclient_free(ptr >>> 0, 1));
const SendClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sendclient_free(ptr >>> 0, 1));
const SendSyncHandlerClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sendsynchandlerclient_free(ptr >>> 0, 1));
const SharedUnlockPeerFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sharedunlockpeer_free(ptr >>> 0, 1));
const StateBridgeClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_statebridgeclient_free(ptr >>> 0, 1));
const StateClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_stateclient_free(ptr >>> 0, 1));
const TotpClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_totpclient_free(ptr >>> 0, 1));
const UserCryptoManagementClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_usercryptomanagementclient_free(ptr >>> 0, 1));
const VaultClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_vaultclient_free(ptr >>> 0, 1));

function addHeapObject(obj) {
    if (heap_next === heap.length) heap.push(heap.length + 1);
    const idx = heap_next;
    heap_next = heap[idx];

    heap[idx] = obj;
    return idx;
}

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
}

function addBorrowedObject(obj) {
    if (stack_pointer == 1) throw new Error('out of js stack');
    heap[--stack_pointer] = obj;
    return stack_pointer;
}

const CLOSURE_DTORS = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(state => state.dtor(state.a, state.b));

function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
        return  `${val}`;
    }
    if (type == 'string') {
        return `"${val}"`;
    }
    if (type == 'symbol') {
        const description = val.description;
        if (description == null) {
            return 'Symbol';
        } else {
            return `Symbol(${description})`;
        }
    }
    if (type == 'function') {
        const name = val.name;
        if (typeof name == 'string' && name.length > 0) {
            return `Function(${name})`;
        } else {
            return 'Function';
        }
    }
    // objects
    if (Array.isArray(val)) {
        const length = val.length;
        let debug = '[';
        if (length > 0) {
            debug += debugString(val[0]);
        }
        for(let i = 1; i < length; i++) {
            debug += ', ' + debugString(val[i]);
        }
        debug += ']';
        return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
        className = builtInMatches[1];
    } else {
        // Failed to match the standard '[object ClassName]'
        return toString.call(val);
    }
    if (className == 'Object') {
        // we're a user defined class or Object
        // JSON.stringify avoids problems with cycles, and is generally much
        // easier than looping through ownProperties of `val`.
        try {
            return 'Object(' + JSON.stringify(val) + ')';
        } catch (_) {
            return 'Object';
        }
    }
    // errors
    if (val instanceof Error) {
        return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
}

function dropObject(idx) {
    if (idx < 1028) return;
    heap[idx] = heap_next;
    heap_next = idx;
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(takeObject(mem.getUint32(i, true)));
    }
    return result;
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function getObject(idx) { return heap[idx]; }

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        wasm.__wbindgen_exn_store(addHeapObject(e));
    }
}

let heap = new Array(1024).fill(undefined);
heap.push(undefined, null, true, false);

let heap_next = heap.length;

function isLikeNone(x) {
    return x === undefined || x === null;
}

function makeMutClosure(arg0, arg1, dtor, f) {
    const state = { a: arg0, b: arg1, cnt: 1, dtor };
    const real = (...args) => {

        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        const a = state.a;
        state.a = 0;
        try {
            return f(a, state.b, ...args);
        } finally {
            state.a = a;
            real._wbg_cb_unref();
        }
    };
    real._wbg_cb_unref = () => {
        if (--state.cnt === 0) {
            state.dtor(state.a, state.b);
            state.a = 0;
            CLOSURE_DTORS.unregister(state);
        }
    };
    CLOSURE_DTORS.register(real, state, state);
    return real;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArrayJsValueToWasm0(array, malloc) {
    const ptr = malloc(array.length * 4, 4) >>> 0;
    const mem = getDataViewMemory0();
    for (let i = 0; i < array.length; i++) {
        mem.setUint32(ptr + 4 * i, addHeapObject(array[i]), true);
    }
    WASM_VECTOR_LEN = array.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

let stack_pointer = 1024;

function takeObject(idx) {
    const ret = getObject(idx);
    dropObject(idx);
    return ret;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
function decodeText(ptr, len) {
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

const wasmPath = `${__dirname}/bitwarden_wasm_internal_bg.wasm`;
const wasmBytes = require('fs').readFileSync(wasmPath);
const wasmModule = new WebAssembly.Module(wasmBytes);
let wasm = new WebAssembly.Instance(wasmModule, __wbg_get_imports()).exports;
