/* tslint:disable */
/* eslint-disable */
/**
 * The `ReadableStreamType` enum.
 *
 * *This API requires the following crate features to be activated: `ReadableStreamType`*
 */

type ReadableStreamType = "bytes";

import { Tagged } from "type-fest";

/**
 * A string that **MUST** be a valid UUID.
 *
 * Never create or cast to this type directly, use the `uuid<T>()` function instead.
 */
export type Uuid = unknown;

/**
 * RFC3339 compliant date-time string.
 * @typeParam T - Not used in JavaScript.
 */
export type DateTime<T = unknown> = string;

/**
 * ISO 8601 compliant date string (yyyy-mm-dd).
 */
export type NaiveDate = string;

/**
 * UTC date-time string. Not used in JavaScript.
 */
export type Utc = unknown;

/**
 * An integer that is known not to equal zero.
 */
export type NonZeroU32 = number;

export interface AccessSendError extends Error {
  name: "AccessSendError";
  variant: "Api" | "Parse";
}

export function isAccessSendError(error: any): error is AccessSendError;

export interface AccountCryptographyInitializationError extends Error {
  name: "AccountCryptographyInitializationError";
  variant: "WrongUserKeyType" | "WrongUserKey" | "CorruptData" | "TamperedData" | "GenericCrypto";
}

export function isAccountCryptographyInitializationError(
  error: any,
): error is AccountCryptographyInitializationError;

export interface AcquireCookieError extends Error {
  name: "AcquireCookieError";
  variant:
    | "Cancelled"
    | "UnsupportedConfiguration"
    | "CookieNameMismatch"
    | "RepositoryGet"
    | "RepositorySave";
}

export function isAcquireCookieError(error: any): error is AcquireCookieError;

export interface AlreadyRunningError extends Error {
  name: "AlreadyRunningError";
}

export function isAlreadyRunningError(error: any): error is AlreadyRunningError;

export interface BulkUpdateCollectionsCipherError extends Error {
  name: "BulkUpdateCollectionsCipherError";
  variant: "Api" | "Repository";
}

export function isBulkUpdateCollectionsCipherError(
  error: any,
): error is BulkUpdateCollectionsCipherError;

export interface CallError extends Error {
  name: "CallError";
}

export function isCallError(error: any): error is CallError;

export interface ChangeKdfError extends Error {
  name: "ChangeKdfError";
  variant: "MasterPassword" | "MissingMasterPasswordUnlockData" | "NotAuthenticated" | "Api";
}

export function isChangeKdfError(error: any): error is ChangeKdfError;

export interface ChannelError extends Error {
  name: "ChannelError";
}

export function isChannelError(error: any): error is ChannelError;

export interface CipherAdminGetAttachmentDownloadUrlError extends Error {
  name: "CipherAdminGetAttachmentDownloadUrlError";
  variant: "Api" | "MissingField" | "NotFound";
}

export function isCipherAdminGetAttachmentDownloadUrlError(
  error: any,
): error is CipherAdminGetAttachmentDownloadUrlError;

export interface CipherCreateAttachmentError extends Error {
  name: "CipherCreateAttachmentError";
  variant: "Api" | "Repository" | "MissingField" | "VaultParse" | "UnsupportedFileUploadType";
}

export function isCipherCreateAttachmentError(error: any): error is CipherCreateAttachmentError;

export interface CipherDeleteAttachmentError extends Error {
  name: "CipherDeleteAttachmentError";
  variant: "Api" | "Repository" | "MissingField" | "VaultParse";
}

export function isCipherDeleteAttachmentError(error: any): error is CipherDeleteAttachmentError;

export interface CipherError extends Error {
  name: "CipherError";
  variant:
    | "MissingField"
    | "Crypto"
    | "Decrypt"
    | "Encrypt"
    | "AttachmentsWithoutKeys"
    | "OrganizationAlreadySet"
    | "Repository"
    | "Chrono"
    | "SerdeJson"
    | "Api";
}

export function isCipherError(error: any): error is CipherError;

export interface CipherGetAttachmentDownloadUrlError extends Error {
  name: "CipherGetAttachmentDownloadUrlError";
  variant: "Api" | "Repository" | "MissingField" | "NotFound" | "InvalidEmergencyAccessId";
}

export function isCipherGetAttachmentDownloadUrlError(
  error: any,
): error is CipherGetAttachmentDownloadUrlError;

export interface CipherRenewFileUploadUrlError extends Error {
  name: "CipherRenewFileUploadUrlError";
  variant: "Api" | "MissingField";
}

export function isCipherRenewFileUploadUrlError(error: any): error is CipherRenewFileUploadUrlError;

export interface CipherRiskError extends Error {
  name: "CipherRiskError";
  variant: "Reqwest";
}

export function isCipherRiskError(error: any): error is CipherRiskError;

export interface CipherUpgradeAttachmentError extends Error {
  name: "CipherUpgradeAttachmentError";
  variant:
    | "Api"
    | "Repository"
    | "MissingField"
    | "VaultParse"
    | "Decrypt"
    | "Encrypt"
    | "Cipher"
    | "GetDownloadUrl"
    | "CreateAttachment"
    | "DeleteAttachment"
    | "Crypto"
    | "Io"
    | "NotFound"
    | "AlreadyUpgraded"
    | "Download"
    | "Upload";
}

export function isCipherUpgradeAttachmentError(error: any): error is CipherUpgradeAttachmentError;

export interface CollectionDecryptError extends Error {
  name: "CollectionDecryptError";
  variant: "Crypto";
}

export function isCollectionDecryptError(error: any): error is CollectionDecryptError;

export interface CreateCipherAdminError extends Error {
  name: "CreateCipherAdminError";
  variant: "Crypto" | "Api" | "VaultParse" | "MissingField" | "NotAuthenticated";
}

export function isCreateCipherAdminError(error: any): error is CreateCipherAdminError;

export interface CreateCipherError extends Error {
  name: "CreateCipherError";
  variant: "Crypto" | "Api" | "VaultParse" | "MissingField" | "NotAuthenticated" | "Repository";
}

export function isCreateCipherError(error: any): error is CreateCipherError;

export interface CreateFileSendError extends Error {
  name: "CreateFileSendError";
  variant: "Api" | "Crypto" | "EmptyEmailList" | "MissingField" | "Repository" | "SendParse";
}

export function isCreateFileSendError(error: any): error is CreateFileSendError;

export interface CreateFolderError extends Error {
  name: "CreateFolderError";
  variant: "Crypto" | "Api" | "VaultParse" | "MissingField" | "Repository";
}

export function isCreateFolderError(error: any): error is CreateFolderError;

export interface CreateSendError extends Error {
  name: "CreateSendError";
  variant: "Api" | "Crypto" | "EmptyEmailList" | "MissingField" | "Repository" | "SendParse";
}

export function isCreateSendError(error: any): error is CreateSendError;

export interface CryptoClientError extends Error {
  name: "CryptoClientError";
  variant:
    | "NotAuthenticated"
    | "Crypto"
    | "InvalidKdfSettings"
    | "PasswordProtectedKeyEnvelope"
    | "InvalidPrfInput"
    | "InvalidUpgradeToken"
    | "UpgradeTokenRequired"
    | "InvalidKeyType";
}

export function isCryptoClientError(error: any): error is CryptoClientError;

export interface CryptoError extends Error {
  name: "CryptoError";
  variant:
    | "Decrypt"
    | "InvalidKey"
    | "KeyDecrypt"
    | "InvalidKeyLen"
    | "InvalidUtf8String"
    | "MissingKey"
    | "MissingField"
    | "MissingKeyId"
    | "KeyOperationNotSupported"
    | "ReadOnlyKeyStore"
    | "InvalidKeyStoreOperation"
    | "InsufficientKdfParameters"
    | "EncString"
    | "Rsa"
    | "Fingerprint"
    | "Argon"
    | "ZeroNumber"
    | "OperationNotSupported"
    | "WrongKeyType"
    | "WrongCoseKeyId"
    | "InvalidNonceLength"
    | "InvalidPadding"
    | "Signature"
    | "Encoding";
}

export function isCryptoError(error: any): error is CryptoError;

export interface DatabaseError extends Error {
  name: "DatabaseError";
  variant:
    | "UnsupportedConfiguration"
    | "ThreadBoundRunner"
    | "Serialization"
    | "JS"
    | "Internal"
    | "Closed";
}

export function isDatabaseError(error: any): error is DatabaseError;

export interface DecryptError extends Error {
  name: "DecryptError";
  variant: "Crypto";
}

export function isDecryptError(error: any): error is DecryptError;

export interface DecryptFileError extends Error {
  name: "DecryptFileError";
  variant: "Decrypt" | "Io";
}

export function isDecryptFileError(error: any): error is DecryptFileError;

export interface DeleteAttachmentAdminError extends Error {
  name: "DeleteAttachmentAdminError";
  variant: "Api" | "MissingField" | "VaultParse";
}

export function isDeleteAttachmentAdminError(error: any): error is DeleteAttachmentAdminError;

export interface DeleteCipherAdminError extends Error {
  name: "DeleteCipherAdminError";
  variant: "Api";
}

export function isDeleteCipherAdminError(error: any): error is DeleteCipherAdminError;

export interface DeleteCipherError extends Error {
  name: "DeleteCipherError";
  variant: "Api" | "Repository";
}

export function isDeleteCipherError(error: any): error is DeleteCipherError;

export interface DeleteSendError extends Error {
  name: "DeleteSendError";
  variant: "Api" | "Repository";
}

export function isDeleteSendError(error: any): error is DeleteSendError;

export interface DeriveKeyConnectorError extends Error {
  name: "DeriveKeyConnectorError";
  variant: "WrongPassword" | "Crypto";
}

export function isDeriveKeyConnectorError(error: any): error is DeriveKeyConnectorError;

export interface DeserializeError extends Error {
  name: "DeserializeError";
}

export function isDeserializeError(error: any): error is DeserializeError;

export interface EditCipherAdminError extends Error {
  name: "EditCipherAdminError";
  variant:
    | "ItemNotFound"
    | "Crypto"
    | "Api"
    | "VaultParse"
    | "MissingField"
    | "NotAuthenticated"
    | "Repository"
    | "Uuid"
    | "Decrypt";
}

export function isEditCipherAdminError(error: any): error is EditCipherAdminError;

export interface EditCipherError extends Error {
  name: "EditCipherError";
  variant:
    | "ItemNotFound"
    | "Crypto"
    | "Api"
    | "VaultParse"
    | "MissingField"
    | "NotAuthenticated"
    | "Repository"
    | "Uuid";
}

export function isEditCipherError(error: any): error is EditCipherError;

export interface EditFolderError extends Error {
  name: "EditFolderError";
  variant:
    "ItemNotFound" | "Crypto" | "Api" | "VaultParse" | "MissingField" | "Repository" | "Uuid";
}

export function isEditFolderError(error: any): error is EditFolderError;

export interface EditSendError extends Error {
  name: "EditSendError";
  variant:
    | "ItemNotFound"
    | "Crypto"
    | "Api"
    | "EmptyEmailList"
    | "MissingField"
    | "Repository"
    | "Uuid"
    | "SendParse"
    | "IdMismatch";
}

export function isEditSendError(error: any): error is EditSendError;

export interface EncryptError extends Error {
  name: "EncryptError";
  variant: "Crypto" | "BlobEncryption" | "MissingUserId";
}

export function isEncryptError(error: any): error is EncryptError;

export interface EncryptFileError extends Error {
  name: "EncryptFileError";
  variant: "Encrypt" | "Io";
}

export function isEncryptFileError(error: any): error is EncryptFileError;

export interface EncryptionSettingsError extends Error {
  name: "EncryptionSettingsError";
  variant:
    | "Crypto"
    | "CryptoInitialization"
    | "MissingPrivateKey"
    | "UserIdAlreadySet"
    | "WrongPin"
    | "UserKeyStateUpdateFailed"
    | "UserKeyStateRetrievalFailed"
    | "InvalidUpgradeToken"
    | "KeyConnectorRetrievalFailed"
    | "LocalUserDataKeyInitFailed"
    | "LocalUserDataKeyLoadFailed"
    | "LocalUserDataMigrationFailed";
}

export function isEncryptionSettingsError(error: any): error is EncryptionSettingsError;

export interface EnrollAdminPasswordResetError extends Error {
  name: "EnrollAdminPasswordResetError";
  variant: "Crypto";
}

export function isEnrollAdminPasswordResetError(error: any): error is EnrollAdminPasswordResetError;

export interface ExportError extends Error {
  name: "ExportError";
  variant:
    | "MissingField"
    | "NotAuthenticated"
    | "Csv"
    | "Cxf"
    | "Json"
    | "EncryptedJson"
    | "BitwardenCrypto"
    | "Cipher";
}

export function isExportError(error: any): error is ExportError;

export interface FollowerStartError extends Error {
  name: "FollowerStartError";
}

export function isFollowerStartError(error: any): error is FollowerStartError;

export interface GenBytesError extends Error {
  name: "GenBytesError";
  variant: "TooManyBytes";
}

export function isGenBytesError(error: any): error is GenBytesError;

export interface GenRangeError extends Error {
  name: "GenRangeError";
  variant: "InvalidRange";
}

export function isGenRangeError(error: any): error is GenRangeError;

export interface GetAssignedOrgCiphersAdminError extends Error {
  name: "GetAssignedOrgCiphersAdminError";
  variant: "Api" | "VaultParse";
}

export function isGetAssignedOrgCiphersAdminError(
  error: any,
): error is GetAssignedOrgCiphersAdminError;

export interface GetCipherError extends Error {
  name: "GetCipherError";
  variant: "ItemNotFound" | "Crypto" | "Repository";
}

export function isGetCipherError(error: any): error is GetCipherError;

export interface GetFileDownloadDataError extends Error {
  name: "GetFileDownloadDataError";
  variant: "Api";
}

export function isGetFileDownloadDataError(error: any): error is GetFileDownloadDataError;

export interface GetFolderError extends Error {
  name: "GetFolderError";
  variant: "ItemNotFound" | "Crypto" | "Repository";
}

export function isGetFolderError(error: any): error is GetFolderError;

export interface GetOrganizationCiphersAdminError extends Error {
  name: "GetOrganizationCiphersAdminError";
  variant: "VaultParse" | "Api";
}

export function isGetOrganizationCiphersAdminError(
  error: any,
): error is GetOrganizationCiphersAdminError;

export interface GetSendError extends Error {
  name: "GetSendError";
  variant: "ItemNotFound" | "Crypto" | "MissingField" | "Repository";
}

export function isGetSendError(error: any): error is GetSendError;

export interface ImportError extends Error {
  name: "ImportError";
  variant:
    | "KdbxInvalidFormat"
    | "KdbxFileTooLarge"
    | "KdbxWrongCredentials"
    | "KdbxCorruptOrUnsupported"
    | "NotAuthenticated"
    | "Api"
    | "BitwardenCrypto"
    | "Export";
}

export function isImportError(error: any): error is ImportError;

export interface InviteLinkError extends Error {
  name: "InviteLinkError";
  variant: "Invite" | "Api" | "Crypto" | "MissingField" | "ParseFailure" | "RecoveryKeyMismatch";
}

export function isInviteLinkError(error: any): error is InviteLinkError;

export interface KeyGenerationError extends Error {
  name: "KeyGenerationError";
  variant: "KeyGeneration" | "KeyConversion";
}

export function isKeyGenerationError(error: any): error is KeyGenerationError;

export interface KeyIdBackfillError extends Error {
  name: "KeyIdBackfillError";
  variant: "UserKeyNotAvailable" | "NoKeyId" | "StateBridgeNotRegistered" | "Api";
}

export function isKeyIdBackfillError(error: any): error is KeyIdBackfillError;

export interface KeyPairRegenerationError extends Error {
  name: "KeyPairRegenerationError";
  variant: "UserKeyNotAvailable" | "Api" | "Crypto";
}

export function isKeyPairRegenerationError(error: any): error is KeyPairRegenerationError;

export interface LeaderStartError extends Error {
  name: "LeaderStartError";
}

export function isLeaderStartError(error: any): error is LeaderStartError;

export interface MakeKeysError extends Error {
  name: "MakeKeysError";
  variant:
    | "AccountCryptographyInitialization"
    | "MasterPasswordDerivation"
    | "RequestModelCreation"
    | "Crypto";
}

export function isMakeKeysError(error: any): error is MakeKeysError;

export interface MasterPasswordError extends Error {
  name: "MasterPasswordError";
  variant:
    | "EncryptionKeyMalformed"
    | "KdfMalformed"
    | "InvalidKdfConfiguration"
    | "MissingField"
    | "Crypto"
    | "WrongPassword";
}

export function isMasterPasswordError(error: any): error is MasterPasswordError;

export interface MigrateToKeyConnectorError extends Error {
  name: "MigrateToKeyConnectorError";
  variant: "UserKeyNotAvailable" | "Crypto" | "Api" | "KeyConnectorApi";
}

export function isMigrateToKeyConnectorError(error: any): error is MigrateToKeyConnectorError;

export interface MoveCipherError extends Error {
  name: "MoveCipherError";
  variant: "Api" | "Repository";
}

export function isMoveCipherError(error: any): error is MoveCipherError;

export interface PasswordError extends Error {
  name: "PasswordError";
  variant: "NoCharacterSetEnabled" | "InvalidLength";
}

export function isPasswordError(error: any): error is PasswordError;

export interface PasswordLoginError extends Error {
  name: "PasswordLoginError";
  variant: "InvalidUsernameOrPassword" | "PasswordAuthenticationDataDerivation" | "Unknown";
}

export function isPasswordLoginError(error: any): error is PasswordLoginError;

export interface PasswordPreloginError extends Error {
  name: "PasswordPreloginError";
  variant: "Api" | "Unknown";
}

export function isPasswordPreloginError(error: any): error is PasswordPreloginError;

export interface PasswordRulesError extends Error {
  name: "PasswordRulesError";
  variant: "Parse" | "InvalidLength";
}

export function isPasswordRulesError(error: any): error is PasswordRulesError;

export interface PinSettingsError extends Error {
  name: "PinSettingsError";
  variant: "SetPinState";
}

export function isPinSettingsError(error: any): error is PinSettingsError;

export interface ReceiveError extends Error {
  name: "ReceiveError";
  variant: "Channel" | "Timeout" | "Cancelled";
}

export function isReceiveError(error: any): error is ReceiveError;

export interface RegistrationError extends Error {
  name: "RegistrationError";
  variant: "KeyConnectorApi" | "Api" | "Crypto" | "InvalidInput";
}

export function isRegistrationError(error: any): error is RegistrationError;

export interface RemoveSendPasswordError extends Error {
  name: "RemoveSendPasswordError";
  variant: "Api" | "Crypto" | "MissingField" | "Repository" | "SendParse";
}

export function isRemoveSendPasswordError(error: any): error is RemoveSendPasswordError;

export interface RenewFileUploadUrlError extends Error {
  name: "RenewFileUploadUrlError";
  variant: "Api" | "MissingField";
}

export function isRenewFileUploadUrlError(error: any): error is RenewFileUploadUrlError;

export interface RequestError extends Error {
  name: "RequestError";
  variant: "Subscribe" | "Receive" | "Timeout" | "Send" | "Unreachable" | "Rpc";
}

export function isRequestError(error: any): error is RequestError;

export interface RestoreCipherAdminError extends Error {
  name: "RestoreCipherAdminError";
  variant: "Api" | "VaultParse" | "Crypto";
}

export function isRestoreCipherAdminError(error: any): error is RestoreCipherAdminError;

export interface RestoreCipherError extends Error {
  name: "RestoreCipherError";
  variant: "Api" | "VaultParse" | "Repository" | "Crypto";
}

export function isRestoreCipherError(error: any): error is RestoreCipherError;

export interface RotateCryptographyStateError extends Error {
  name: "RotateCryptographyStateError";
  variant: "KeyMissing" | "InvalidData";
}

export function isRotateCryptographyStateError(error: any): error is RotateCryptographyStateError;

export interface RotateUserKeysError extends Error {
  name: "RotateUserKeysError";
  variant:
    "Api" | "Crypto" | "InvalidPublicKey" | "KeyConnectorApi" | "UntrustedKey" | "OldAttachments";
}

export function isRotateUserKeysError(error: any): error is RotateUserKeysError;

export interface SendAccessDecryptError extends Error {
  name: "SendAccessDecryptError";
  variant: "Crypto";
}

export function isSendAccessDecryptError(error: any): error is SendAccessDecryptError;

export interface SendAccessKeyError extends Error {
  name: "SendAccessKeyError";
  variant: "InvalidEncoding" | "InvalidLength";
}

export function isSendAccessKeyError(error: any): error is SendAccessKeyError;

export interface ServerCommunicationConfigRepositoryError extends Error {
  name: "ServerCommunicationConfigRepositoryError";
  variant: "Get" | "Save";
}

export function isServerCommunicationConfigRepositoryError(
  error: any,
): error is ServerCommunicationConfigRepositoryError;

export interface SshKeyExportError extends Error {
  name: "SshKeyExportError";
  variant: "KeyConversion";
}

export function isSshKeyExportError(error: any): error is SshKeyExportError;

export interface SshKeyImportError extends Error {
  name: "SshKeyImportError";
  variant: "Parsing" | "PasswordRequired" | "WrongPassword" | "UnsupportedKeyType";
}

export function isSshKeyImportError(error: any): error is SshKeyImportError;

export interface StateRegistryError extends Error {
  name: "StateRegistryError";
  variant: "DatabaseNotInitialized" | "Database";
}

export function isStateRegistryError(error: any): error is StateRegistryError;

export interface StatefulCryptoError extends Error {
  name: "StatefulCryptoError";
  variant: "MissingSecurityState" | "WrongAccountCryptoVersion" | "Crypto";
}

export function isStatefulCryptoError(error: any): error is StatefulCryptoError;

export interface SubscribeError extends Error {
  name: "SubscribeError";
  variant: "NotStarted";
}

export function isSubscribeError(error: any): error is SubscribeError;

export interface SyncError extends Error {
  name: "SyncError";
  variant: "Network" | "Data";
}

export function isSyncError(error: any): error is SyncError;

export interface TestError extends Error {
  name: "TestError";
}

export function isTestError(error: any): error is TestError;

export interface TotpError extends Error {
  name: "TotpError";
  variant: "InvalidOtpauth" | "MissingSecret" | "Crypto";
}

export function isTotpError(error: any): error is TotpError;

export interface TypedReceiveError extends Error {
  name: "TypedReceiveError";
  variant: "Channel" | "Timeout" | "Cancelled" | "Typing";
}

export function isTypedReceiveError(error: any): error is TypedReceiveError;

export interface UploadSendFileError extends Error {
  name: "UploadSendFileError";
  variant: "Api" | "Reqwest" | "RenewFileUploadUrl";
}

export function isUploadSendFileError(error: any): error is UploadSendFileError;

export interface UsernameError extends Error {
  name: "UsernameError";
  variant: "GenerationFailed";
}

export function isUsernameError(error: any): error is UsernameError;

export type UnsignedSharedKey = Tagged<string, "UnsignedSharedKey">;

/**
 * @deprecated Use PasswordManagerClient instead
 */
export type BitwardenClient = PasswordManagerClient;

/**
 * Platform API interface for acquiring SSO cookies.
 *
 * Platform clients implement this interface to handle cookie acquisition
 * through browser redirects or other platform-specific mechanisms.
 */
export interface ServerCommunicationConfigPlatformApi {
  /**
   * Acquires cookies using the provided vault URL.
   *
   * This typically involves redirecting to an IdP login page and extracting
   * cookies from the load balancer response. For sharded cookies, returns
   * multiple entries with names like "CookieName-0", "CookieName-1", etc.
   *
   * @param vaultUrl The full vault URL (e.g., "https://vault.bitwarden.com" or "https://localhost:8000")
   * @returns An array of AcquiredCookie objects, or undefined if acquisition failed or was cancelled
   */
  acquireCookies(vaultUrl: string): Promise<AcquiredCookie[] | undefined>;
}

/**
 * Repository interface for storing server communication configuration.
 *
 * Implementations use StateProvider (or equivalent storage mechanism) to
 * persist configuration across sessions. The domain is typically the vault
 * server's domain name (e.g., "vault.acme.com").
 */
export interface ServerCommunicationConfigRepository {
  /**
   * Retrieves the server communication configuration for a given domain.
   *
   * @param domain The server domain (e.g., "vault.acme.com")
   * @returns The configuration if it exists, undefined otherwise
   */
  get(domain: string): Promise<ServerCommunicationConfig | undefined>;

  /**
   * Saves the server communication configuration for a given domain.
   *
   * @param domain The server domain (e.g., "vault.acme.com")
   * @param config The configuration to store
   */
  save(domain: string, config: ServerCommunicationConfig): Promise<void>;
}

/** A sanitized adapter failure. Provider bodies, endpoints, and credentials are forbidden. */
export interface AliasAdapterFailure {
  code: AliasErrorCode;
  retryAfterSeconds?: number;
}

export type AliasAdapterResult<T> =
  { status: "success"; value: T } | { status: "failure"; failure: AliasAdapterFailure };

/**
 * Provider-neutral lifecycle SPI implemented by the host application.
 * Connection secrets and provider-native transport remain private to this object.
 */
export interface AliasProviderAdapter {
  create(request: CreateAliasRequest): Promise<AliasAdapterResult<Alias>>;
  list(request: ListAliasesRequest): Promise<AliasAdapterResult<AliasPage>>;
  get(identity: AliasIdentity): Promise<AliasAdapterResult<Alias>>;
  setEnabled(identity: AliasIdentity, enabled: boolean): Promise<AliasAdapterResult<Alias>>;
  delete(identity: AliasIdentity): Promise<AliasAdapterResult<DeleteAliasResult>>;
  createSendReplyIdentity(
    request: CreateSendReplyIdentityRequest,
  ): Promise<AliasAdapterResult<SendReplyIdentity>>;
  listSendReplyIdentities(
    identity: AliasIdentity,
    pageToken?: string,
  ): Promise<AliasAdapterResult<SendReplyIdentityPage>>;
  removeSendReplyIdentity(identity: SendReplyIdentity): Promise<AliasAdapterResult<null>>;
  setSendReplyBlocked(
    identity: SendReplyIdentity,
    blocked: boolean,
  ): Promise<AliasAdapterResult<SendReplyIdentity>>;
}

export interface BiometricsUnlock {
  /**
   * Returns the status of biometrics unlock for the given user.
   */
  get_biometrics_status(user_id: UserId): Promise<BiometricsStatus>;
  /**
   * Triggers a biometric unlock flow for the given user. Resolves with the
   * user's symmetric key on success, or `undefined` if the unlock was
   * canceled or otherwise failed.
   *
   * Please note, the user-key is only returned temporarily until
   * shared unlock is rolled out and will be removed afterwards.
   */
  unlock_biometrics(user_id: UserId): Promise<SymmetricKey | undefined>;
  /**
   * Triggers a biometrics UV check. Retruns true if the check succeeded.
   */
  authenticate_biometrics(): Promise<boolean>;
}

export interface IpcCommunicationBackendSender {
  send(message: OutgoingMessage): Promise<void>;
}

export interface IpcSessionRepository {
  get(endpoint: Endpoint): Promise<any | undefined>;
  save(endpoint: Endpoint, session: any): Promise<void>;
  remove(endpoint: Endpoint): Promise<void>;
}

export interface Repository<T> {
  get(id: string): Promise<T | null>;
  list(): Promise<T[]>;
  set(id: string, value: T): Promise<void>;
  setBulk(values: [string, T][]): Promise<void>;
  remove(id: string): Promise<void>;
  removeBulk(keys: string[]): Promise<void>;
  removeAll(): Promise<void>;
}

export interface SharedUnlockDriver {
  lock_user(user_id: UserId): Promise<void>;
  unlock_user(user_id: UserId, user_key: SymmetricKey): Promise<void>;
  list_users(): Promise<UserId[]>;
  get_user_key(user_id: UserId): Promise<SymmetricKey | undefined>;
  suppress_vault_timeout(user_id: UserId, suppression_duration: number): Promise<void>;
  get_client_name(): Promise<string>;
  get_vault_url(user_id: UserId): Promise<string | undefined>;
}

export interface TokenProvider {
  get_access_token(): Promise<string | undefined>;
}

export type DataEnvelope = Tagged<string, "DataEnvelope">;

export type EncString = Tagged<string, "EncString">;

export type HighEntropySecret = Tagged<string, "HighEntropySecret">;

export type Invite = Tagged<string, "Invite">;

export type InviteSecret = Tagged<string, "InviteSecret">;

export type KeyId = Tagged<string, "KeyId">;

export type MasterPassword = SensitiveString;
export type Pin = SensitiveString;

export type PasswordProtectedKeyEnvelope = Tagged<string, "PasswordProtectedKeyEnvelope">;

export type PublicKey = Tagged<string, "PublicKey">;

export type SealedOpenOrgInviteData = Tagged<string, "SealedOpenOrgInviteData">;

export type SecretProtectedKeyEnvelope = Tagged<string, "SecretProtectedKeyEnvelope">;

export type SensitiveString = Tagged<string, "SensitiveString">;

export type SignedPublicKey = Tagged<string, "SignedPublicKey">;

export type SignedSecurityState = string;

export type SymmetricKey = Tagged<string, "SymmetricKey">;

export type SymmetricKeyEnvelope = Tagged<string, "SymmetricKeyEnvelope">;

/**
 * A cookie acquired from the platform
 *
 * Represents a single cookie name/value pair as received from the browser or HTTP client.
 * For sharded cookies (AWS ALB pattern), each shard is a separate `AcquiredCookie` with
 * its own name including the `-{N}` suffix (e.g., `AWSELBAuthSessionCookie-0`).
 */
export interface AcquiredCookie {
  /**
   * Cookie name
   *
   * For sharded cookies, this includes the shard suffix (e.g., `AWSELBAuthSessionCookie-0`)
   * For unsharded cookies, this is the cookie name without any suffix.
   */
  name: string;
  /**
   * Cookie value
   */
  value: string;
}

/**
 * A minimal set of data for a user in an organization. This provides
 * the context needed to evaluate the policies that are applied to the
 * user by the organization.
 */
export interface OrganizationUserPolicyContext {
  /**
   * The organization\'s unique ID.
   */
  id: Uuid;
  /**
   * The user\'s membership status in the organization.
   */
  status: OrganizationUserStatusType;
  /**
   * The user\'s role within the organization.
   */
  role: OrganizationUserType;
  /**
   * Whether the organization is enabled.
   */
  enabled: boolean;
  /**
   * Whether the organization\'s plan supports policies.
   */
  usePolicies: boolean;
  /**
   * Whether the user is acting on behalf of a provider
   * that manages the organization.
   */
  isProviderUser: boolean;
}

/**
 * A persisted organization encryption key.
 *
 * Stored in a Repository keyed by [`OrganizationId`].
 * The `org_id` is included in the struct so it can be recovered from `Repository::list()`.
 */
export interface OrganizationSharedKey {
  /**
   * The organization this key belongs to.
   */
  org_id: OrganizationId;
  /**
   * The organization\'s shared encryption key.
   */
  key: UnsignedSharedKey;
}

/**
 * A request structure for requesting a send access token from the API.
 */
export interface SendAccessTokenRequest {
  /**
   * The id of the send for which the access token is requested.
   */
  sendId: string;
  /**
   * The optional send access credentials.
   */
  sendAccessCredentials?: SendAccessCredentials;
}

/**
 * A send access token which can be used to access a send.
 */
export interface SendAccessTokenResponse {
  /**
   * The actual token string.
   */
  token: string;
  /**
   * The timestamp in milliseconds when the token expires.
   */
  expiresAt: number;
}

/**
 * A set of keys where a given `DownstreamKey` is protected by an encrypted public/private
 * key-pair. The `DownstreamKey` is used to encrypt/decrypt data, while the public/private key-pair
 * is used to rotate the `DownstreamKey`.
 *
 * The `PrivateKey` is protected by an `UpstreamKey`, such as a `DeviceKey`, or `PrfKey`,
 * and the `PublicKey` is protected by the `DownstreamKey`. This setup allows:
 *
 *   - Access to `DownstreamKey` by knowing the `UpstreamKey`
 *   - Rotation to a `NewDownstreamKey` by knowing the current `DownstreamKey`, without needing
 *     access to the `UpstreamKey`
 */
export interface RotateableKeySet {
  /**
   * `DownstreamKey` protected by encapsulation key
   */
  encapsulatedDownstreamKey: UnsignedSharedKey;
  /**
   * Encapsulation key protected by `DownstreamKey`
   */
  encryptedEncapsulationKey: EncString;
  /**
   * Decapsulation key protected by `UpstreamKey`
   */
  encryptedDecapsulationKey: EncString;
}

/**
 * A single log event captured by the Flight Recorder.
 */
export interface FlightRecorderEvent {
  /**
   * Unix timestamp in milliseconds.
   */
  timestamp: number;
  /**
   * Log level (e.g. \"DEBUG\", \"INFO\", \"WARN\", \"ERROR\").
   */
  level: string;
  /**
   * Target module path (e.g. \"bitwarden_core::client\").
   */
  target: string;
  /**
   * Primary log message.
   */
  message: string;
  /**
   * Structured fields from the tracing event.
   */
  fields: Record<string, string>;
}

/**
 * Active feature flags for the SDK.
 */
export interface FeatureFlags extends Map<string, boolean> {}

/**
 * Aggregate counts for a reconciliation plan or application result.
 */
export interface AliasReconciliationSummary {
  /**
   * Bindings already matching current aliases.
   */
  matched: bigint;
  /**
   * Bindings needing a reference or username refresh.
   */
  staleBindings: bigint;
  /**
   * Alias identities claimed by multiple ciphers.
   */
  duplicateBindings: bigint;
  /**
   * Bindings whose alias is absent from the inventory.
   */
  missingAliases: bigint;
  /**
   * Current aliases with no binding.
   */
  unboundAliases: bigint;
  /**
   * Ciphers excluded from reconciliation.
   */
  skippedCiphers: bigint;
  /**
   * Repair actions proposed by the plan.
   */
  proposedRepairs: bigint;
  /**
   * Repairs confirmed as applied by a reporting layer.
   */
  appliedRepairs: bigint;
  /**
   * Repairs reported as failed by a reporting layer.
   */
  failedRepairs: bigint;
  /**
   * Outcomes that require user conflict resolution.
   */
  conflicts: bigint;
  /**
   * Mutations whose remote result remains unknown.
   */
  unknownOutcomes: bigint;
}

/**
 * An existing organization collection to assign an org import to.
 */
export interface ImportTargetCollection {
  id: CollectionId;
  name: string;
}

/**
 * An existing personal folder to nest a personal import under.
 */
export interface ImportTargetFolder {
  id: FolderId;
  name: string;
}

/**
 * An organization invite link as persisted by the server.
 */
export interface OrganizationInviteLink {
  /**
   * Unique identifier of the invite link.
   */
  id: Uuid;
  /**
   * The invite code invitees present when accepting or confirming the invite.
   */
  code: Uuid;
  /**
   * The organization this invite link belongs to.
   */
  organizationId: OrganizationId;
  /**
   * Email domains permitted to redeem this invite link.
   */
  allowedDomains: string[];
  /**
   * The sealed cryptographic invite carried in the invite link.
   */
  invite: Invite;
  /**
   * Whether invitees can self-confirm using this invite link.
   */
  supportsConfirmation: boolean;
  /**
   * When the invite link was created.
   */
  creationDate: DateTime<Utc>;
}

/**
 * An organization policy.
 */
export interface PolicyView {
  /**
   * The policy\'s unique ID.
   */
  id: Uuid;
  /**
   * The organization this policy belongs to.
   */
  organizationId: Uuid;
  /**
   * The type of policy.
   */
  type: PolicyType;
  /**
   * The policy\'s additional configuration data as a JSON string, if any.
   */
  data: string | undefined;
  /**
   * Whether the policy is enabled.
   */
  enabled: boolean;
  /**
   * When the policy was last modified.
   */
  revisionDate: DateTime<Utc> | undefined;
}

/**
 * Any keys / cryptographic protection \"downstream\" from the account symmetric key (user key).
 * Private keys are protected by the user key.
 */
export type WrappedAccountCryptographicState =
  | { V1: { private_key: EncString } }
  | {
      V2: {
        private_key: EncString;
        signed_public_key: SignedPublicKey | undefined;
        signing_key: EncString;
        security_state: SignedSecurityState;
      };
    };

/**
 * Any unexpected error that occurs when making requests to identity. This could be
 * local/transport/decoding failure from the HTTP client (DNS/TLS/connect/read timeout,
 * connection reset, or JSON decode failure on a success response) or non-2xx response with an
 * unexpected body or status. Used when decoding the server\'s error payload into
 * `SendAccessTokenApiErrorResponse` fails, or for 5xx responses where no structured error is
 * available.
 */
export type UnexpectedIdentityError = string;

/**
 * Auth requests supports multiple initialization methods.
 */
export type AuthRequestMethod =
  | { userKey: { protected_user_key: UnsignedSharedKey } }
  | { masterKey: { protected_master_key: UnsignedSharedKey; auth_request_key: EncString } };

/**
 * Available fields on a cipher and can be copied from a the list view in the UI.
 */
export type CopyableCipherFields =
  | "LoginUsername"
  | "LoginPassword"
  | "LoginTotp"
  | "CardNumber"
  | "CardSecurityCode"
  | "IdentityUsername"
  | "IdentityEmail"
  | "IdentityPhone"
  | "IdentityAddress"
  | "SshKey"
  | "SecureNotes"
  | "BankAccountNameOnAccount"
  | "BankAccountAccountNumber"
  | "BankAccountRoutingNumber"
  | "BankAccountBranchNumber"
  | "BankAccountPin"
  | "BankAccountIban"
  | "BankAccountSwift"
  | "PassportGivenName"
  | "PassportSurname"
  | "PassportPassportNumber"
  | "PassportNationalIdentificationNumber"
  | "DriversLicenseFirstName"
  | "DriversLicenseMiddleName"
  | "DriversLicenseLastName"
  | "DriversLicenseLicenseNumber";

/**
 * Base64 encoded data
 *
 * Is indifferent about padding when decoding, but always produces padding when encoding.
 */
export type B64 = string;

/**
 * Basic client behavior settings. These settings specify the various targets and behavior of the
 * Bitwarden Client. They are optional and uneditable once the client is initialized.
 *
 * Defaults to
 *
 * ```
 * # use bitwarden_core::{ClientSettings, DeviceType};
 * let settings = ClientSettings {
 *     identity_url: \"https://identity.bitwarden.com\".to_string(),
 *     api_url: \"https://api.bitwarden.com\".to_string(),
 *     user_agent: \"Bitwarden Rust-SDK\".to_string(),
 *     device_type: DeviceType::SDK,
 *     bitwarden_client_version: None,
 *     bitwarden_package_type: None,
 *     device_identifier: None,
 * };
 * let default = ClientSettings::default();
 * ```
 */
export interface ClientSettings {
  /**
   * The identity url of the targeted Bitwarden instance. Defaults to `https://identity.bitwarden.com`
   */
  identityUrl?: string;
  /**
   * The api url of the targeted Bitwarden instance. Defaults to `https://api.bitwarden.com`
   */
  apiUrl?: string;
  /**
   * The user_agent to sent to Bitwarden. Defaults to `Bitwarden Rust-SDK`
   */
  userAgent?: string;
  /**
   * Device type to send to Bitwarden. Defaults to SDK
   */
  deviceType?: DeviceType;
  /**
   * Device identifier to send to Bitwarden. Optional for now in transition period.
   */
  deviceIdentifier?: string | undefined;
  /**
   * Bitwarden Client Version to send to Bitwarden. Optional for now in transition period.
   */
  bitwardenClientVersion?: string | undefined;
  /**
   * Bitwarden Package Type to send to Bitwarden. We should evaluate this field to see if it
   * should be optional later.
   */
  bitwardenPackageType?: string | undefined;
}

/**
 * Bootstrap configuration for server communication
 */
export type BootstrapConfig =
  { type: "direct" } | ({ type: "ssoCookieVendor" } & SsoCookieVendorConfig);

/**
 * Bootstrap configuration variant for [`SetCommunicationTypeRequest`]
 */
export type BootstrapConfigRequest =
  { type: "direct" } | ({ type: "ssoCookieVendor" } & SsoCookieVendorConfigRequest);

/**
 * Canonical connection-scoped alias identity.
 *
 * Equality and reconciliation use only `connection_id` plus the opaque `alias_id`. The address
 * is a required normalized integrity/display snapshot, never a join key.
 */
export interface AliasIdentity {
  /**
   * Provider-neutral contract version.
   */
  version: number;
  /**
   * Stable UUID v4 of the authorization that owns the alias.
   */
  connectionId: string;
  /**
   * Opaque provider-assigned identifier. It is not parsed, trimmed, or treated as numeric.
   */
  aliasId: string;
  /**
   * Normalized alias address retained as an integrity and display snapshot.
   */
  address: SensitiveString;
}

/**
 * Canonical deterministic reconciliation plan for one connection snapshot.
 */
export interface AliasReconciliationPlan {
  /**
   * Reconciliation report schema version.
   */
  version: number;
  /**
   * Plan mode, which must be dry-run before application.
   */
  mode: AliasReconciliationMode;
  /**
   * Stable UUID v4 of the configured provider connection.
   */
  connectionId: string;
  /**
   * Canonically ordered observations for the input snapshot.
   */
  outcomes: AliasReconciliationOutcome[];
  /**
   * Canonically ordered repairs derived from stale bindings.
   */
  actions: AliasReconciliationAction[];
  /**
   * Counts derived exactly from the outcomes and actions.
   */
  summary: AliasReconciliationSummary;
}

/**
 * Canonical v1 vault binding. Field order is normative for serialization.
 */
export interface AliasReference {
  /**
   * Canonical alias-reference schema version.
   */
  version: number;
  /**
   * Stable UUID v4 identifying the configured provider connection.
   */
  connectionId: string;
  /**
   * Opaque provider identifier. No numeric interpretation or normalization is permitted.
   */
  aliasId: string;
  /**
   * Normalized alias email address captured with the binding.
   */
  address: SensitiveString;
}

/**
 * Canonically ordered append-only event set.
 */
export interface AliasJournal {
  /**
   * Journal schema version.
   */
  version: number;
  /**
   * Stable authorization scope for every event, including create events without a remote ID.
   */
  connectionId: string;
  /**
   * Canonically ordered immutable event set.
   */
  events: AliasJournalEvent[];
}

/**
 * Coarse telemetry payload allowed by the product contract.
 */
export interface AliasTelemetryEvent {
  /**
   * Coarse operation category.
   */
  operation: AliasOperationKind;
  /**
   * Coarse client platform.
   */
  platform: AliasPlatform;
  /**
   * Stable error category, when the operation failed.
   */
  errorCode: AliasErrorCode | undefined;
  /**
   * Whether the operation succeeded.
   */
  success: boolean;
}

/**
 * Coarse telemetry payload allowed by the product contract.
 */
export type AliasPlatform = "web" | "browser-extension" | "desktop" | "cli" | "mobile" | "other";

/**
 * Common login response model used across different login methods.
 */
export type LoginResponse = { Authenticated: LoginSuccessResponse };

/**
 * Conflict status of a provider-neutral alias snapshot.
 */
export type AliasConsistency = "clean" | "conflicted";

/**
 * Controls how `bw send edit` updates the auth on an existing Send.
 */
export type AuthEdit = { type: "preserve" } | { type: "set"; auth: SendAuthType };

/**
 * Counts of what an import submitted to the server, broken down by cipher type so the client can
 * render its per-type result table.
 */
export interface ImportSummary {
  ciphers: CipherTypeCount[];
  folders: number;
  collections: number;
}

/**
 * Credentials for getting a send access token using an email and OTP.
 */
export interface SendEmailOtpCredentials {
  /**
   * The email address to which the OTP will be sent.
   */
  email: string;
  /**
   * The one-time password (OTP) that the user has received via email.
   */
  otp: string;
}

/**
 * Credentials for sending an OTP to the user\'s email address.
 * This is used when the send requires email verification with an OTP.
 */
export interface SendEmailCredentials {
  /**
   * The email address to which the OTP will be sent.
   */
  email: string;
}

/**
 * Credentials for sending password secured access requests.
 * Clone auto implements the standard lib\'s Clone trait, allowing us to create copies of this
 * struct.
 */
export interface SendPasswordCredentials {
  /**
   * A Base64-encoded hash of the password protecting the send.
   */
  passwordHashB64: string;
}

/**
 * Current availability state for PIN-based unlock.
 */
export type PinUnlockStatus = "Available" | "NeedsUnlock" | "NotSet";

/**
 * Custom administrative permissions for an organization member with the
 * [`OrganizationUserType::Custom`] role.
 */
export interface Permissions {
  /**
   * Can view the organization\'s event logs.
   */
  accessEventLogs?: boolean;
  /**
   * Can import and export organization vault data.
   */
  accessImportExport?: boolean;
  /**
   * Can access organization reports.
   */
  accessReports?: boolean;
  /**
   * Can create new collections.
   */
  createNewCollections?: boolean;
  /**
   * Can edit any collection, including those they are not assigned to.
   */
  editAnyCollection?: boolean;
  /**
   * Can delete any collection, including those they are not assigned to.
   */
  deleteAnyCollection?: boolean;
  /**
   * Can manage groups within the organization.
   */
  manageGroups?: boolean;
  /**
   * Can manage SSO configuration.
   */
  manageSso?: boolean;
  /**
   * Can manage organization policies.
   */
  managePolicies?: boolean;
  /**
   * Can manage organization members.
   */
  manageUsers?: boolean;
  /**
   * Can manage the account recovery (password reset) feature.
   */
  manageResetPassword?: boolean;
  /**
   * Can manage SCIM (System for Cross-domain Identity Management) configuration.
   */
  manageScim?: boolean;
}

/**
 * Decrypted file metadata of a file send.
 */
export interface SendAccessFileView {
  /**
   * The file ID
   */
  id: string | undefined;
  /**
   * The decrypted file name
   */
  fileName: string | undefined;
  /**
   * File size in bytes as a string
   */
  size: string | undefined;
  /**
   * Human-readable size (e.g. \"4.2 KB\")
   */
  sizeName: string | undefined;
}

/**
 * Decrypted text content of a text send.
 */
export interface SendAccessTextView {
  /**
   * The decrypted text content
   */
  text: string | undefined;
  /**
   * Whether to hide the text by default
   */
  hidden: boolean;
}

/**
 * Describes the source of an incoming IPC message with per-variant metadata.
 *
 * `Source` mirrors [`Endpoint`] but carries additional context about the sender
 * that the application layer needs for security decisions (e.g., checking `origin`
 * for web sources). Use [`From<Source> for Endpoint`] to convert a source into an
 * addressable endpoint (dropping the metadata).
 */
export type Source =
  | { Web: { tab_id: number; document_id: string; origin: string } }
  | { BrowserForeground: { id: number } }
  | { BrowserBackground: { id: HostId } }
  | "DesktopRenderer"
  | "DesktopMain";

/**
 * Destination options for a vault import.
 *
 * `organization_id` selects the destination: `None` imports into the user\'s personal vault (groups
 * become personal folders), `Some` imports into that organization (ciphers are encrypted with the
 * org key). `target_folder` (personal) and `target_collection` (organization) nest the import
 * under an existing destination, mirroring the client\'s import-target behavior; each carries both
 * its id and name together so a half-specified target can\'t be expressed. `restricted_types` are
 * dropped before submission.
 */
export interface ImportOptions {
  organization_id: OrganizationId | undefined;
  target_folder: ImportTargetFolder | undefined;
  target_collection: ImportTargetCollection | undefined;
  restricted_types: CipherType[];
}

/**
 * Deterministic journal reduction returned to callers.
 */
export interface AliasJournalState {
  /**
   * Latest selected state for each logical operation.
   */
  operations: AliasReducedOperation[];
  /**
   * Latest selected state for each connection-scoped alias.
   */
  resources: AliasReducedResource[];
  /**
   * Operation IDs or resource keys whose concurrent terminal facts cannot be silently chosen.
   */
  conflicts: string[];
}

/**
 * Deterministic result for one alias binding or skipped cipher.
 */
export type AliasReconciliationOutcome =
  | { status: "matched"; alias_id: string; cipher_id: CipherId }
  | {
      status: "staleBinding";
      alias_id: string;
      cipher_id: CipherId;
      reference_address_stale: boolean;
      username_stale: boolean;
    }
  | { status: "duplicateBinding"; alias_id: string; cipher_ids: CipherId[] }
  | { status: "missingAlias"; alias_id: string; cipher_id: CipherId }
  | { status: "unboundAlias"; alias_id: string }
  | {
      status: "skippedCipher";
      cipher_id: CipherId | undefined;
      reason: AliasReconciliationSkipReason;
    };

/**
 * Device information for login requests.
 * This is common across all login mechanisms and describes the device
 * making the authentication request.
 */
export interface LoginDeviceRequest {
  /**
   * The type of device making the login request
   * Note: today, we already have the DeviceType on the ApiConfigurations
   * but we do not have the other device fields so we will accept the device data at login time
   * for now. In the future, we might refactor the unauthN client to instantiate with full
   * device info which would deprecate this struct. However, using the device_type here
   * allows us to avoid any timing issues in scenarios where the device type could change
   * between client instantiation and login (unlikely but possible).
   */
  deviceType: DeviceType;
  /**
   * Unique identifier for the device
   */
  deviceIdentifier: string;
  /**
   * Human-readable name of the device
   */
  deviceName: string;
  /**
   * Push notification token for the device (only for mobile devices)
   */
  devicePushToken: string | undefined;
}

/**
 * Durable operation phase. A dispatched operation is never reduced to ordinary failure merely
 * because its response was lost.
 */
export type AliasOperationPhase =
  "prepared" | "dispatched" | "acknowledged" | "outcome-unknown" | "failed";

/**
 * Encrypted file metadata of a file send.
 */
export interface SendAccessFileResponse {
  /**
   * The file ID
   */
  id: string | undefined;
  /**
   * Encrypted file name
   */
  fileName: string | undefined;
  /**
   * File size in bytes as a string
   */
  size: string | undefined;
  /**
   * Human-readable size (e.g. \"4.2 KB\")
   */
  sizeName: string | undefined;
}

/**
 * Encrypted text content of a text send.
 */
export interface SendAccessTextResponse {
  /**
   * Encrypted text content
   */
  text: string | undefined;
  /**
   * Whether to hide the text by default
   */
  hidden: boolean;
}

/**
 * Encrypted, account-scoped connection metadata. Credentials, endpoints, labels, and adapter
 * configuration are intentionally outside the generated common contract.
 */
export interface AliasConnection {
  /**
   * Provider-neutral contract version.
   */
  version: number;
  /**
   * Stable UUID v4 assigned to this authorization.
   */
  connectionId: string;
  /**
   * Non-secret descriptor for the injected adapter.
   */
  adapter: AliasAdapterDescriptor;
}

/**
 * Every WebAuthn PRF credential the account can unlock with.
 */
export interface WebAuthnPrfUnlockData {
  /**
   * The credentials, in the order the server reported them.
   */
  options: WebAuthnPrfUnlockOption[];
}

/**
 * File download URL data returned from a send file access call.
 */
export interface SendFileDownloadData {
  /**
   * The file ID
   */
  id: string | undefined;
  /**
   * The pre-signed download URL
   */
  url: string | undefined;
}

/**
 * File-based send content
 */
export interface SendFile {
  /**
   * The file\'s ID
   */
  id: string | undefined;
  /**
   * The encrypted file name
   */
  fileName: EncString;
  /**
   * The file size in bytes as a string
   */
  size: string | undefined;
  /**
   * Readable size, ex: \"4.2 KB\" or \"1.43 GB\
   */
  sizeName: string | undefined;
}

/**
 * Freshness of a provider-neutral alias snapshot.
 */
export type AliasFreshness = "current" | "stale";

/**
 * Holds both V1 and V2 user keys, each wrapped by the other.
 */
export interface V2UpgradeToken {
  /**
   * V1 user key encrypted with V2 key (Cose_Encrypt0_B64 format)
   */
  wrapped_user_key_1: EncString;
  /**
   * V2 user key encrypted with V1 key (Aes256Cbc_HmacSha256_B64 format)
   */
  wrapped_user_key_2: EncString;
}

/**
 * IPC destination/source endpoint for SDK clients.
 *
 * Endpoints are categorized by their role in the connection topology:
 * - **Host endpoints** ([`HostId`]): Connection hubs that can be addressed relationally or
 *   specifically. ([`BrowserBackground`](Endpoint::BrowserBackground))
 * - **Leaf endpoints**: Addressed by transport-assigned IDs. ([`Web`](Endpoint::Web),
 *   [`BrowserForeground`](Endpoint::BrowserForeground))
 * - **Singleton endpoints**: Exactly one instance globally, no ID needed.
 *   ([`DesktopMain`](Endpoint::DesktopMain), [`DesktopRenderer`](Endpoint::DesktopRenderer))
 */
export type Endpoint =
  | { Web: { tab_id: number; document_id: string } }
  | { BrowserForeground: { id: number } }
  | { BrowserBackground: { id: HostId } }
  | "DesktopRenderer"
  | "DesktopMain";

/**
 * Identifies a host endpoint, one that manages connections for other endpoints.
 *
 * Host endpoints can be addressed relationally (when the sender has a direct connection
 * and there is only one from their perspective) or by a specific transport-assigned ID
 * (when distinguishing between multiple instances).
 */
export type HostId = "Own" | { Id: number };

/**
 * Input for creating a recipient-scoped send/reply identity.
 */
export interface CreateSendReplyIdentityRequest {
  /**
   * Alias that will own the send/reply identity.
   */
  alias: AliasIdentity;
  /**
   * Normalized recipient address.
   */
  recipient: SensitiveString;
}

/**
 * Input for one page of aliases.
 */
export interface ListAliasesRequest {
  /**
   * Opaque bounded continuation token. Absence requests the first page.
   */
  pageToken: string | undefined;
}

/**
 * Input for one-click alias creation through the injected adapter.
 */
export interface CreateAliasRequest {
  /**
   * Explicit post-action browsing context reduced to one normalized hostname.
   */
  hostname: SensitiveString | undefined;
}

/**
 * Invalid grant errors - typically due to invalid credentials.
 */
export type SendAccessTokenInvalidGrantError =
  "send_id_invalid" | "password_hash_b64_invalid" | "unknown";

/**
 * Invalid request errors - typically due to missing parameters.
 */
export type SendAccessTokenInvalidRequestError =
  | "send_id_required"
  | "password_hash_b64_required"
  | "email_required"
  | "email_and_otp_required"
  | "unknown";

/**
 * Key Derivation Function for Bitwarden Account
 *
 * In Bitwarden accounts can use multiple KDFs to derive their master key from their password. This
 * Enum represents all the possible KDFs.
 */
export type Kdf =
  | { pBKDF2: { iterations: NonZeroU32 } }
  | { argon2id: { iterations: NonZeroU32; memory: NonZeroU32; parallelism: NonZeroU32 } };

/**
 * Latest deterministic state for one connection-scoped alias resource.
 */
export interface AliasReducedResource {
  /**
   * Stable connection-scoped identity and latest address snapshot.
   */
  identity: AliasIdentity;
  /**
   * Latest selected lifecycle state.
   */
  lifecycle: AliasLifecycleState;
  /**
   * Whether a deletion tombstone prevents resurrection.
   */
  tombstoned: boolean;
  sequence: bigint;
  replicaId: string;
  eventId: string;
  causal: AliasCausalEntry[];
}

/**
 * Latest deterministic state for one logical operation.
 */
export interface AliasReducedOperation {
  /**
   * UUID v4 of the logical operation.
   */
  operationId: string;
  /**
   * Provider-neutral operation category.
   */
  operation: AliasOperationKind;
  /**
   * Latest causally selected durable phase.
   */
  phase: AliasOperationPhase;
  /**
   * Stable target identity, when the operation has one.
   */
  target: AliasIdentity | undefined;
  /**
   * Desired or acknowledged lifecycle, when applicable.
   */
  lifecycle: AliasLifecycleState | undefined;
  /**
   * Stable failure category, when applicable.
   */
  error: AliasErrorCode | undefined;
  sequence: bigint;
  replicaId: string;
  eventId: string;
  causal: AliasCausalEntry[];
}

/**
 * Login cipher data needed for risk evaluation.
 */
export interface CipherLoginDetails {
  /**
   * Cipher ID to identify which cipher in results.
   */
  id: CipherId;
  /**
   * The decrypted password to evaluate.
   */
  password: string;
  /**
   * Username or email (login ciphers only have one field).
   */
  username: string | undefined;
}

/**
 * Metadata for opening a new attachment slot on the server.
 *
 * The caller pre-encrypts the key, file name, and contents; the SDK only opens the slot and
 * the caller uploads. See `upgrade_attachment` for the alternative where the SDK owns the
 * encryption and upload.
 */
export interface CreateAttachmentRequest {
  /**
   * Encrypted attachment key.
   */
  key: EncString;
  /**
   * Encrypted file name.
   */
  fileName: EncString;
  /**
   * Encrypted file size in byte
   */
  fileSize: number;
  /**
   * Cipher revision date
   */
  lastKnownRevisionDate: DateTime<Utc>;
  /**
   * Uses the admin auth scope. The server returns a
   * `CipherMiniResponseModel`, and the local repository is not updated.
   */
  asAdmin: boolean;
}

/**
 * Minimal BankAccountView only including the needed details for list views
 */
export interface BankAccountListView {
  /**
   * The account number of the bank account.
   */
  accountNumber: string | undefined;
  /**
   * The type of the bank account, e.g. Checking, Savings, etc.
   */
  accountType: string | undefined;
}

/**
 * Minimal CardView only including the needed details for list views
 */
export interface CardListView {
  /**
   * The brand of the card, e.g. Visa, Mastercard, etc.
   */
  brand: string | undefined;
}

/**
 * Minimal field view for list/search operations.
 * Contains only the fields needed for search indexing.
 */
export interface FieldListView {
  /**
   * Only populated if the field has a name.
   */
  name: string | undefined;
  /**
   * Only populated for [FieldType::Text] fields.
   */
  value: string | undefined;
  /**
   * The field type.
   */
  type: FieldType;
}

/**
 * NewType wrapper for `CipherId`
 */
export type CipherId = Tagged<Uuid, "CipherId">;

/**
 * NewType wrapper for `CollectionId`
 */
export type CollectionId = Tagged<Uuid, "CollectionId">;

/**
 * NewType wrapper for `FolderId`
 */
export type FolderId = Tagged<Uuid, "FolderId">;

/**
 * NewType wrapper for `OrganizationId`
 */
export type OrganizationId = Tagged<Uuid, "OrganizationId">;

/**
 * NewType wrapper for `SendId`
 */
export type SendId = Tagged<Uuid, "SendId">;

/**
 * NewType wrapper for `UserId`
 */
export type UserId = Tagged<Uuid, "UserId">;

/**
 * Non-secret adapter descriptor stored only with encrypted connection metadata.
 */
export interface AliasAdapterDescriptor {
  /**
   * Extensible lowercase adapter identifier, never an enum.
   */
  adapterId: string;
  /**
   * Canonical baseline and extension capabilities exposed by the adapter.
   */
  capabilities: AliasProviderCapabilities;
}

/**
 * Number of imported ciphers of a given type.
 */
export interface CipherTypeCount {
  type: CipherType;
  count: number;
}

/**
 * One entry in an event\'s vector clock. Entries must be sorted by replica ID and unique.
 */
export interface AliasCausalEntry {
  /**
   * UUID v4 of the observed replica.
   */
  replicaId: string;
  /**
   * Greatest observed sequence for that replica.
   */
  sequence: bigint;
}

/**
 * One page of recipient-scoped send/reply identities.
 */
export interface SendReplyIdentityPage {
  /**
   * Validated identities in this page.
   */
  identities: SendReplyIdentity[];
  /**
   * Opaque continuation token, or `None` at the end.
   */
  nextPageToken: string | undefined;
}

/**
 * One validated page of provider-neutral aliases.
 */
export interface AliasPage {
  /**
   * Validated aliases in this page.
   */
  aliases: Alias[];
  /**
   * Opaque continuation token, or `None` at the end.
   */
  nextPageToken: string | undefined;
}

/**
 * Open-organization-invite data to include on the register-finish payload.
 */
export interface RegistrationFinishOpenOrgInviteData {
  /**
   * The organization the registrant is joining via the open invite link.
   */
  organization_id: OrganizationId;
  /**
   * The bearer code from the shared invite URL. Must be a UUID.
   */
  code: string;
}

/**
 * Options for configuring risk computation.
 */
export interface CipherRiskOptions {
  /**
   * Pre-computed password reuse map (password → count).
   * If provided, enables reuse detection across ciphers.
   */
  passwordMap?: PasswordReuseMap | undefined;
  /**
   * Whether to check passwords against Have I Been Pwned API.
   * When true, makes network requests to check for exposed passwords.
   */
  checkExposed?: boolean;
  /**
   * Optional HIBP API base URL override. When None, uses the production HIBP URL.
   * Can be used for testing or alternative password breach checking services.
   */
  hibpBaseUrl?: string | undefined;
}

/**
 * Organization membership details from the user\'s profile sync.
 *
 * Contains the full set of entitlements, plan features, and metadata for a single
 * organization that the current user belongs to.
 */
export interface ProfileOrganization {
  /**
   * Unique identifier for the organization.
   */
  id: Uuid;
  /**
   * Display name of the organization.
   */
  name: string;
  /**
   * The user\'s membership status in the organization.
   */
  status: OrganizationUserStatusType;
  /**
   * The user\'s role in the organization.
   */
  type: OrganizationUserType;
  /**
   * Whether the organization is currently enabled.
   */
  enabled: boolean;
  /**
   * Whether the organization has access to policies features.
   */
  usePolicies: boolean;
  /**
   * Whether the organization has access to groups features.
   */
  useGroups: boolean;
  /**
   * Whether the organization has access to directory sync features.
   */
  useDirectory: boolean;
  /**
   * Whether the organization has access to event logging features.
   */
  useEvents: boolean;
  /**
   * Whether the organization can enforce TOTP for members.
   */
  useTotp: boolean;
  /**
   * Whether the organization has access to two-factor authentication features.
   */
  use2fa: boolean;
  /**
   * Whether the organization has access to the Bitwarden Public API.
   */
  useApi: boolean;
  /**
   * Whether the organization has access to SSO features.
   */
  useSso: boolean;
  /**
   * Whether the organization can manage verified domains.
   */
  useOrganizationDomains: boolean;
  /**
   * Whether the organization uses Key Connector for decryption.
   */
  useKeyConnector: boolean;
  /**
   * Whether the organization has access to SCIM provisioning.
   */
  useScim: boolean;
  /**
   * Whether the organization can use the [`OrganizationUserType::Custom`] role.
   */
  useCustomPermissions: boolean;
  /**
   * Whether the organization has access to the account recovery (admin password reset) feature.
   */
  useResetPassword: boolean;
  /**
   * Whether the organization has access to Secrets Manager.
   */
  useSecretsManager: boolean;
  /**
   * Whether the organization has access to Password Manager.
   */
  usePasswordManager: boolean;
  /**
   * Whether the organization can use the activate autofill policy.
   */
  useActivateAutofillPolicy: boolean;
  /**
   * Whether the organization can automatically confirm new members without manual admin
   * approval.
   */
  useAutomaticUserConfirmation: boolean;
  /**
   * Whether the organization can create a license file for a self-hosted instance.
   */
  selfHost: boolean;
  /**
   * Whether organization members receive premium features.
   */
  usersGetPremium: boolean;
  /**
   * The number of licensed seats for the organization.
   */
  seats: number | undefined;
  /**
   * The maximum number of collections the organization can create.
   */
  maxCollections: number | undefined;
  /**
   * The maximum encrypted storage in gigabytes, if limited.
   */
  maxStorageGb: number | undefined;
  /**
   * Whether the current user\'s account is bound to this organization via SSO.
   */
  ssoBound: boolean;
  /**
   * The organization\'s SSO identifier.
   */
  identifier: string | undefined;
  /**
   * The current user\'s custom permissions, relevant when [`OrganizationUserType::Custom`] is
   * the user\'s `type`.
   */
  permissions: Permissions;
  /**
   * Whether the current user is enrolled in account recovery for this organization.
   */
  resetPasswordEnrolled: boolean;
  /**
   * The current user\'s personal user ID.
   */
  userId: Uuid | undefined;
  /**
   * The current user\'s organization membership ID.
   */
  organizationUserId: Uuid | undefined;
  /**
   * Whether the organization has both a public and private key configured.
   */
  hasPublicAndPrivateKeys: boolean;
  /**
   * The ID of the provider managing this organization, if any.
   */
  providerId: Uuid | undefined;
  /**
   * The name of the provider managing this organization, if any.
   */
  providerName: string | undefined;
  /**
   * The type of provider managing this organization, if any.
   */
  providerType: ProviderType | undefined;
  /**
   * Whether the current user accesses this organization through a provider.
   */
  isProviderUser: boolean;
  /**
   * Whether the current user is a direct member of this organization (as opposed to
   * provider-only access).
   */
  isMember: boolean;
  /**
   * The friendly name of a pending families sponsorship, if any.
   */
  familySponsorshipFriendlyName: string | undefined;
  /**
   * Whether the organization can sponsor a families plan for the current user.
   */
  familySponsorshipAvailable: boolean;
  /**
   * The subscription tier of the organization.
   */
  productTierType: ProductTierType;
  /**
   * Whether Key Connector is enabled for this organization.
   */
  keyConnectorEnabled: boolean;
  /**
   * The URL of the Key Connector service, if enabled.
   */
  keyConnectorUrl: string | undefined;
  /**
   * The date the families sponsorship was last synced, if applicable.
   */
  familySponsorshipLastSyncDate: DateTime<Utc> | undefined;
  /**
   * The date the families sponsorship expires, if applicable.
   */
  familySponsorshipValidUntil: DateTime<Utc> | undefined;
  /**
   * Whether the families sponsorship is scheduled for deletion.
   */
  familySponsorshipToDelete: boolean | undefined;
  /**
   * Whether the current user has access to Secrets Manager for this organization.
   */
  accessSecretsManager: boolean;
  /**
   * Whether collection creation is restricted to owners and admins only.
   *
   * When `false`, any member can create collections and automatically receives manage
   * permissions over collections they create.
   */
  limitCollectionCreation: boolean;
  /**
   * Whether collection deletion is restricted to owners and admins only.
   *
   * When `true`, regular users cannot delete collections that they manage.
   */
  limitCollectionDeletion: boolean;
  /**
   * Whether item deletion is restricted to members with the Manage collection permission.
   *
   * When `false`, members with Edit permission can also delete items within their collections.
   */
  limitItemDeletion: boolean;
  /**
   * Whether owners and admins have implicit manage permissions over all collections.
   *
   * When `true`, owners and admins can alter items, groups, and permissions across all
   * collections without requiring explicit collection assignments.
   * When `false`, admins can only access collections where they have been explicitly assigned.
   */
  allowAdminAccessToAllCollectionItems: boolean;
  /**
   * Whether the current user\'s account is managed by this organization.
   */
  userIsManagedByOrganization: boolean;
  /**
   * Whether the organization has access to Access Intelligence features.
   */
  useAccessIntelligence: boolean;
  /**
   * Whether the organization can sponsor families plans for members (Families For Enterprises).
   */
  useAdminSponsoredFamilies: boolean;
  /**
   * Whether Secrets Manager ads are disabled for users.
   */
  useDisableSMAdsForUsers: boolean;
  /**
   * Whether the organization\'s Families For Enterprises sponsorship was initiated by an admin.
   */
  isAdminInitiated: boolean;
  /**
   * Whether SSO login is currently enabled for this organization.
   */
  ssoEnabled: boolean;
  /**
   * The decryption type used for SSO members, if SSO is enabled.
   */
  ssoMemberDecryptionType: MemberDecryptionType | undefined;
  /**
   * Whether the organization has access to phishing blocker features.
   */
  usePhishingBlocker: boolean;
  /**
   * Whether the organization has access to the My Items collection feature.
   * This allows users to store personal items in the organization vault
   * if the Centralize Organization Ownership policy is enabled.
   */
  useMyItems: boolean;
}

/**
 * Owned cipher collection and result returned by binding-friendly application APIs.
 */
export interface AliasReconciliationApplyOutput {
  /**
   * Input ciphers with validated repairs applied.
   */
  ciphers: CipherView[];
  /**
   * Mutation result for the application.
   */
  result: AliasReconciliationApplyResult;
}

/**
 * Passphrase generator request options.
 */
export interface PassphraseGeneratorRequest {
  /**
   * Number of words in the generated passphrase.
   * This value must be between 3 and 20.
   */
  numWords: number;
  /**
   * Character separator between words in the generated passphrase. The value cannot be empty.
   */
  wordSeparator: string;
  /**
   * When set to true, capitalize the first letter of each word in the generated passphrase.
   */
  capitalize: boolean;
  /**
   * When set to true, include a number at the end of one of the words in the generated
   * passphrase.
   */
  includeNumber: boolean;
}

/**
 * Password generator request options.
 */
export interface PasswordGeneratorRequest {
  /**
   * Include lowercase characters (a-z).
   */
  lowercase: boolean;
  /**
   * Include uppercase characters (A-Z).
   */
  uppercase: boolean;
  /**
   * Include numbers (0-9).
   */
  numbers: boolean;
  /**
   * Include special characters: ! @ # $ % ^ & *
   */
  special: boolean;
  /**
   * The length of the generated password.
   * Note that the password length must be greater than the sum of all the minimums.
   */
  length: number;
  /**
   * When set to true, the generated password will not contain ambiguous characters.
   * The ambiguous characters are: I, O, l, 0, 1
   */
  avoidAmbiguous: boolean;
  /**
   * The minimum number of lowercase characters in the generated password.
   * When set, the value must be between 1 and 9. This value is ignored if lowercase is false.
   */
  minLowercase: number | undefined;
  /**
   * The minimum number of uppercase characters in the generated password.
   * When set, the value must be between 1 and 9. This value is ignored if uppercase is false.
   */
  minUppercase: number | undefined;
  /**
   * The minimum number of numbers in the generated password.
   * When set, the value must be between 1 and 9. This value is ignored if numbers is false.
   */
  minNumber: number | undefined;
  /**
   * The minimum number of special characters in the generated password.
   * When set, the value must be between 1 and 9. This value is ignored if special is false.
   */
  minSpecial: number | undefined;
  /**
   * Custom characters that must each be available to the generator and from which at least
   * one character is guaranteed to appear in the output. Each character of the string is
   * treated as a member of the custom required set. Non-ASCII-printable characters are
   * silently dropped during validation.
   *
   * This is primarily used by the HTML `passwordrules` parser to honor custom required
   * character classes (e.g. `required: [!#$]`).
   */
  customRequiredChars?: string;
  /**
   * Custom characters that are added to the overall pool of allowed characters, but are not
   * required to appear. Each character of the string is treated as a member of the custom
   * allowed set. Non-ASCII-printable characters are silently dropped during validation.
   *
   * This is primarily used by the HTML `passwordrules` parser to honor custom allowed
   * character classes (e.g. `allowed: [-_.]`).
   */
  customAllowedChars?: string;
  /**
   * The maximum number of consecutive identical characters allowed in the generated password,
   * as expressed by the HTML `passwordrules` `max-consecutive` property. `None` disables
   * the check; `Some(0)` is invalid and rejected at request validation. Enforced via
   * re-shuffle with a single-pass repair fallback for degenerate pool sizes.
   */
  maxConsecutive?: number;
}

/**
 * Password reuse map wrapper for WASM compatibility.
 */
export type PasswordReuseMap = Record<string, number>;

/**
 * Pin unlock can be configured to use one of two modes. Before-first-unlock and
 * after-first-unlock. In AFU mode, the PIN is available only after unlocking once with the master
 * password or another unlock method. In BFU mode, PIN unlock is available right after app start.
 * For this, the PIN-encrypted vault key is stored on disk.
 */
export type PinLockType = "BeforeFirstUnlock" | "AfterFirstUnlock";

/**
 * Plaintext open-organization-invite payload. Passed into
 * [`crate::registration::registration_client::RegistrationClient::seal_open_org_invite_data`] to
 * seal to be used in the registration email verification link, and returned by
 * [`crate::registration::registration_client::RegistrationClient::unseal_open_org_invite_data`]
 * for the acceptance flow.
 */
export interface OpenOrgInvite {
  /**
   * The organization the registrant is joining.
   */
  organizationId: string;
  /**
   * The public invite link code carried in the shared invite URL.
   */
  inviteLinkCode: string;
  /**
   * The invite secret associated with the invite link.
   */
  inviteSecret: string;
}

/**
 * Plaintext view of a [`SendAccessResponse`], produced by
 * [`SendAccessKey::decrypt_response`].
 *
 * Mirrors the legacy CLI\'s `SendAccessResponse` output shape (`apps/cli`) so that a
 * JSON dump of a received send stays recognizable to existing scripts, with two
 * additions the wire response already carries (`expirationDate`, `creatorIdentifier`).
 *
 * `text`/`file` are kept as independent `Option`s rather than collapsed into an enum with
 * associated data: `type_` is `Option<SendType>` on the wire and an unrecognized or absent
 * discriminant must still round-trip (both the legacy CLI and `bw receive` fall back to
 * dumping whatever the server returned), which a total enum could not represent.
 */
export interface SendAccessView {
  /**
   * The send access ID
   */
  id: string | undefined;
  /**
   * The send type.
   */
  type: SendType | undefined;
  /**
   * The decrypted send name. `None` when the send has no name, which is not an error —
   * a nameless text send still has printable content.
   */
  name: string | undefined;
  /**
   * Decrypted text content (if type is Text)
   */
  text: SendAccessTextView | undefined;
  /**
   * Decrypted file metadata (if type is File)
   */
  file: SendAccessFileView | undefined;
  /**
   * When the send expires.
   */
  expirationDate: DateTime<Utc> | undefined;
  /**
   * The creator\'s identifier (email), if not hidden
   */
  creatorIdentifier: string | undefined;
}

/**
 * Provider-confirmed lifecycle state of an alias.
 */
export type AliasLifecycleState = "enabled" | "disabled" | "deleted";

/**
 * Provider-neutral alias snapshot. Provider-native payloads and provider-owned names/notes are
 * deliberately absent.
 */
export interface Alias {
  /**
   * Stable connection-scoped identity.
   */
  identity: AliasIdentity;
  /**
   * Current lifecycle state.
   */
  lifecycle: AliasLifecycleState;
  /**
   * Snapshot freshness.
   */
  freshness: AliasFreshness;
  /**
   * Snapshot conflict status.
   */
  consistency: AliasConsistency;
  /**
   * Password-manager-owned encrypted label. Adapters always return `None`.
   */
  label: SensitiveString | undefined;
  /**
   * Capabilities of the adapter that returned this snapshot.
   */
  capabilities: AliasProviderCapabilities;
}

/**
 * Provider-neutral operation names. These are the only operation details allowed in telemetry.
 */
export type AliasOperationKind =
  | "create"
  | "list"
  | "get"
  | "enable"
  | "disable"
  | "delete"
  | "create-send-reply-identity"
  | "list-send-reply-identities"
  | "remove-send-reply-identity"
  | "set-send-reply-blocked"
  | "reconcile";

/**
 * Provider-neutral repair proposed by a reconciliation plan.
 */
export type AliasReconciliationAction = {
  action: "refresh";
  alias_id: string;
  cipher_id: CipherId;
  reference_address_stale: boolean;
  username_stale: boolean;
};

/**
 * Public SDK request model for logging in via password
 */
export interface PasswordLoginRequest {
  /**
   * Common login request fields
   */
  loginRequest: LoginRequest;
  /**
   * User\'s email address
   */
  email: string;
  /**
   * User\'s master password
   */
  password: string;
  /**
   * Prelogin data required for password authentication
   * (e.g., KDF configuration for deriving the master key)
   */
  preloginResponse: PasswordPreloginResponse;
}

/**
 * RPC response for [`UnlockBiometricsRequest`]. `user_key` is `None` if the
 * biometric prompt was canceled or otherwise failed on the responding device.
 */
export interface UnlockBiometricsResponse {
  /**
   * The unlocked user\'s symmetric key, if the unlock succeeded.
   */
  user_key?: SymmetricKey;
}

/**
 * Recipient-scoped service-issued address for initiating or continuing a conversation.
 */
export interface SendReplyIdentity {
  /**
   * Alias that owns this recipient-scoped identity.
   */
  alias: AliasIdentity;
  /**
   * Opaque provider-assigned send/reply identity identifier.
   */
  identityId: string;
  /**
   * Normalized recipient address.
   */
  recipient: SensitiveString;
  /**
   * Normalized service-issued address used to send or reply.
   */
  address: SensitiveString;
  /**
   * Whether the identity is currently usable.
   */
  valid: boolean;
  /**
   * Present only when the negotiated `send-reply.block` extension exists.
   */
  blocked: boolean | undefined;
}

/**
 * Represents errors that can occur when requesting a send access token.
 * It includes expected and unexpected API errors.
 */
export type SendAccessTokenError =
  | { kind: "unexpected"; data: UnexpectedIdentityError }
  | { kind: "expected"; data: SendAccessTokenApiErrorResponse };

/**
 * Represents the data required to authenticate with the master password.
 */
export interface MasterPasswordAuthenticationData {
  kdf: Kdf;
  salt: string;
  masterPasswordAuthenticationHash: B64;
}

/**
 * Represents the data required to unlock with the master password.
 */
export interface MasterPasswordUnlockData {
  /**
   * The key derivation function used to derive the master key
   */
  kdf: Kdf;
  /**
   * The master key wrapped user key
   */
  masterKeyWrappedUserKey: EncString;
  /**
   * The salt used in the KDF, typically the user\'s email
   */
  salt: string;
}

/**
 * Represents the inner data of a cipher view.
 */
export type CipherViewType =
  | { login: LoginView }
  | { card: CardView }
  | { identity: IdentityView }
  | { secureNote: SecureNoteView }
  | { sshKey: SshKeyView }
  | { bankAccount: BankAccountView }
  | { passport: PassportView }
  | { driversLicense: DriversLicenseView };

/**
 * Represents the local user data key, wrapped by user key.
 * This key is used to encrypt local user data (e.g., password generator history).
 */
export interface LocalUserDataKeyState {
  wrapped_key: EncString;
}

/**
 * Represents the possible, expected errors that can occur when requesting a send access token.
 */
export type SendAccessTokenApiErrorResponse =
  | {
      error: "invalid_request";
      error_description?: string;
      send_access_error_type?: SendAccessTokenInvalidRequestError;
    }
  | {
      error: "invalid_grant";
      error_description?: string;
      send_access_error_type?: SendAccessTokenInvalidGrantError;
    }
  | { error: "invalid_client"; error_description?: string }
  | { error: "unauthorized_client"; error_description?: string }
  | { error: "unsupported_grant_type"; error_description?: string }
  | { error: "invalid_scope"; error_description?: string }
  | { error: "invalid_target"; error_description?: string };

/**
 * Represents the request to initialize the user\'s organizational cryptographic state.
 */
export interface InitOrgCryptoRequest {
  /**
   * The encryption keys for all the organizations the user is a part of
   */
  organizationKeys: Map<OrganizationId, UnsignedSharedKey>;
}

/**
 * Represents the result of decrypting a list of ciphers.
 *
 * This struct contains two vectors: `successes` and `failures`.
 * `successes` contains the decrypted `CipherListView` objects,
 * while `failures` contains the original `Cipher` objects that failed to decrypt.
 */
export interface DecryptCipherListResult {
  /**
   * The decrypted `CipherListView` objects.
   */
  successes: CipherListView[];
  /**
   * The original `Cipher` objects that failed to decrypt.
   */
  failures: Cipher[];
}

/**
 * Represents the result of decrypting a list of ciphers.
 *
 * This struct contains two vectors: `successes` and `failures`.
 * `successes` contains the decrypted `CipherView` objects,
 * while `failures` contains the original `Cipher` objects that failed to decrypt.
 */
export interface DecryptCipherResult {
  /**
   * The decrypted `CipherView` objects.
   */
  successes: CipherView[];
  /**
   * The original `Cipher` objects that failed to decrypt.
   */
  failures: Cipher[];
}

/**
 * Represents the result of fetching and decrypting all ciphers for an organization.
 *
 * Contains the encrypted ciphers from the API alongside their decrypted list views.
 */
export interface ListOrganizationCiphersResult {
  /**
   * All encrypted ciphers returned from the API.
   */
  ciphers: Cipher[];
  /**
   * Successfully decrypted `CipherListView` objects.
   */
  listViews: CipherListView[];
}

/**
 * Request for deriving a pin protected user key
 */
export interface DerivePinKeyResponse {
  /**
   * [UserKey][bitwarden_crypto::UserKey] protected by PIN
   */
  pinProtectedUserKey: EncString;
  /**
   * PIN protected by [UserKey][bitwarden_crypto::UserKey]
   */
  encryptedPin: EncString;
}

/**
 * Request for deriving a pin protected user key
 */
export interface EnrollPinResponse {
  /**
   * [UserKey][bitwarden_crypto::UserKey] protected by PIN
   */
  pinProtectedUserKeyEnvelope: PasswordProtectedKeyEnvelope;
  /**
   * PIN protected by [UserKey][bitwarden_crypto::UserKey]
   */
  userKeyEncryptedPin: EncString;
}

/**
 * Request for migrating an account from password to key connector.
 */
export interface DeriveKeyConnectorRequest {
  /**
   * Encrypted user key, used to validate the master key
   */
  userKeyEncrypted: EncString;
  /**
   * The user\'s master password
   */
  password: string;
  /**
   * The KDF parameters used to derive the master key
   */
  kdf: Kdf;
  /**
   * The user\'s email address
   */
  email: string;
}

/**
 * Request model for creating a new Send.
 */
export interface SendAddRequest {
  /**
   * The name of the Send.
   */
  name: string;
  /**
   * Optional notes visible to the sender.
   */
  notes: string | undefined;
  /**
   * The type and content of the Send.
   */
  viewType: SendViewType;
  /**
   * Maximum number of times the Send can be accessed.
   */
  maxAccessCount: number | undefined;
  /**
   * Whether the Send is disabled and cannot be accessed.
   */
  disabled: boolean;
  /**
   * Whether to hide the sender\'s email from recipients.
   */
  hideEmail: boolean;
  /**
   * Date and time when the Send will be permanently deleted.
   */
  deletionDate: DateTime<Utc>;
  /**
   * Optional date and time when the Send expires and can no longer be accessed.
   */
  expirationDate: DateTime<Utc> | undefined;
  /**
   * Authentication method for accessing this Send.
   */
  auth: SendAuthType;
}

/**
 * Request model for editing an existing Send.
 */
export interface SendEditRequest {
  /**
   * The name of the Send.
   */
  name: string;
  /**
   * Optional notes visible to the sender.
   */
  notes: string | undefined;
  /**
   * The type and content of the Send.
   */
  viewType: SendViewType;
  /**
   * Maximum number of times the Send can be accessed.
   */
  maxAccessCount: number | undefined;
  /**
   * Whether the Send is disabled and cannot be accessed.
   */
  disabled: boolean;
  /**
   * Whether to hide the sender\'s email from recipients.
   */
  hideEmail: boolean;
  /**
   * Date and time when the Send will be permanently deleted.
   */
  deletionDate: DateTime<Utc>;
  /**
   * Optional date and time when the Send expires and can no longer be accessed.
   */
  expirationDate: DateTime<Utc> | undefined;
  /**
   * Authentication for accessing this Send. Use `AuthEdit::Preserve` to keep the
   * existing auth on partial edits.
   */
  auth: AuthEdit;
}

/**
 * Request parameters for SSO JIT master password registration.
 */
export interface JitMasterPasswordRegistrationRequest {
  /**
   * Organization ID to enroll in
   */
  org_id: OrganizationId;
  /**
   * Organization\'s public key for encrypting the reset password key. This should be verified by
   * the client and not verifying may compromise the security of the user\'s account.
   */
  org_public_key: B64;
  /**
   * Organization SSO identifier
   */
  organization_sso_identifier: string;
  /**
   * User ID for the account being initialized
   */
  user_id: UserId;
  /**
   * Salt for master password hashing, usually email
   */
  salt: string;
  /**
   * Master password for the account
   */
  master_password: string;
  /**
   * Optional hint for the master password
   */
  master_password_hint: string | undefined;
  /**
   * Should enroll user into admin password reset
   */
  reset_password_enroll: boolean;
}

/**
 * Request parameters for TDE (Trusted Device Encryption) registration.
 */
export interface TdeRegistrationRequest {
  /**
   * Organization ID to enroll in
   */
  org_id: OrganizationId;
  /**
   * Organization\'s public key for encrypting the reset password key. This should be verified by
   * the client and not verifying may compromise the security of the user\'s account.
   */
  org_public_key: B64;
  /**
   * User ID for the account being initialized
   */
  user_id: UserId;
  /**
   * Device identifier for TDE enrollment
   */
  device_identifier: string;
  /**
   * Whether to trust this device for TDE
   */
  trust_device: boolean;
}

/**
 * Request parameters for master password registration
 */
export interface UserMasterPasswordRegistrationRequest {
  /**
   * Email for the account being initialized
   */
  email: string;
  /**
   * Salt for master password hashing
   */
  salt: string;
  /**
   * Master password for the account
   */
  master_password: string;
  /**
   * Optional hint for the master password
   */
  master_password_hint: string | undefined;
  /**
   * Optional token for email verification
   */
  email_verification_token: string | undefined;
  /**
   * Optional token for sales-assisted trial/registration
   */
  sales_assisted_token: string | undefined;
  /**
   * Optional organization user ID for organization invitations
   */
  organization_user_id: OrganizationId | undefined;
  /**
   * Optional direct organization invite token for joining an organization
   */
  org_invite_token: string | undefined;
  /**
   * Optional token for sponsored free family plan
   */
  org_sponsored_free_family_plan_token: string | undefined;
  /**
   * Optional token for accepting emergency access invitation
   */
  accept_emergency_access_invite_token: string | undefined;
  /**
   * Optional emergency access ID for accepting emergency access invitation
   */
  accept_emergency_access_id: UserId | undefined;
  /**
   * Optional provider invite token for joining as a provider
   */
  provider_invite_token: string | undefined;
  /**
   * Optional provider user ID for provider invitations
   */
  provider_user_id: UserId | undefined;
  /**
   * Optional open-organization-invite identifiers when finishing registration with an open
   * organization invite link in client state.
   */
  open_org_invite: RegistrationFinishOpenOrgInviteData | undefined;
}

/**
 * Request to add a cipher.
 */
export interface CipherCreateRequest {
  organizationId: OrganizationId | undefined;
  collectionIds: CollectionId[];
  folderId: FolderId | undefined;
  name: string;
  notes: string | undefined;
  favorite: boolean;
  reprompt: CipherRepromptType;
  type: CipherViewType;
  fields: FieldView[];
  archivedDate?: DateTime<Utc>;
}

/**
 * Request to add or edit a folder.
 */
export interface FolderAddEditRequest {
  /**
   * The new name of the folder.
   */
  name: string;
}

/**
 * Request to edit a cipher.
 */
export interface CipherEditRequest {
  id: CipherId;
  organizationId: OrganizationId | undefined;
  folderId: FolderId | undefined;
  favorite: boolean;
  reprompt: CipherRepromptType;
  name: string;
  notes: string | undefined;
  fields: FieldView[];
  type: CipherViewType;
  revisionDate: DateTime<Utc>;
  archivedDate: DateTime<Utc> | undefined;
  attachments: AttachmentView[];
  key: EncString | undefined;
}

/**
 * Request to set server communication configuration for a hostname
 *
 * This is the input type for
 * [`ServerCommunicationConfigClient::set_communication_type`](crate::ServerCommunicationConfigClient::set_communication_type).
 * Unlike [`ServerCommunicationConfig`], this type does not include acquired cookies,
 * since cookies are managed separately via
 * [`ServerCommunicationConfigClient::acquire_cookie`](crate::ServerCommunicationConfigClient::acquire_cookie).
 */
export interface SetCommunicationTypeRequest {
  /**
   * Bootstrap configuration determining how to establish server communication
   */
  bootstrap: BootstrapConfigRequest;
}

/**
 * Request to update the subset of cipher fields that a user without edit
 * permissions is still allowed to change (`folder_id` and `favorite`).
 *
 * Backed by the `PUT /ciphers/{id}/partial` server endpoint, which authorizes
 * based on view (not edit) access.
 */
export interface CipherPartialEditRequest {
  id: CipherId;
  folderId: FolderId | undefined;
  favorite: boolean;
}

/**
 * Required and negotiated behavior exposed by an adapter.
 *
 * Baseline flags are explicit so first-class qualification is deterministic. Optional behavior
 * uses validated identifiers instead of a closed provider-specific enum.
 */
export interface AliasProviderCapabilities {
  /**
   * Supports one-click alias creation.
   */
  create: boolean;
  /**
   * Supports paginated alias listing.
   */
  list: boolean;
  /**
   * Supports reading one alias by stable identity.
   */
  get: boolean;
  /**
   * Supports explicit enable and disable operations.
   */
  enableDisable: boolean;
  /**
   * Supports idempotent deletion.
   */
  delete: boolean;
  /**
   * Supports creating recipient-scoped send/reply identities.
   */
  createSendReplyIdentity: boolean;
  /**
   * Supports listing recipient-scoped send/reply identities.
   */
  listSendReplyIdentities: boolean;
  /**
   * Supports removing recipient-scoped send/reply identities.
   */
  removeSendReplyIdentity: boolean;
  /**
   * Sorted unique extension identifiers such as `send-reply.block`.
   */
  extensions: string[];
}

/**
 * Response containing the data required before password-based authentication
 */
export interface PasswordPreloginResponse {
  /**
   * The Key Derivation Function (KDF) configuration for the user
   */
  kdf: Kdf;
  /**
   * The salt used in the KDF process
   */
  salt: string;
}

/**
 * Response for the `make_keys_for_user_crypto_v2`, containing a set of keys for a user
 */
export interface UserCryptoV2KeysResponse {
  /**
   * User key
   */
  userKey: B64;
  /**
   * Wrapped private key
   */
  privateKey: EncString;
  /**
   * Public key
   */
  publicKey: B64;
  /**
   * The user\'s public key, signed by the signing key
   */
  signedPublicKey: SignedPublicKey;
  /**
   * Signing key, encrypted with the user\'s symmetric key
   */
  signingKey: EncString;
  /**
   * Base64 encoded verifying key
   */
  verifyingKey: B64;
  /**
   * The user\'s signed security state
   */
  securityState: SignedSecurityState;
  /**
   * The security state\'s version
   */
  securityVersion: number;
}

/**
 * Response from the `make_update_password` function
 */
export interface UpdatePasswordResponse {
  /**
   * Hash of the new password
   */
  passwordHash: B64;
  /**
   * User key, encrypted with the new password
   */
  newKey: EncString;
}

/**
 * Response from the `update_kdf` function
 *
 * Note: This is deprecated and will be removed after key-connector fully uses sdk
 */
export interface UpdateKdfResponse {
  /**
   * The authentication data for the new KDF setting
   */
  masterPasswordAuthenticationData: MasterPasswordAuthenticationData;
  /**
   * The unlock data for the new KDF setting
   */
  masterPasswordUnlockData: MasterPasswordUnlockData;
  /**
   * The authentication data for the KDF setting prior to the change
   */
  oldMasterPasswordAuthenticationData: MasterPasswordAuthenticationData;
}

/**
 * Response model for untrusted memberships, containing both organization and emergency access
 * memberships.
 */
export interface UntrustedMembershipsResponse {
  emergency_access_memberships: V1EmergencyAccessMembership[];
  organization_memberships: V1OrganizationMembership[];
}

/**
 * Result of JIT master password registration process.
 */
export interface JitMasterPasswordRegistrationResponse {
  /**
   * The account cryptographic state of the user
   */
  account_cryptographic_state: WrappedAccountCryptographicState;
  /**
   * The master password unlock data
   */
  master_password_unlock: MasterPasswordUnlockData;
  /**
   * The decrypted user key.
   */
  user_key: B64;
}

/**
 * Result of Key Connector registration process.
 */
export interface KeyConnectorRegistrationResult {
  /**
   * The account cryptographic state of the user.
   */
  account_cryptographic_state: WrappedAccountCryptographicState;
  /**
   * The key connector key used for unlocking.
   */
  key_connector_key: B64;
  /**
   * The encrypted user key, wrapped with the key connector key.
   */
  key_connector_key_wrapped_user_key: EncString;
  /**
   * The decrypted user key. This can be used to get the consuming client to an unlocked state.
   */
  user_key: B64;
}

/**
 * Result of TDE registration process.
 */
export interface TdeRegistrationResponse {
  /**
   * The account cryptographic state of the user
   */
  account_cryptographic_state: WrappedAccountCryptographicState;
  /**
   * The device key
   */
  device_key: B64;
  /**
   * The decrypted user key. This can be used to get the consuming client to an unlocked state.
   */
  user_key: B64;
}

/**
 * Result of an idempotent alias deletion.
 */
export interface DeleteAliasResult {
  /**
   * Stable identity requested for deletion.
   */
  identity: AliasIdentity;
  /**
   * `true` for both confirmed removal and an idempotent already-absent result.
   */
  deleted: boolean;
}

/**
 * Result of atomically applying a validated reconciliation plan.
 */
export interface AliasReconciliationApplyResult {
  /**
   * Cipher identifiers whose reference or username changed.
   */
  changedCipherIds: CipherId[];
  /**
   * Actions already satisfied by a prior idempotent application.
   */
  unchangedActions: bigint;
}

/**
 * Result of checking password exposure via HIBP API.
 */
export type ExposedPasswordResult =
  { type: "NotChecked" } | { type: "Found"; value: number } | { type: "Error"; value: string };

/**
 * Result of user master password registration process.
 */
export interface UserMasterPasswordRegistrationResponse {
  /**
   * The account cryptographic state of the user
   */
  account_cryptographic_state: WrappedAccountCryptographicState;
  /**
   * The master password unlock data
   */
  master_password_unlock: MasterPasswordUnlockData;
  /**
   * The decrypted user key. This can be used to get the consuming client to an unlocked state.
   */
  user_key: B64;
}

/**
 * Risk evaluation result for a single cipher.
 */
export interface CipherRiskResult {
  /**
   * Cipher ID matching the input CipherLoginDetails.
   */
  id: CipherId;
  /**
   * Password strength score from 0 (weakest) to 4 (strongest).
   * Calculated using zxcvbn with cipher-specific context.
   */
  password_strength: number;
  /**
   * Result of checking password exposure via HIBP API.
   * - `NotChecked`: check_exposed was false, or password was empty
   * - `Found(n)`: Successfully checked, found in n breaches
   * - `Error(msg)`: HIBP API request failed for this cipher with the given error message
   */
  exposed_result: ExposedPasswordResult;
  /**
   * Number of times this password appears in the provided password_map.
   * None if not found or if no password_map was provided.
   */
  reuse_count: number | undefined;
}

/**
 * SDK domain model for Key Connector user decryption option.
 */
export interface KeyConnectorUserDecryptionOption {
  /**
   * URL of the Key Connector server to use for decryption.
   */
  keyConnectorUrl: string;
}

/**
 * SDK domain model for Trusted Device user decryption option.
 */
export interface TrustedDeviceUserDecryptionOption {
  /**
   * Whether the user has admin approval for device login.
   */
  hasAdminApproval: boolean;
  /**
   * Whether the user has a device that can approve logins.
   */
  hasLoginApprovingDevice: boolean;
  /**
   * Whether the user has permission to manage password reset for other users.
   */
  hasManageResetPasswordPermission: boolean;
  /**
   * Whether the user is in TDE offboarding.
   */
  isTdeOffboarding: boolean;
  /**
   * The device key encrypted device private key. Only present if the device is trusted.
   */
  encryptedPrivateKey?: EncString;
  /**
   * The device private key encrypted user key. Only present if the device is trusted.
   */
  encryptedUserKey?: UnsignedSharedKey;
}

/**
 * SDK domain model for WebAuthn PRF user decryption option.
 */
export interface WebAuthnPrfUserDecryptionOption {
  /**
   * PRF key encrypted private key
   */
  encryptedPrivateKey: EncString;
  /**
   * Public Key encrypted user key
   */
  encryptedUserKey: UnsignedSharedKey;
  /**
   * Credential ID for this WebAuthn PRF credential.
   * TODO: PM-32163 - can remove `Option<T>` after 3 releases from server v2026.1.1
   */
  credentialId: string | undefined;
  /**
   * Transport methods available for this credential (e.g., \"usb\", \"nfc\", \"ble\", \"internal\",
   * \"hybrid\").
   * TODO: PM-32163 - can remove `Option<T>` after 3 releases from server v2026.1.1
   */
  transports: string[] | undefined;
}

/**
 * SDK domain model for master password policy requirements.
 * Defines the complexity requirements for a user\'s master password
 * when enforced by an organization policy.
 */
export interface MasterPasswordPolicyResponse {
  /**
   * The minimum complexity score required for the master password.
   * Complexity is calculated based on password strength metrics.
   */
  minComplexity?: number;
  /**
   * The minimum length required for the master password.
   */
  minLength?: number;
  /**
   * Whether the master password must contain at least one lowercase letter.
   */
  requireLower?: boolean;
  /**
   * Whether the master password must contain at least one uppercase letter.
   */
  requireUpper?: boolean;
  /**
   * Whether the master password must contain at least one numeric digit.
   */
  requireNumbers?: boolean;
  /**
   * Whether the master password must contain at least one special character.
   */
  requireSpecial?: boolean;
  /**
   * Whether this policy should be enforced when the user logs in.
   * If true, the user will be required to update their master password
   * if it doesn\'t meet the policy requirements.
   */
  enforceOnLogin?: boolean;
}

/**
 * SDK domain model for user decryption options.
 * Provides the various methods available to unlock a user\'s vault.
 */
export interface UserDecryptionOptionsResponse {
  /**
   * Master password unlock option. None if user doesn\'t have a master password.
   */
  masterPasswordUnlock?: MasterPasswordUnlockData;
  /**
   * Trusted Device decryption option.
   */
  trustedDeviceOption?: TrustedDeviceUserDecryptionOption;
  /**
   * Key Connector decryption option.
   * Mutually exclusive with Trusted Device option.
   */
  keyConnectorOption?: KeyConnectorUserDecryptionOption;
  /**
   * WebAuthn PRF decryption option.
   */
  webauthnPrfOption?: WebAuthnPrfUserDecryptionOption;
}

/**
 * SDK response model for a successful login.
 * This is the model that will be exposed to consuming applications.
 */
export interface LoginSuccessResponse {
  /**
   * The access token string.
   */
  accessToken: string;
  /**
   * The duration in seconds until the token expires.
   */
  expiresIn: number;
  /**
   * The timestamp in milliseconds when the token expires.
   * We calculate this for more convenient token expiration handling.
   */
  expiresAt: number;
  /**
   * The scope of the access token.
   * OAuth 2.0 RFC reference: <https://datatracker.ietf.org/doc/html/rfc6749#section-3.3>
   */
  scope: string;
  /**
   * The type of the token.
   * This will be \"Bearer\" for send access tokens.
   * OAuth 2.0 RFC reference: <https://datatracker.ietf.org/doc/html/rfc6749#section-7.1>
   */
  tokenType: string;
  /**
   * The optional refresh token string.
   * This token can be used to obtain new access tokens when the current one expires.
   */
  refreshToken: string | undefined;
  /**
   * The user key wrapped user private key.
   * Note: previously known as \"private_key\".
   */
  userKeyWrappedUserPrivateKey: string | undefined;
  /**
   * Two-factor authentication token for future requests.
   */
  twoFactorToken: string | undefined;
  /**
   * Indicates whether an admin has reset the user\'s master password,
   * requiring them to set a new password upon next login.
   */
  forcePasswordReset: boolean | undefined;
  /**
   * Indicates whether the user uses Key Connector and if the client should have a locally
   * configured Key Connector URL in their environment.
   * Note: This is currently only applicable for client_credential grant type logins and
   * is only expected to be relevant for the CLI
   */
  apiUseKeyConnector: boolean | undefined;
  /**
   * The user\'s decryption options for unlocking their vault.
   */
  userDecryptionOptions: UserDecryptionOptionsResponse;
  /**
   * If the user is subject to an organization master password policy,
   * this field contains the requirements of that policy.
   */
  masterPasswordPolicy: MasterPasswordPolicyResponse | undefined;
  /**
   * The user\'s account cryptographic keys (wrapped with the user key).
   */
  wrappedAccountCryptoState: WrappedAccountCryptographicState | undefined;
}

/**
 * SSO cookie vendor configuration
 *
 * This configuration is provided by the server.
 */
export interface SsoCookieVendorConfig {
  /**
   * Identity provider login URL for browser redirect during bootstrap
   */
  idpLoginUrl: string | undefined;
  /**
   * Cookie name (base name, without shard suffix)
   */
  cookieName: string;
  /**
   * Cookie domain for validation
   */
  cookieDomain: string;
  /**
   * Vault URL for cookie acquisition redirect
   *
   * This is the full vault URL (scheme + host + port) where the browser
   * should be redirected for SSO cookie acquisition.
   */
  vaultUrl: string;
  /**
   * Acquired cookies
   *
   * For sharded cookies, this contains multiple entries with names like
   * `AWSELBAuthSessionCookie-0`, `AWSELBAuthSessionCookie-1`, etc.
   * For unsharded cookies, this contains a single entry with the base name.
   */
  cookieValue: AcquiredCookie[] | undefined;
}

/**
 * SSO cookie vendor configuration for [`SetCommunicationTypeRequest`]
 *
 * Contains the server-provided configuration fields without acquired cookies.
 */
export interface SsoCookieVendorConfigRequest {
  /**
   * Identity provider login URL for browser redirect during bootstrap
   */
  idpLoginUrl: string | undefined;
  /**
   * Cookie name (base name, without shard suffix)
   */
  cookieName: string;
  /**
   * Cookie domain for validation
   */
  cookieDomain: string;
  /**
   * Vault URL for cookie acquisition redirect
   *
   * This is the full vault URL (scheme + host + port) where the browser
   * should be redirected for SSO cookie acquisition.
   */
  vaultUrl: string;
}

/**
 * Sealed open-organization-invite payload. Produced by
 * [`RegistrationClient::seal_open_org_invite_data`] and consumed by
 * [`RegistrationClient::unseal_open_org_invite_data`]. Both fields are required to unseal;
 * neither half is useful on its own.
 */
export interface SealedOpenOrgInvite {
  /**
   * URL-safe opaque payload; place on the verification-email link.
   */
  sealedData: SealedOpenOrgInviteData;
  /**
   * Paired secret; keep client-side (e.g. `localStorage`) and never send to the server.
   */
  highEntropySecret: HighEntropySecret;
}

/**
 * Secret-free encrypted journal event. Its closed schema deliberately has nowhere to place an
 * endpoint, credential, request/response body, header, URL query, or provider-native payload.
 */
export interface AliasJournalEvent {
  /**
   * Journal schema version.
   */
  version: number;
  /**
   * Globally unique UUID v4 for this immutable event.
   */
  eventId: string;
  /**
   * UUID v4 grouping all phases of one logical operation.
   */
  operationId: string;
  /**
   * UUID v4 of the replica that appended this event.
   */
  replicaId: string;
  /**
   * Strictly increasing sequence within the replica.
   */
  sequence: bigint;
  /**
   * Canonically sorted vector clock of observed predecessor events.
   */
  causal: AliasCausalEntry[];
  /**
   * Provider-neutral operation category.
   */
  operation: AliasOperationKind;
  /**
   * Durable phase of the operation.
   */
  phase: AliasOperationPhase;
  /**
   * Absent for create until an adapter acknowledges a stable remote identity.
   */
  target: AliasIdentity | undefined;
  /**
   * Desired or acknowledged lifecycle, kept separate from operation phase.
   */
  lifecycle: AliasLifecycleState | undefined;
  /**
   * Only a stable provider-neutral category is retained.
   */
  error: AliasErrorCode | undefined;
}

/**
 * Server communication configuration
 */
export interface ServerCommunicationConfig {
  /**
   * Bootstrap configuration determining how to establish server communication
   */
  bootstrap: BootstrapConfig;
}

/**
 * Server data for a newly created attachment slot. The caller uploads the
 * encrypted bytes to [`Self::upload_url`] using [`Self::file_upload_type`]
 */
export interface CreatedAttachment {
  /**
   * Server-assigned attachment ID.
   */
  attachmentId: string;
  /**
   * Upload target for the encrypted bytes
   */
  uploadUrl: string;
  /**
   * Bitwarden server or Azure Blob Storage.
   */
  fileUploadType: AttachmentFileUploadType;
  /**
   * Cipher returned by the server. For non-admin requests, this is also
   * written to the local repository
   */
  cipher: Cipher;
}

/**
 * Stable provider-neutral error category shared by every alias adapter and platform binding.
 */
export type AliasErrorCode =
  | "vault-locked"
  | "connection-missing"
  | "authentication-rejected"
  | "permission-denied"
  | "capability-unsupported"
  | "invalid-input"
  | "not-found"
  | "quota-exhausted"
  | "rate-limited"
  | "offline"
  | "timeout"
  | "service-unavailable"
  | "invalid-response"
  | "outcome-unknown"
  | "sync-conflict"
  | "local-security-failure";

/**
 * Stable reason a cipher could not participate in reconciliation.
 */
export type AliasReconciliationSkipReason =
  | "missing-cipher-id"
  | "reference-too-large"
  | "malformed-reference"
  | "unsupported-reference-version"
  | "foreign-connection"
  | "non-login-cipher"
  | "invalid-reference-value";

/**
 * State used for initializing the user cryptographic state.
 */
export interface InitUserCryptoRequest {
  /**
   * The user\'s ID.
   */
  userId: UserId | undefined;
  /**
   * The user\'s KDF parameters, as received from the prelogin request
   */
  kdfParams: Kdf;
  /**
   * The user\'s email address
   */
  email: string;
  /**
   * The user\'s account cryptographic state, containing their signature and
   * public-key-encryption keys, along with the signed security state, protected by the user key
   */
  accountCryptographicState: WrappedAccountCryptographicState;
  /**
   * The method to decrypt the user\'s account symmetric key (user key)
   */
  method: InitUserCryptoMethod;
  /**
   * Optional V2 upgrade token for automatic key rotation from V1 to V2
   */
  upgradeToken?: V2UpgradeToken;
}

/**
 * Temporary struct to hold metadata related to current account
 *
 * Eventually the SDK itself should have this state and we get rid of this struct.
 */
export interface Account {
  id: Uuid;
  email: string;
  name: string | undefined;
}

/**
 * Text-based send content
 */
export interface SendText {
  text: EncString | undefined;
  hidden: boolean;
}

/**
 * The common bucket of login fields to be re-used across all login mechanisms
 * (e.g., password, SSO, etc.). This will include handling client_id and 2FA.
 */
export interface LoginRequest {
  /**
   * OAuth client identifier
   */
  clientId: string;
  /**
   * Device information for this login request
   */
  device: LoginDeviceRequest;
}

/**
 * The credentials used for send access requests.
 */
export type SendAccessCredentials =
  SendPasswordCredentials | SendEmailOtpCredentials | SendEmailCredentials;

/**
 * The crypto method used to initialize the user cryptographic state.
 */
export type InitUserCryptoMethod =
  | { masterPasswordUnlock: { password: string; master_password_unlock: MasterPasswordUnlockData } }
  | { clientManagedState: {} }
  | { decryptedKey: { decrypted_user_key: string } }
  | { pin: { pin: string; pin_protected_user_key: EncString } }
  | { pinState: { pin: string } }
  | { pinEnvelope: { pin: string; pin_protected_user_key_envelope: PasswordProtectedKeyEnvelope } }
  | { authRequest: { request_private_key: B64; method: AuthRequestMethod } }
  | {
      deviceKey: {
        device_key: string;
        protected_device_private_key: EncString;
        device_protected_user_key: UnsignedSharedKey;
      };
    }
  | { keyConnector: { master_key: B64; user_key: EncString } }
  | { keyConnectorUrl: { url: string; key_connector_key_wrapped_user_key: EncString } };

/**
 * The data necessary to re-share the user-key to a V1 emergency access membership. Note: The
 * Public-key must be verified/trusted. Further, there is no sender authentication possible here.
 */
export interface V1EmergencyAccessMembership {
  id: Uuid;
  grantee_id: Uuid;
  name: string;
  public_key: PublicKey;
}

/**
 * The data necessary to re-share the user-key to a V1 organization membership. Note: The
 * Public-key must be verified/trusted. Further, there is no sender authentication possible here.
 */
export interface V1OrganizationMembership {
  organization_id: Uuid;
  name: string;
  public_key: PublicKey;
}

/**
 * The device (client) has several events that need to be reported to the shared unlock system.
 * This enum represents the events that need to be reported.
 */
export type DeviceEvent =
  | { ManualLock: { user_id: UserId } }
  | { ManualUnlock: { user_id: UserId; user_key: SymmetricKey } };

/**
 * The parts of a sync response the key management sync handler needs.
 */
export interface CryptoSyncData {
  /**
   * The account\'s user decryption options, as the server reports them on sync.
   */
  userDecryption?: CryptoSyncUserDecryption;
  /**
   * The account\'s cryptographic state, as the server reports it on sync.
   */
  accountCryptographicState?: WrappedAccountCryptographicState;
}

/**
 * The response to a discover/ping request.
 */
export interface DiscoverResponse {
  /**
   * The version of the client that responded to the discover request.
   */
  version: string;
}

/**
 * The type of key / signature scheme used for signing and verifying.
 */
export type SignatureAlgorithm = "ed25519" | "mlDsa44";

/**
 * The unlock data for a single WebAuthn PRF credential.
 */
export interface WebAuthnPrfUnlockOption {
  /**
   * The private key of the unlock option, wrapped by the key derived from the credential\'s PRF
   * output
   */
  encryptedPrivateKey: EncString;
  /**
   * The user key, encapsulated with the public key of the unlock option
   */
  encryptedUserKey: UnsignedSharedKey;
  /**
   * Credential ID for this WebAuthn PRF credential.
   */
  credentialId: string | undefined;
  /**
   * Transport methods available for this credential (e.g., \"usb\", \"nfc\", \"ble\", \"internal\",
   * \"hybrid\").
   */
  transports: string[] | undefined;
}

/**
 * The user decryption options a sync response carries, narrowed to the parts key management owns.
 */
export interface CryptoSyncUserDecryption {
  /**
   * Unlock data for accounts that have a master password.
   */
  masterPasswordUnlock?: MasterPasswordUnlockData;
  /**
   * Token allowing unlock after a V1 to V2 upgrade, when one is outstanding.
   */
  v2UpgradeToken?: V2UpgradeToken;
  /**
   * The WebAuthn PRF credentials the account can unlock with.
   */
  webAuthnPrfOptions?: WebAuthnPrfUnlockOption[];
  /**
   * The id of the account\'s current user key.
   */
  userKeyId?: KeyId;
}

/**
 * Type-safe authentication method for a Send, including the authentication data.
 * This ensures that password and email authentication are mutually exclusive.
 */
export type SendAuthType =
  | { type: "none" }
  | { type: "password"; password: string }
  | { type: "hashedPassword"; keyB64: string }
  | { type: "emails"; emails: string[] };

/**
 * Typescript interface that the state bridge needs to implement. The state bridge
 * is a temporary layer that allows quickly transitioning non-repository shaped
 * state to be accessible from within the SDK.
 */
export interface WasmStateBridge {
  set_user_key(value: SymmetricKey): Promise<void>;
  get_user_key(): Promise<SymmetricKey | null>;
  clear_user_key(): Promise<void>;
  set_user_key_id(value: KeyId): Promise<void>;
  get_user_key_id(): Promise<KeyId | null>;
  clear_user_key_id(): Promise<void>;
  set_persistent_pin_envelope(value: PasswordProtectedKeyEnvelope): Promise<void>;
  get_persistent_pin_envelope(): Promise<PasswordProtectedKeyEnvelope | null>;
  clear_persistent_pin_envelope(): Promise<void>;
  set_ephemeral_pin_envelope(value: PasswordProtectedKeyEnvelope): Promise<void>;
  get_ephemeral_pin_envelope(): Promise<PasswordProtectedKeyEnvelope | null>;
  clear_ephemeral_pin_envelope(): Promise<void>;
  set_encrypted_pin(value: EncString): Promise<void>;
  get_encrypted_pin(): Promise<EncString | null>;
  clear_encrypted_pin(): Promise<void>;
  set_v2_upgrade_token(value: V2UpgradeToken): Promise<void>;
  get_v2_upgrade_token(): Promise<V2UpgradeToken | null>;
  clear_v2_upgrade_token(): Promise<void>;
  set_account_cryptographic_state(value: WrappedAccountCryptographicState): Promise<void>;
  get_account_cryptographic_state(): Promise<WrappedAccountCryptographicState | null>;
  clear_account_cryptographic_state(): Promise<void>;
  set_masterpassword_unlock_data(value: MasterPasswordUnlockData): Promise<void>;
  get_masterpassword_unlock_data(): Promise<MasterPasswordUnlockData | null>;
  clear_masterpassword_unlock_data(): Promise<void>;
  set_webauthn_prf_unlock_data(value: WebAuthnPrfUnlockData): Promise<void>;
  get_webauthn_prf_unlock_data(): Promise<WebAuthnPrfUnlockData | null>;
  clear_webauthn_prf_unlock_data(): Promise<void>;
  set_kdf_config(value: Kdf): Promise<void>;
  get_kdf_config(): Promise<Kdf | null>;
  clear_kdf_config(): Promise<void>;
}

/**
 * Updated decrypted cipher returned to the caller\'s normal encryption/persistence path.
 */
export interface AliasCipherMutationResult {
  /**
   * Decrypted cipher to pass through the caller\'s normal persistence path.
   */
  cipher: CipherView;
  /**
   * Whether the canonical binding changed.
   */
  changed: boolean;
}

/**
 * View model for decrypted Send type
 */
export type SendViewType = { File: SendFileView } | { Text: SendTextView };

/**
 * View model for decrypted SendFile
 */
export interface SendFileView {
  /**
   * The file\'s ID
   */
  id: string | undefined;
  /**
   * The file name
   */
  fileName: string;
  /**
   * The file size in bytes as a string
   */
  size: string | undefined;
  /**
   * Readable size, ex: \"4.2 KB\" or \"1.43 GB\
   */
  sizeName: string | undefined;
}

/**
 * View model for decrypted SendText
 */
export interface SendTextView {
  /**
   * The text content of the send
   */
  text: string | undefined;
  /**
   * Whether the text is hidden-by-default (masked as ********).
   */
  hidden: boolean;
}

/**
 * View of a send\'s accessible content, returned after a successful send access call.
 * Name, text, and file fields are encrypted and must be decrypted client-side using the
 * key derived from the URL fragment.
 */
export interface SendAccessResponse {
  /**
   * The send access ID
   */
  id: string | undefined;
  /**
   * The send type.
   */
  type: SendType | undefined;
  /**
   * Encrypted send name
   */
  name: string | undefined;
  /**
   * Text content (if type is Text)
   */
  text: SendAccessTextResponse | undefined;
  /**
   * File metadata (if type is File)
   */
  file: SendAccessFileResponse | undefined;
  /**
   * When the send expires.
   */
  expirationDate: DateTime<Utc> | undefined;
  /**
   * The creator\'s identifier (email), if not hidden
   */
  creatorIdentifier: string | undefined;
}

/**
 * View returned after creating a file send.
 *
 * Contains the created send and information needed to upload the file data.
 */
export interface CreateFileSendResponse {
  /**
   * The created send.
   */
  send: SendView;
  /**
   * The upload URL for the file data.
   */
  url: string;
  /**
   * Which upload backend the client should target with the encrypted bytes.
   */
  fileUploadType: FileUploadType;
  /**
   * The file ID assigned by the server.
   */
  fileId: string;
  /**
   * The encrypted file name string (e.g. `\"2.ABCD...\"`).
   */
  encryptedFileName: string;
  /**
   * The encrypted file bytes, ready to hand to [`SendClient::upload_send_file`]. These were
   * encrypted under the same send key recorded on the created send, and their length was used
   * to populate `file_length` on the create request (matching the legacy client, which sends
   * the encrypted buffer length so the server can enforce storage quotas up-front).
   */
  encryptedFileBuffer: number[];
}

/**
 * Where attachment bytes should be uploaded.
 */
export type AttachmentFileUploadType = "Direct" | "Azure";

/**
 * Whether reconciliation is planning changes or reporting an applied result.
 */
export type AliasReconciliationMode = "dry-run" | "apply";

export interface AncestorMap {
  ancestors: Map<CollectionId, string>;
}

export interface Attachment {
  id: string | undefined;
  url: string | undefined;
  size: string | undefined;
  /**
   * Readable size, ex: \"4.2 KB\" or \"1.43 GB\
   */
  sizeName: string | undefined;
  fileName: EncString | undefined;
  key: EncString | undefined;
}

export interface AttachmentView {
  id: string | undefined;
  url: string | undefined;
  size: string | undefined;
  sizeName: string | undefined;
  fileName: string | undefined;
  key: EncString | undefined;
  /**
   * The decrypted attachmentkey in base64 format.
   *
   * **TEMPORARY FIELD**: This field is a temporary workaround to provide
   * decrypted attachment keys to the TypeScript client during the migration
   * process. It will be removed once the encryption/decryption logic is
   * fully migrated to the SDK.
   *
   * **Ticket**: <https://bitwarden.atlassian.net/browse/PM-23005>
   *
   * Do not rely on this field for long-term use.
   */
  decryptedKey: string | undefined;
}

export interface BankAccount {
  bankName: EncString | undefined;
  nameOnAccount: EncString | undefined;
  accountType: EncString | undefined;
  accountNumber: EncString | undefined;
  routingNumber: EncString | undefined;
  branchNumber: EncString | undefined;
  pin: EncString | undefined;
  swiftCode: EncString | undefined;
  iban: EncString | undefined;
  bankContactPhone: EncString | undefined;
}

export interface BankAccountView {
  bankName: string | undefined;
  nameOnAccount: string | undefined;
  accountType: string | undefined;
  accountNumber: string | undefined;
  routingNumber: string | undefined;
  branchNumber: string | undefined;
  pin: string | undefined;
  swiftCode: string | undefined;
  iban: string | undefined;
  bankContactPhone: string | undefined;
}

export interface Card {
  cardholderName: EncString | undefined;
  expMonth: EncString | undefined;
  expYear: EncString | undefined;
  code: EncString | undefined;
  brand: EncString | undefined;
  number: EncString | undefined;
}

export interface CardView {
  cardholderName: string | undefined;
  expMonth: string | undefined;
  expYear: string | undefined;
  code: string | undefined;
  brand: string | undefined;
  number: string | undefined;
}

export interface Cipher {
  id: CipherId | undefined;
  organizationId: OrganizationId | undefined;
  folderId: FolderId | undefined;
  collectionIds: CollectionId[];
  /**
   * More recent ciphers uses individual encryption keys to encrypt the other fields of the
   * Cipher.
   */
  key: EncString | undefined;
  /**
   * Encrypted item name. `None` for blob-encrypted ciphers, where the name lives inside
   * the sealed `data` blob; required on the legacy field-level format.
   */
  name: EncString | undefined;
  notes: EncString | undefined;
  type: CipherType;
  login: Login | undefined;
  identity: Identity | undefined;
  card: Card | undefined;
  secureNote: SecureNote | undefined;
  sshKey: SshKey | undefined;
  bankAccount: BankAccount | undefined;
  driversLicense: DriversLicense | undefined;
  passport: Passport | undefined;
  favorite: boolean;
  reprompt: CipherRepromptType;
  organizationUseTotp: boolean;
  edit: boolean;
  permissions: CipherPermissions | undefined;
  viewPassword: boolean;
  localData: LocalData | undefined;
  attachments: Attachment[] | undefined;
  fields: Field[] | undefined;
  passwordHistory: PasswordHistory[] | undefined;
  creationDate: DateTime<Utc>;
  deletedDate: DateTime<Utc> | undefined;
  revisionDate: DateTime<Utc>;
  archivedDate: DateTime<Utc> | undefined;
  data: string | undefined;
}

export interface CipherListView {
  id: CipherId | undefined;
  organizationId: OrganizationId | undefined;
  folderId: FolderId | undefined;
  collectionIds: CollectionId[];
  /**
   * Temporary, required to support calculating TOTP from CipherListView.
   */
  key: EncString | undefined;
  name: string;
  subtitle: string;
  type: CipherListViewType;
  favorite: boolean;
  reprompt: CipherRepromptType;
  organizationUseTotp: boolean;
  edit: boolean;
  permissions: CipherPermissions | undefined;
  viewPassword: boolean;
  /**
   * The number of attachments
   */
  attachments: number;
  /**
   * Indicates if the cipher has old attachments that need to be re-uploaded
   */
  hasOldAttachments: boolean;
  creationDate: DateTime<Utc>;
  deletedDate: DateTime<Utc> | undefined;
  revisionDate: DateTime<Utc>;
  archivedDate: DateTime<Utc> | undefined;
  /**
   * Hints for the presentation layer for which fields can be copied.
   */
  copyableFields: CopyableCipherFields[];
  localData: LocalDataView | undefined;
  /**
   * Decrypted cipher notes for search indexing.
   */
  notes: string | undefined;
  /**
   * Decrypted cipher fields for search indexing.
   * Only includes name and value (for text fields only).
   */
  fields: FieldListView[] | undefined;
  /**
   * Decrypted attachment filenames for search indexing.
   */
  attachmentNames: string[] | undefined;
}

export interface CipherPermissions {
  delete: boolean;
  restore: boolean;
}

export interface CipherView {
  id: CipherId | undefined;
  organizationId: OrganizationId | undefined;
  folderId: FolderId | undefined;
  collectionIds: CollectionId[];
  /**
   * Temporary, required to support re-encrypting existing items.
   */
  key: EncString | undefined;
  name: string;
  notes: string | undefined;
  type: CipherType;
  login: LoginView | undefined;
  identity: IdentityView | undefined;
  card: CardView | undefined;
  secureNote: SecureNoteView | undefined;
  sshKey: SshKeyView | undefined;
  bankAccount: BankAccountView | undefined;
  driversLicense: DriversLicenseView | undefined;
  passport: PassportView | undefined;
  favorite: boolean;
  reprompt: CipherRepromptType;
  organizationUseTotp: boolean;
  edit: boolean;
  permissions: CipherPermissions | undefined;
  viewPassword: boolean;
  localData: LocalDataView | undefined;
  attachments: AttachmentView[] | undefined;
  /**
   * Attachments that failed to decrypt. Only present when there are decryption failures.
   */
  attachmentDecryptionFailures?: AttachmentView[];
  fields: FieldView[] | undefined;
  passwordHistory: PasswordHistoryView[] | undefined;
  creationDate: DateTime<Utc>;
  deletedDate: DateTime<Utc> | undefined;
  revisionDate: DateTime<Utc>;
  archivedDate: DateTime<Utc> | undefined;
}

export interface Collection {
  id: CollectionId | undefined;
  organizationId: OrganizationId;
  name: EncString;
  externalId: string | undefined;
  hidePasswords: boolean;
  readOnly: boolean;
  manage: boolean;
  defaultUserCollectionEmail: string | undefined;
  type: CollectionType;
}

export interface CollectionView {
  id: CollectionId | undefined;
  organizationId: OrganizationId;
  name: string;
  externalId: string | undefined;
  hidePasswords: boolean;
  readOnly: boolean;
  manage: boolean;
  type: CollectionType;
}

export interface DriversLicense {
  firstName: EncString | undefined;
  middleName: EncString | undefined;
  lastName: EncString | undefined;
  dateOfBirth: EncString | undefined;
  licenseNumber: EncString | undefined;
  issuingCountry: EncString | undefined;
  issuingState: EncString | undefined;
  issueDate: EncString | undefined;
  expirationDate: EncString | undefined;
  issuingAuthority: EncString | undefined;
  licenseClass: EncString | undefined;
}

export interface DriversLicenseView {
  firstName: string | undefined;
  middleName: string | undefined;
  lastName: string | undefined;
  dateOfBirth: NaiveDate | undefined;
  licenseNumber: string | undefined;
  issuingCountry: string | undefined;
  issuingState: string | undefined;
  issueDate: NaiveDate | undefined;
  expirationDate: NaiveDate | undefined;
  issuingAuthority: string | undefined;
  licenseClass: string | undefined;
}

export interface EncryptionContext {
  /**
   * The Id of the user that encrypted the cipher. It should always represent a UserId, even for
   * Organization-owned ciphers
   */
  encryptedFor: UserId;
  /**
   * Hex-encoded id of the key the cipher\'s fields are wrapped under - the organization key for
   * Organization-owned ciphers, otherwise the user key - captured at the time the cipher was
   * encrypted. The server uses it to reject writes made under a wrong key.
   *
   * `None` when the wrapping key has no server-managed id. Legacy AES-CBC-HMAC keys used by V1
   * accounts have a derived local identity, but that value does not cross this boundary.
   */
  encryptedByKeyId?: string;
  cipher: Cipher;
}

export interface Fido2Credential {
  credentialId: EncString;
  keyType: EncString;
  keyAlgorithm: EncString;
  keyCurve: EncString;
  keyValue: EncString;
  rpId: EncString;
  userHandle: EncString | undefined;
  userName: EncString | undefined;
  counter: EncString;
  rpName: EncString | undefined;
  userDisplayName: EncString | undefined;
  discoverable: EncString;
  creationDate: DateTime<Utc>;
}

export interface Fido2CredentialFullView {
  credentialId: string;
  keyType: string;
  keyAlgorithm: string;
  keyCurve: string;
  keyValue: string;
  rpId: string;
  userHandle: string | undefined;
  userName: string | undefined;
  counter: string;
  rpName: string | undefined;
  userDisplayName: string | undefined;
  discoverable: string;
  creationDate: DateTime<Utc>;
}

export interface Fido2CredentialListView {
  credentialId: string;
  rpId: string;
  userHandle: string | undefined;
  userName: string | undefined;
  userDisplayName: string | undefined;
  counter: string;
}

export interface Fido2CredentialNewView {
  credentialId: string;
  keyType: string;
  keyAlgorithm: string;
  keyCurve: string;
  rpId: string;
  userHandle: string | undefined;
  userName: string | undefined;
  counter: string;
  rpName: string | undefined;
  userDisplayName: string | undefined;
  creationDate: DateTime<Utc>;
}

export interface Fido2CredentialView {
  credentialId: string;
  keyType: string;
  keyAlgorithm: string;
  keyCurve: string;
  keyValue: EncString;
  rpId: string;
  userHandle: string | undefined;
  userName: string | undefined;
  counter: string;
  rpName: string | undefined;
  userDisplayName: string | undefined;
  discoverable: string;
  creationDate: DateTime<Utc>;
}

export interface Field {
  name: EncString | undefined;
  value: EncString | undefined;
  type: FieldType;
  linkedId: LinkedIdType | undefined;
}

export interface FieldView {
  name: string | undefined;
  value: string | undefined;
  type: FieldType;
  linkedId: LinkedIdType | undefined;
}

export interface Folder {
  id: FolderId | undefined;
  name: EncString;
  revisionDate: DateTime<Utc>;
}

export interface FolderView {
  id: FolderId | undefined;
  name: string;
  revisionDate: DateTime<Utc>;
}

export interface Identity {
  title: EncString | undefined;
  firstName: EncString | undefined;
  middleName: EncString | undefined;
  lastName: EncString | undefined;
  address1: EncString | undefined;
  address2: EncString | undefined;
  address3: EncString | undefined;
  city: EncString | undefined;
  state: EncString | undefined;
  postalCode: EncString | undefined;
  country: EncString | undefined;
  company: EncString | undefined;
  email: EncString | undefined;
  phone: EncString | undefined;
  ssn: EncString | undefined;
  username: EncString | undefined;
  passportNumber: EncString | undefined;
  licenseNumber: EncString | undefined;
}

export interface IdentityView {
  title: string | undefined;
  firstName: string | undefined;
  middleName: string | undefined;
  lastName: string | undefined;
  address1: string | undefined;
  address2: string | undefined;
  address3: string | undefined;
  city: string | undefined;
  state: string | undefined;
  postalCode: string | undefined;
  country: string | undefined;
  company: string | undefined;
  email: string | undefined;
  phone: string | undefined;
  ssn: string | undefined;
  username: string | undefined;
  passportNumber: string | undefined;
  licenseNumber: string | undefined;
}

export interface LocalData {
  lastUsedDate: DateTime<Utc> | undefined;
  lastLaunched: DateTime<Utc> | undefined;
}

export interface LocalDataView {
  lastUsedDate: DateTime<Utc> | undefined;
  lastLaunched: DateTime<Utc> | undefined;
}

export interface Login {
  username: EncString | undefined;
  password: EncString | undefined;
  /**
   * Canonical alias reference JSON encrypted with the rest of the login.
   */
  aliasReference: EncString | undefined;
  passwordRevisionDate: DateTime<Utc> | undefined;
  uris: LoginUri[] | undefined;
  totp: EncString | undefined;
  autofillOnPageLoad: boolean | undefined;
  fido2Credentials: Fido2Credential[] | undefined;
}

export interface LoginListView {
  fido2Credentials: Fido2CredentialListView[] | undefined;
  hasFido2: boolean;
  username: string | undefined;
  /**
   * The TOTP key is not decrypted. Useable as is with [`crate::generate_totp_cipher_view`].
   */
  totp: EncString | undefined;
  uris: LoginUriView[] | undefined;
}

export interface LoginUri {
  uri: EncString | undefined;
  match: UriMatchType | undefined;
  uriChecksum: EncString | undefined;
}

export interface LoginUriView {
  uri: string | undefined;
  match: UriMatchType | undefined;
  uriChecksum: string | undefined;
}

export interface LoginView {
  username: string | undefined;
  password: string | undefined;
  /**
   * Canonical alias reference JSON. This is persisted only through normal vault encryption.
   */
  aliasReference: string | undefined;
  passwordRevisionDate: DateTime<Utc> | undefined;
  uris: LoginUriView[] | undefined;
  totp: string | undefined;
  autofillOnPageLoad: boolean | undefined;
  fido2Credentials: Fido2Credential[] | undefined;
}

export interface Passport {
  surname: EncString | undefined;
  givenName: EncString | undefined;
  dateOfBirth: EncString | undefined;
  sex: EncString | undefined;
  birthPlace: EncString | undefined;
  nationality: EncString | undefined;
  issuingCountry: EncString | undefined;
  passportNumber: EncString | undefined;
  passportType: EncString | undefined;
  nationalIdentificationNumber: EncString | undefined;
  issuingAuthority: EncString | undefined;
  issueDate: EncString | undefined;
  expirationDate: EncString | undefined;
}

export interface PassportView {
  surname: string | undefined;
  givenName: string | undefined;
  dateOfBirth: NaiveDate | undefined;
  sex: string | undefined;
  birthPlace: string | undefined;
  nationality: string | undefined;
  issuingCountry: string | undefined;
  passportNumber: string | undefined;
  passportType: string | undefined;
  nationalIdentificationNumber: string | undefined;
  issuingAuthority: string | undefined;
  issueDate: NaiveDate | undefined;
  expirationDate: NaiveDate | undefined;
}

export interface PasswordChangeAndRotateUserKeysRequest {
  old_password: string;
  password: string;
  hint: string | undefined;
  trusted_emergency_access_public_keys: PublicKey[];
  trusted_organization_public_keys: PublicKey[];
}

export interface PasswordHistory {
  password: EncString;
  lastUsedDate: DateTime<Utc>;
}

export interface PasswordHistoryView {
  password: string;
  lastUsedDate: DateTime<Utc>;
}

export interface Repositories {
  cipher: Repository<Cipher> | null;
  folder: Repository<Folder> | null;
  local_user_data_key_state: Repository<LocalUserDataKeyState> | null;
  organization_shared_key: Repository<OrganizationSharedKey> | null;
  send: Repository<Send> | null;
}

export interface RotateUserKeysRequest {
  key_rotation_method: KeyRotationMethod;
  trusted_emergency_access_public_keys: PublicKey[];
  /**
   * Organization public keys the user confirmed as trusted. Only needed when the rotation
   * shares the new user key for account recovery.
   */
  trusted_organization_public_keys: PublicKey[];
  upgrade_token_action: UpgradeTokenAction;
}

export interface SecureNote {
  type: SecureNoteType;
}

export interface SecureNoteView {
  type: SecureNoteType;
}

export interface Send {
  id: SendId | undefined;
  accessId: string | undefined;
  name: EncString;
  notes: EncString | undefined;
  key: EncString;
  password: string | undefined;
  type: SendType;
  file: SendFile | undefined;
  text: SendText | undefined;
  maxAccessCount: number | undefined;
  accessCount: number;
  disabled: boolean;
  hideEmail: boolean;
  revisionDate: DateTime<Utc>;
  deletionDate: DateTime<Utc>;
  expirationDate: DateTime<Utc> | undefined;
  /**
   * Email addresses for OTP authentication (comma-separated).
   *
   * **Note**: Mutually exclusive with `password`. If both `password` and `emails` are
   * set, password authentication takes precedence and email OTP is ignored.
   */
  emails: string | undefined;
  authType: AuthType;
}

export interface SendListView {
  id: SendId | undefined;
  accessId: string | undefined;
  name: string;
  type: SendType;
  disabled: boolean;
  revisionDate: DateTime<Utc>;
  deletionDate: DateTime<Utc>;
  expirationDate: DateTime<Utc> | undefined;
  authType: AuthType;
}

export interface SendView {
  id: SendId | undefined;
  accessId: string | undefined;
  name: string;
  notes: string | undefined;
  /**
   * Base64 encoded key
   */
  key: string | undefined;
  /**
   * Replace or add a password to an existing send. The SDK will always return None when
   * decrypting a [Send]
   * TODO: We should revisit this, one variant is to have `[Create, Update]SendView` DTOs.
   */
  newPassword: string | undefined;
  /**
   * Denote if an existing send has a password. The SDK will ignore this value when creating or
   * updating sends.
   */
  hasPassword: boolean;
  type: SendType;
  file: SendFileView | undefined;
  text: SendTextView | undefined;
  maxAccessCount: number | undefined;
  accessCount: number;
  disabled: boolean;
  hideEmail: boolean;
  revisionDate: DateTime<Utc>;
  deletionDate: DateTime<Utc>;
  expirationDate: DateTime<Utc> | undefined;
  /**
   * Email addresses for OTP authentication.
   * **Note**: Mutually exclusive with `new_password`. If both are set, only password
   * authentication will be used. When creating or editing sends, use [crate::SendAuthType]
   * to ensure mutual exclusivity at the type level.
   */
  emails: string[];
  authType: AuthType;
}

export interface SshKey {
  /**
   * SSH private key (ed25519/rsa) in unencrypted openssh private key format [OpenSSH private key](https://github.com/openssh/openssh-portable/blob/master/PROTOCOL.key)
   */
  privateKey: EncString;
  /**
   * SSH public key (ed25519/rsa) according to [RFC4253](https://datatracker.ietf.org/doc/html/rfc4253#section-6.6).
   */
  publicKey: EncString | undefined;
  /**
   * SSH fingerprint using SHA256 in the format: `SHA256:BASE64_ENCODED_FINGERPRINT`.
   */
  fingerprint: EncString | undefined;
}

export interface SshKeyView {
  /**
   * SSH private key (ed25519/rsa) in unencrypted openssh private key format [OpenSSH private key](https://github.com/openssh/openssh-portable/blob/master/PROTOCOL.key)
   */
  privateKey: string;
  /**
   * SSH public key (ed25519/rsa) according to [RFC4253](https://datatracker.ietf.org/doc/html/rfc4253#section-6.6)
   */
  publicKey: string;
  /**
   * SSH fingerprint using SHA256 in the format: `SHA256:BASE64_ENCODED_FINGERPRINT`
   */
  fingerprint: string;
}

export interface TotpResponse {
  /**
   * Generated TOTP code
   */
  code: string;
  /**
   * Time period
   */
  period: number;
}

export interface TrustDeviceResponse {
  /**
   * Base64 encoded device key
   */
  device_key: B64;
  /**
   * UserKey encrypted with DevicePublicKey
   */
  protected_user_key: UnsignedSharedKey;
  /**
   * DevicePrivateKey encrypted with [DeviceKey]
   */
  protected_device_private_key: EncString;
  /**
   * DevicePublicKey encrypted with [UserKey](super::UserKey)
   */
  protected_device_public_key: EncString;
}

export type AppendType = "random" | { websiteName: { website: string } };

export type CipherListViewType =
  | { login: LoginListView }
  | "secureNote"
  | { card: CardListView }
  | "identity"
  | "sshKey"
  | { bankAccount: BankAccountListView }
  | "passport"
  | "driversLicense";

export type DeviceType =
  | "Android"
  | "iOS"
  | "ChromeExtension"
  | "FirefoxExtension"
  | "OperaExtension"
  | "EdgeExtension"
  | "WindowsDesktop"
  | "MacOsDesktop"
  | "LinuxDesktop"
  | "ChromeBrowser"
  | "FirefoxBrowser"
  | "OperaBrowser"
  | "EdgeBrowser"
  | "IEBrowser"
  | "UnknownBrowser"
  | "AndroidAmazon"
  | "UWP"
  | "SafariBrowser"
  | "VivaldiBrowser"
  | "VivaldiExtension"
  | "SafariExtension"
  | "SDK"
  | "Server"
  | "WindowsCLI"
  | "MacOsCLI"
  | "LinuxCLI"
  | "DuckDuckGoBrowser";

export type ExportFormat = "Csv" | "Json" | { EncryptedJson: { password: string } };

export type KeyAlgorithm =
  "Ed25519" | "Rsa3072" | "Rsa4096" | "EcdsaP256" | "EcdsaP384" | "EcdsaP521";

export type KeyRotationMethod =
  { Password: { password: string } } | { KeyConnector: { key_connector_url: string } } | "Tde";

export type LinkedIdType = LoginLinkedIdType | CardLinkedIdType | IdentityLinkedIdType;

export type PassphraseError = { InvalidNumWords: { minimum: number; maximum: number } };

export type UpgradeTokenAction = "Skip" | "CreateIfNeeded";

export type UsernameGeneratorRequest =
  | { word: { capitalize: boolean; include_number: boolean } }
  | { subaddress: { type: AppendType; email: string } }
  | { catchall: { type: AppendType; domain: string } };

/**
 * Stateful provider-neutral lifecycle service around a host-injected adapter.
 */
export class AliasClient {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Returns the canonical encrypted connection metadata supplied at construction.
   */
  connection(): AliasConnection;
  /**
   * Creates an alias through the injected adapter.
   */
  create(request: CreateAliasRequest): Promise<Alias>;
  /**
   * Creates a recipient-scoped send/reply identity.
   */
  create_send_reply_identity(request: CreateSendReplyIdentityRequest): Promise<SendReplyIdentity>;
  /**
   * Deletes an alias idempotently without modifying any bound login.
   */
  delete(identity: AliasIdentity): Promise<DeleteAliasResult>;
  /**
   * Gets the current snapshot for a connection-scoped identity.
   */
  get(identity: AliasIdentity): Promise<Alias>;
  /**
   * Lists a page of aliases through the injected adapter.
   */
  list(request: ListAliasesRequest): Promise<AliasPage>;
  /**
   * Lists recipient-scoped send/reply identities for one alias.
   */
  list_send_reply_identities(
    alias: AliasIdentity,
    page_token?: string | null,
  ): Promise<SendReplyIdentityPage>;
  /**
   * Creates a lifecycle service from encrypted neutral connection metadata and a host adapter.
   */
  constructor(connection: AliasConnection, adapter: AliasProviderAdapter);
  /**
   * Removes a recipient-scoped send/reply identity.
   */
  remove_send_reply_identity(identity: SendReplyIdentity): Promise<void>;
  /**
   * Explicitly enables or disables an alias and validates the confirmed state.
   */
  set_enabled(identity: AliasIdentity, enabled: boolean): Promise<Alias>;
  /**
   * Sets recipient blocking when the adapter negotiated `send-reply.block`.
   */
  set_send_reply_blocked(identity: SendReplyIdentity, blocked: boolean): Promise<SendReplyIdentity>;
}

/**
 * Wrapper for attachment admin operations. Uses the admin server API endpoints and does
 * not modify local state.
 */
export class AttachmentAdminClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Deletes an attachment from a cipher using the admin endpoint.
   * Affects server data only, does not modify local state.
   */
  delete_attachment(cipher_id: CipherId, attachment_id: string): Promise<Cipher>;
  /**
   * Fetches the download URL for an attachment from the admin API. The admin client has
   * no local repository to fall back to on 404, so a server-side 404 is surfaced as
   * [`CipherAdminGetAttachmentDownloadUrlError::NotFound`] for the caller to handle.
   */
  get_attachment_download_url(cipher_id: CipherId, attachment_id: string): Promise<string>;
}

/**
 * Wrapper for attachment-specific cipher operations.
 */
export class AttachmentsClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Returns a new client for performing attachment admin operations.
   * Uses the admin server API endpoints and does not modify local state.
   */
  admin(): AttachmentAdminClient;
  /**
   * Creates a new attachment slot on the server and updates local repository
   * state with the merged cipher returned by the server.
   *
   * The caller must upload the encrypted bytes to [`CreatedAttachment::upload_url`]
   * using the transport in [`CreatedAttachment::file_upload_type`].
   *
   * If a later step fails after slot creation, the SDK best-effort deletes the
   * orphaned slot and returns the original error.
   */
  create_attachment(
    cipher_id: CipherId,
    request: CreateAttachmentRequest,
  ): Promise<CreatedAttachment>;
  decrypt_buffer(
    cipher: Cipher,
    attachment: AttachmentView,
    encrypted_buffer: Uint8Array,
  ): Uint8Array;
  /**
   * Deletes an attachment from a cipher, and updates the local repository with the new
   * cipher data returned from the API.
   */
  delete_attachment(cipher_id: CipherId, attachment_id: string): Promise<Cipher>;
  /**
   * Returns the attachment download URL.
   *
   * With `emergency_access_id`, uses the emergency-access endpoint and never falls back.
   * Otherwise uses the cipher endpoint and falls back to the local repository on 404.
   */
  get_attachment_download_url(
    cipher_id: CipherId,
    attachment_id: string,
    emergency_access_id?: string | null,
  ): Promise<string>;
  /**
   * Returns a renewed upload URL for an attachment.
   * Does not modify the attachment slot.
   */
  renew_file_upload_url(cipher_id: CipherId, attachment_id: string): Promise<string>;
  /**
   * Upgrades a legacy v1 attachment to `CipherKey(AttachmentKey(Contents))`.
   *
   * Downloads and re-encrypts the attachment, creates a new slot, uploads the
   * new bytes, then deletes the old attachment. If the upload fails, it tries
   * to delete the new slot before returning the error. Returns the decrypted
   * cipher view.
   */
  upgrade_attachment(cipher_id: CipherId, attachment_id: string): Promise<CipherView>;
}

/**
 * Subclient containing auth functionality.
 */
export class AuthClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Client for login functionality
   */
  login(client_settings: ClientSettings): LoginClient;
  /**
   * Client for initializing user account cryptography and unlock methods after JIT provisioning
   */
  registration(): RegistrationClient;
  /**
   * Client for send access functionality
   */
  send_access(): SendAccessClient;
}

/**
 * Indicates the authentication strategy to use when accessing a Send
 */
export enum AuthType {
  /**
   * Email-based OTP authentication
   */
  Email = 0,
  /**
   * Password-based authentication
   */
  Password = 1,
  /**
   * No authentication required
   */
  None = 2,
}

/**
 * The current biometric capability state for a specific user on this client.
 */
export enum BiometricsStatus {
  /**
   * Biometrics is available and can be used immediately.
   */
  Available = 0,
  /**
   * Biometrics is supported, but user interaction is required before unlock can proceed.
   */
  UnlockNeeded = 1,
  /**
   * Biometrics hardware or platform support is unavailable.
   */
  HardwareUnavailable = 2,
  /**
   * Biometrics is supported but not enabled for this user.
   */
  NotEnabled = 3,
}

export enum CardLinkedIdType {
  CardholderName = 300,
  ExpMonth = 301,
  ExpYear = 302,
  Code = 303,
  Brand = 304,
  Number = 305,
}

/**
 * Client for performing admin operations on ciphers. Unlike the regular CiphersClient,
 * this client uses the admin server API endpoints, and does not modify local state.
 */
export class CipherAdminClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Creates a new [Cipher] for an organization, using the admin server endpoints.
   * Creates the Cipher on the server only, does not store it to local state.
   */
  create(request: CipherCreateRequest): Promise<CipherView>;
  /**
   * Deletes the Cipher with the matching CipherId from the server, using the admin endpoint.
   * Affects server data only, does not modify local state.
   */
  delete(cipher_id: CipherId): Promise<void>;
  /**
   * Deletes all Cipher objects with a matching CipherId from the server, using the admin
   * endpoint. Affects server data only, does not modify local state.
   */
  delete_many(cipher_ids: CipherId[], organization_id: OrganizationId): Promise<void>;
  /**
   * Edit an existing [Cipher] and save it to the server.
   */
  edit(request: CipherEditRequest, original_cipher_view: CipherView): Promise<CipherView>;
  /**
   * Fetches and decrypts all ciphers assigned to the current user for an organization.
   */
  list_assigned_org_ciphers(org_id: OrganizationId): Promise<ListOrganizationCiphersResult>;
  /**
   * Get all ciphers for an organization.
   */
  list_org_ciphers(
    org_id: OrganizationId,
    include_member_items: boolean,
  ): Promise<ListOrganizationCiphersResult>;
  /**
   * Restores a soft-deleted cipher on the server, using the admin endpoint.
   */
  restore(cipher_id: CipherId): Promise<CipherView>;
  /**
   * Restores multiple soft-deleted ciphers on the server.
   */
  restore_many(cipher_ids: CipherId[], org_id: OrganizationId): Promise<DecryptCipherListResult>;
  /**
   * Soft-deletes the Cipher with the matching CipherId from the server, using the admin
   * endpoint. Affects server data only, does not modify local state.
   */
  soft_delete(cipher_id: CipherId): Promise<void>;
  /**
   * Soft-deletes all Cipher objects for the given CipherIds from the server, using the admin
   * endpoint. Affects server data only, does not modify local state.
   */
  soft_delete_many(cipher_ids: CipherId[], organization_id: OrganizationId): Promise<void>;
  /**
   * Adds the cipher matched by [CipherId] to any number of collections on the server.
   */
  update_collection(cipher_id: CipherId, collection_ids: CollectionId[]): Promise<CipherView>;
}

export enum CipherRepromptType {
  None = 0,
  Password = 1,
}

/**
 * Client for evaluating credential risk for login ciphers.
 */
export class CipherRiskClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Evaluate security risks for multiple login ciphers concurrently.
   *
   * For each cipher:
   * 1. Calculates password strength (0-4) using zxcvbn with cipher-specific context
   * 2. Optionally checks if the password has been exposed via Have I Been Pwned API
   * 3. Counts how many times the password is reused in the provided `password_map`
   *
   * Returns a vector of `CipherRisk` results, one for each input cipher.
   *
   * ## HIBP Check Results (`exposed_result` field)
   *
   * The `exposed_result` field uses the `ExposedPasswordResult` enum with three possible states:
   * - `NotChecked`: Password exposure check was not performed because:
   *   - `check_exposed` option was `false`, or
   *   - Password was empty
   * - `Found(n)`: Successfully checked via HIBP API, password appears in `n` data breaches
   * - `Error(msg)`: HIBP API request failed with error message `msg`
   *
   * # Errors
   *
   * This method only returns `Err` for internal logic failures. HIBP API errors are
   * captured per-cipher in the `exposed_result` field as `ExposedPasswordResult::Error(msg)`.
   */
  compute_risk(
    login_details: CipherLoginDetails[],
    options: CipherRiskOptions,
  ): Promise<CipherRiskResult[]>;
  /**
   * Build password reuse map for a list of login ciphers.
   *
   * Returns a map where keys are passwords and values are the number of times
   * each password appears in the provided list. This map can be passed to `compute_risk()`
   * to enable password reuse detection.
   */
  password_reuse_map(login_details: CipherLoginDetails[]): PasswordReuseMap;
}

export enum CipherType {
  Login = 1,
  SecureNote = 2,
  Card = 3,
  Identity = 4,
  SshKey = 5,
  BankAccount = 6,
  DriversLicense = 7,
  Passport = 8,
}

export class CiphersClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Returns a new client for performing admin operations.
   * Uses the admin server API endpoints and does not modify local state.
   */
  admin(): CipherAdminClient;
  /**
   * Updates collection membership for multiple [`Cipher`](crate::Cipher) objects.
   *
   * When `remove_collections` is `true`, the given collection IDs are removed from each cipher.
   * When `false`, they are added without introducing duplicates.
   */
  bulk_update_collections(
    organization_id: OrganizationId,
    cipher_ids: CipherId[],
    collection_ids: CollectionId[],
    remove_collections: boolean,
  ): Promise<void>;
  /**
   * Creates a new [Cipher] and saves it to the server.
   */
  create(request: CipherCreateRequest): Promise<CipherView>;
  decrypt(cipher: Cipher): Promise<CipherView>;
  decrypt_fido2_credentials(cipher_view: CipherView): Fido2CredentialView[];
  decrypt_fido2_private_key(cipher_view: CipherView): string;
  decrypt_list(ciphers: Cipher[]): Promise<CipherListView[]>;
  /**
   * Decrypt full cipher list
   * Returns both successfully fully decrypted ciphers and any that failed to decrypt
   */
  decrypt_list_full_with_failures(ciphers: Cipher[]): Promise<DecryptCipherResult>;
  /**
   * Decrypt cipher list with failures
   * Returns both successfully decrypted ciphers and any that failed to decrypt
   */
  decrypt_list_with_failures(ciphers: Cipher[]): Promise<DecryptCipherListResult>;
  /**
   * Deletes the [Cipher] with the matching [CipherId] from the server.
   */
  delete(cipher_id: CipherId): Promise<void>;
  /**
   * Deletes all [Cipher] objects with a matching [CipherId] from the server.
   */
  delete_many(cipher_ids: CipherId[], organization_id?: OrganizationId | null): Promise<void>;
  /**
   * Edit an existing [Cipher] and save it to the server.
   */
  edit(request: CipherEditRequest): Promise<CipherView>;
  /**
   * Update only `folder_id` and `favorite` on an existing [Cipher].
   *
   * Intended for users who do not have edit permissions on the cipher, but
   * are still allowed to change these personal organization fields.
   */
  edit_partial(request: CipherPartialEditRequest): Promise<CipherView>;
  encrypt(cipher_view: CipherView): Promise<EncryptionContext>;
  /**
   * Encrypt a cipher with the provided key. This should only be used when rotating encryption
   * keys in the Web client.
   *
   * Until key rotation is fully implemented in the SDK, this method must be provided the new
   * symmetric key in base64 format. See PM-23084
   *
   * If the cipher has a CipherKey, it will be re-encrypted with the new key.
   * If the cipher does not have a CipherKey and CipherKeyEncryption is enabled, one will be
   * generated using the new key. Otherwise, the cipher's data will be encrypted with the new
   * key directly.
   */
  encrypt_cipher_for_rotation(cipher_view: CipherView, new_key: B64): Promise<EncryptionContext>;
  /**
   * Encrypt a list of cipher views.
   *
   * This method attempts to encrypt all ciphers in the list. If any cipher
   * fails to encrypt, the entire operation fails and an error is returned.
   */
  encrypt_list(cipher_views: CipherView[]): Promise<EncryptionContext[]>;
  /**
   * Get [Cipher] by ID from state and decrypt it to a [CipherView].
   */
  get(cipher_id: string): Promise<CipherView>;
  /**
   * Get all ciphers from state and decrypt them to full [CipherView], returning both
   * successes and failures. This method will not fail when some ciphers fail to decrypt,
   * allowing for graceful handling of corrupted or problematic cipher data.
   */
  get_all(): Promise<DecryptCipherResult>;
  /**
   * Get all ciphers from state and decrypt them to [crate::CipherListView], returning both
   * successes and failures. This method will not fail when some ciphers fail to decrypt,
   * allowing for graceful handling of corrupted or problematic cipher data.
   */
  list(): Promise<DecryptCipherListResult>;
  /**
   * Moves multiple [`Cipher`](crate::Cipher) objects to a folder, or clears their folder when
   * `folder_id` is `None`.
   */
  move_many(cipher_ids: CipherId[], folder_id?: FolderId | null): Promise<void>;
  move_to_organization(cipher_view: CipherView, organization_id: OrganizationId): CipherView;
  /**
   * Restores a soft-deleted cipher on the server.
   */
  restore(cipher_id: CipherId): Promise<CipherView>;
  /**
   * Restores multiple soft-deleted ciphers on the server.
   */
  restore_many(cipher_ids: CipherId[]): Promise<DecryptCipherListResult>;
  /**
   * Temporary method used to re-encrypt FIDO2 credentials for a cipher view.
   * Necessary until the TS clients utilize the SDK entirely for FIDO2 credentials management.
   * TS clients create decrypted FIDO2 credentials that need to be encrypted manually when
   * encrypting the rest of the CipherView.
   * TODO: Remove once TS passkey provider implementation uses SDK - PM-8313
   */
  set_fido2_credentials(
    cipher_view: CipherView,
    fido2_credentials: Fido2CredentialFullView[],
  ): CipherView;
  /**
   * Moves a cipher into an organization, adds it to collections, and calls the share_cipher API.
   */
  share_cipher(
    cipher_view: CipherView,
    organization_id: OrganizationId,
    collection_ids: CollectionId[],
    original_cipher_view?: CipherView | null,
  ): Promise<CipherView>;
  /**
   * Moves a group of ciphers into an organization, adds them to collections, and calls the
   * share_ciphers API.
   */
  share_ciphers_bulk(
    cipher_views: CipherView[],
    organization_id: OrganizationId,
    collection_ids: CollectionId[],
  ): Promise<CipherView[]>;
  /**
   * Soft-deletes the [Cipher] with the matching [CipherId] from the server.
   */
  soft_delete(cipher_id: CipherId): Promise<void>;
  /**
   * Soft-deletes all [Cipher] objects for the given [CipherId]s from the server.
   */
  soft_delete_many(cipher_ids: CipherId[], organization_id?: OrganizationId | null): Promise<void>;
  /**
   * Adds the cipher matched by [CipherId] to any number of collections on the server.
   */
  update_collection(
    cipher_id: CipherId,
    collection_ids: CollectionId[],
    is_admin: boolean,
  ): Promise<CipherView>;
}

/**
 * Type of collection
 */
export enum CollectionType {
  /**
   * Default collection type. Can be assigned by an organization to user(s) or group(s)
   */
  SharedCollection = 0,
  /**
   * Default collection assigned to a user for an organization that has
   * OrganizationDataOwnership (formerly PersonalOwnership) policy enabled.
   */
  DefaultUserCollection = 1,
}

export class CollectionViewNodeItem {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  get_ancestors(): AncestorMap;
  get_children(): CollectionView[];
  get_item(): CollectionView;
  get_parent(): CollectionView | undefined;
}

export class CollectionViewTree {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  get_flat_items(): CollectionViewNodeItem[];
  get_item_for_view(collection_view: CollectionView): CollectionViewNodeItem | undefined;
  get_root_items(): CollectionViewNodeItem[];
}

export class CollectionsClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  decrypt(collection: Collection): CollectionView;
  decrypt_list(collections: Collection[]): CollectionView[];
  /**
   * Encrypts a [CollectionView] into an encrypted [Collection] using the organization key.
   */
  encrypt(collection_view: CollectionView): Collection;
  /**
   * Encrypts a list of [CollectionView]s into encrypted [Collection]s using the organization
   * key.
   */
  encrypt_list(collection_views: CollectionView[]): Collection[];
  /**
   *
   * Returns the vector of CollectionView objects in a tree structure based on its implemented
   * path().
   */
  get_collection_tree(collections: CollectionView[]): CollectionViewTree;
}

/**
 * Tells you which cryptographic algorithms to use for the current account and environment.
 *
 * Some environments are restricted in which algorithms they may use — for example, government
 * (FedRAMP) deployments must use FIPS-approved algorithms. Ask this client which algorithm to use
 * instead of picking one yourself, so the choice stays correct as those rules change.
 */
export class CryptoCipherSuiteClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Returns the KDF a new account should use in the current environment.
   *
   * In a FIPS (gov) environment the FIPS-approved PBKDF2 is used; otherwise the modern Argon2id
   * default.
   */
  default_kdf_for_new_account(): Kdf;
  /**
   * Returns whether the given KDF is allowed in the current environment.
   *
   * Intended for surfaces that let a user pick a KDF (e.g. the Change KDF settings screen): the
   * caller can validate or filter the options it offers. In a FIPS (gov) environment only PBKDF2
   * is allowed; otherwise every supported KDF is allowed.
   */
  is_kdf_compliant(kdf: Kdf): boolean;
}

/**
 * A client for the crypto operations.
 */
export class CryptoClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * A stop gap-solution for decrypting with the local user data key, until the WASM client's
   * password generator history encryption and email forwarders encryption is fully migrated to
   * SDK.
   */
  decrypt_with_local_user_data_key(encrypted_plaintext: string): string;
  /**
   * A stop gap-solution for encrypting with the local user data key, until the WASM client's
   * password generator history encryption and email forwarders encryption is fully migrated to
   * SDK.
   */
  encrypt_with_local_user_data_key(plaintext: string): string;
  /**
   * Protects the current user key with the provided PIN. The result can be stored and later
   * used to initialize another client instance by using the PIN and the PIN key with
   * `initialize_user_crypto`.
   */
  enroll_pin(pin: string): EnrollPinResponse;
  /**
   * Protects the current user key with the provided PIN. The result can be stored and later
   * used to initialize another client instance by using the PIN and the PIN key with
   * `initialize_user_crypto`. The provided pin is encrypted with the user key.
   */
  enroll_pin_with_encrypted_pin(encrypted_pin: string): EnrollPinResponse;
  /**
   * Takes a raw key and returns the corresponding key id. This is used for the biometrics
   * subsystem and should be removed after moving over biometric management to the SDK.
   */
  static get_key_id_for_symmetric_key(key: Uint8Array): Uint8Array | undefined;
  /**
   * ⚠️⚠️⚠️ HAZMAT WARNING: DO NOT USE THIS ⚠️⚠️⚠️
   *
   * Get the uses's decrypted encryption key. Note: It's very important
   * to keep this key safe, as it can be used to decrypt all of the user's data. It is
   * only permitted to use for a transition period where side effects such as biometrics
   * and never-lock are set from within the client code.
   */
  get_user_encryption_key(): Promise<B64>;
  /**
   * Creates a rotated set of account keys for the current state
   */
  get_v2_rotated_account_keys(): UserCryptoV2KeysResponse;
  /**
   * Initialization method for the organization crypto. Needs to be called after
   * `initialize_user_crypto` but before any other crypto operations.
   */
  initialize_org_crypto(req: InitOrgCryptoRequest): Promise<void>;
  /**
   * Initialization method for the user crypto. Needs to be called before any other crypto
   * operations.
   */
  initialize_user_crypto(req: InitUserCryptoRequest): Promise<void>;
  /**
   * Makes a new signing key pair and signs the public key for the user
   */
  make_keys_for_user_crypto_v2(): UserCryptoV2KeysResponse;
  /**
   * Create the data necessary to update the user's kdf settings. The user's encryption key is
   * re-encrypted for the password under the new kdf settings. This returns the re-encrypted
   * user key and the new password hash but does not update sdk state.
   *
   * Note: This is deprecated. Please use the user-crypto-management client instead.
   */
  make_update_kdf(password: string, kdf: Kdf): Promise<UpdateKdfResponse>;
  /**
   * Decrypts a `PasswordProtectedKeyEnvelope`, returning the user key, if successful.
   * This is a stop-gap solution, until initialization of the SDK is used.
   */
  unseal_password_protected_key_envelope(pin: string, envelope: string): Uint8Array;
}

/**
 * Client for the key management work that runs on every sync.
 */
export class CryptoSyncHandlerClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Runs the key management sync work. Call this after each sync, once the user's cryptographic
   * state has been applied.
   */
  on_sync(data: CryptoSyncData): Promise<void>;
}

export class ExporterClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Credential Exchange Format (CXF)
   *
   * *Warning:* Expect this API to be unstable, and it will change in the future.
   *
   * For use with Apple using [ASCredentialExportManager](https://developer.apple.com/documentation/authenticationservices/ascredentialexportmanager).
   * Ideally, the input should be immediately serialized from [ASImportableAccount](https://developer.apple.com/documentation/authenticationservices/asimportableaccount).
   */
  export_cxf(account: Account, ciphers: Cipher[]): string;
  export_organization_vault(
    collections: Collection[],
    ciphers: Cipher[],
    format: ExportFormat,
  ): string;
  export_vault(folders: Folder[], ciphers: Cipher[], format: ExportFormat): Promise<string>;
  /**
   * Credential Exchange Format (CXF)
   *
   * *Warning:* Expect this API to be unstable, and it will change in the future.
   *
   * For use with Apple using [ASCredentialExportManager](https://developer.apple.com/documentation/authenticationservices/ascredentialexportmanager).
   * Ideally, the input should be immediately serialized from [ASImportableAccount](https://developer.apple.com/documentation/authenticationservices/asimportableaccount).
   */
  import_cxf(payload: string): Cipher[];
}

/**
 * Represents the type of a [FieldView].
 */
export enum FieldType {
  /**
   * Text field
   */
  Text = 0,
  /**
   * Hidden text field
   */
  Hidden = 1,
  /**
   * Boolean field
   */
  Boolean = 2,
  /**
   * Linked field
   */
  Linked = 3,
}

/**
 * Where the client should upload the encrypted file bytes after [`SendClient::create_file_send`].
 */
export enum FileUploadType {
  /**
   * Upload directly to the Bitwarden server via `POST /sends/{id}/file/{file_id}`.
   */
  Direct = 0,
  /**
   * Upload to an Azure Blob Storage pre-signed URL.
   */
  Azure = 1,
}

/**
 * A client for inspecting and refreshing feature flags.
 */
export class FlagsClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}

/**
 * WASM client for reading Flight Recorder logs.
 *
 * The underlying buffer is global (initialized in [`init_sdk`](crate::init_sdk)),
 * so this client is a stateless handle for WASM access.
 */
export class FlightRecorderClient {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Get the current event count without reading event contents.
   */
  count(): number;
  /**
   * Create a new `FlightRecorderClient`.
   */
  constructor();
  /**
   * Read all events currently in the Flight Recorder buffer.
   */
  read(): FlightRecorderEvent[];
  /**
   * Ingest a single TypeScript-originated log event into the global buffer,
   * honoring the configured level floor.
   *
   * `timestamp` is milliseconds since the Unix epoch, supplied by the caller
   * (`Date.now()`).
   */
  write(timestamp: number, level: LogLevel, target: string, message: string): void;
}

/**
 * Wrapper for folder specific functionality.
 */
export class FoldersClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Create a new [Folder] and save it to the server.
   */
  create(request: FolderAddEditRequest): Promise<FolderView>;
  /**
   * Decrypt a [Folder] to [FolderView].
   */
  decrypt(folder: Folder): FolderView;
  /**
   * Decrypt a list of [Folder]s to a list of [FolderView]s.
   */
  decrypt_list(folders: Folder[]): FolderView[];
  /**
   * Edit the [Folder] and save it to the server.
   */
  edit(folder_id: FolderId, request: FolderAddEditRequest): Promise<FolderView>;
  /**
   * Encrypt a [FolderView] to a [Folder].
   */
  encrypt(folder_view: FolderView): Folder;
  /**
   * Get a specific [crate::Folder] by its ID from state and decrypt it to a [FolderView].
   */
  get(folder_id: FolderId): Promise<FolderView>;
  /**
   * Get all folders from state and decrypt them to a list of [FolderView].
   */
  list(): Promise<FolderView[]>;
}

export class GeneratorClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Generates a random passphrase.
   * A passphrase is a combination of random words separated by a character.
   * An example of passphrase is `correct horse battery staple`.
   *
   * The number of words and their case, the word separator, and the inclusion of
   * a number in the passphrase can be customized using the `input` parameter.
   *
   * # Examples
   *
   * ```
   * use bitwarden_core::Client;
   * use bitwarden_generators::{GeneratorClientsExt, PassphraseError, PassphraseGeneratorRequest};
   *
   * async fn test() -> Result<(), PassphraseError> {
   *     let input = PassphraseGeneratorRequest {
   *         num_words: 4,
   *         ..Default::default()
   *     };
   *     let passphrase = Client::new(None).generator().passphrase(input).unwrap();
   *     println!("{}", passphrase);
   *     Ok(())
   * }
   * ```
   */
  passphrase(input: PassphraseGeneratorRequest): string;
  /**
   * Generates a random password.
   *
   * The character sets and password length can be customized using the `input` parameter.
   *
   * # Examples
   *
   * ```
   * use bitwarden_core::Client;
   * use bitwarden_generators::{GeneratorClientsExt, PassphraseError, PasswordGeneratorRequest};
   *
   * async fn test() -> Result<(), PassphraseError> {
   *     let input = PasswordGeneratorRequest {
   *         lowercase: true,
   *         uppercase: true,
   *         numbers: true,
   *         length: 20,
   *         ..Default::default()
   *     };
   *     let password = Client::new(None).generator().password(input).unwrap();
   *     println!("{}", password);
   *     Ok(())
   * }
   * ```
   */
  password(input: PasswordGeneratorRequest): string;
  /**
   * Parses an HTML `passwordrules` attribute string into a [`PasswordGeneratorRequest`].
   *
   * The returned request can be passed to [`GeneratorClient::password`] to produce a
   * password that satisfies the website's declared constraints.
   */
  password_rules(rules: string): PasswordGeneratorRequest;
}

export enum IdentityLinkedIdType {
  Title = 400,
  MiddleName = 401,
  Address1 = 402,
  Address2 = 403,
  Address3 = 404,
  City = 405,
  State = 406,
  PostalCode = 407,
  Country = 408,
  Company = 409,
  Email = 410,
  Phone = 411,
  Ssn = 412,
  Username = 413,
  PassportNumber = 414,
  LicenseNumber = 415,
  FirstName = 416,
  LastName = 417,
  FullName = 418,
}

export class ImporterClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Import a KeePass KDBX (`.kdbx`) database and submit it to the server.
   *
   * Parses and decrypts the raw `.kdbx` bytes (unlocked with the password and/or key file),
   * encrypts the entries for the user's personal vault or the given organization, and submits
   * them to the import endpoint. Returns the counts of what was imported. Inputs larger than
   * 10 MiB are rejected with `KdbxFileTooLarge`.
   */
  import_kdbx(
    file: Uint8Array,
    password: string | null | undefined,
    key_file: Uint8Array | null | undefined,
    options: ImportOptions,
  ): Promise<ImportSummary>;
}

/**
 * An untyped IPC message received from another endpoint.
 */
export class IncomingMessage {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Create an incoming IPC message from raw payload bytes.
   */
  constructor(payload: Uint8Array, destination: Endpoint, source: Source, topic?: string | null);
  /**
   * Try to parse the payload as JSON.
   * @returns The parsed JSON value, or undefined if the payload is not valid JSON.
   */
  parse_payload_as_json(): any;
  /**
   * Destination endpoint that received this message.
   */
  destination: Endpoint;
  /**
   * Serialized payload bytes.
   */
  payload: Uint8Array;
  /**
   * Source that sent this message, with per-variant metadata.
   */
  source: Source;
  /**
   * Optional topic used for routing/dispatch.
   */
  get topic(): string | undefined;
  /**
   * Optional topic used for routing/dispatch.
   */
  set topic(value: string | null | undefined);
}

export class IntoUnderlyingByteSource {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  cancel(): void;
  pull(controller: ReadableByteStreamController): Promise<any>;
  start(controller: ReadableByteStreamController): void;
  readonly autoAllocateChunkSize: number;
  readonly type: ReadableStreamType;
}

export class IntoUnderlyingSink {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  abort(reason: any): Promise<any>;
  close(): Promise<any>;
  write(chunk: any): Promise<any>;
}

export class IntoUnderlyingSource {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  cancel(): void;
  pull(controller: ReadableStreamDefaultController): Promise<any>;
}

/**
 * Client for organization invite link cryptographic and network operations.
 */
export class InviteLinkClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Accepts an organization invite for the current user, optionally enrolling into account
   * recovery (when `enroll_into_account_recovery` is set) and — when the invite supports
   * confirmation — self-confirming.
   */
  accept_and_optionally_confirm(
    organization_id: OrganizationId,
    code: string,
    invite_secret: string,
    default_collection_name: string,
    enroll_into_account_recovery: boolean,
  ): Promise<void>;
  /**
   * Creates a new organization invite and posts it to the server, returning the full
   * [`OrganizationInviteLink`] persisted by the server.
   *
   * # Security
   * Only the sealed invite is posted to the server; the invite secret is never sent. Use
   * [`InviteLinkClient::get_invite_secret`] to recover the secret needed to reconstruct the
   * invite link.
   */
  create_invite_link(
    organization_id: OrganizationId,
    allowed_domains: string[],
    supports_confirmation: boolean,
  ): Promise<OrganizationInviteLink>;
  /**
   * Using the organization key, recovers the [`InviteSecret`] from the invite carried in the
   * given [`OrganizationInviteLink`] so an admin can reconstruct the invite link.
   */
  get_invite_secret(organization_id: OrganizationId, invite: string): InviteSecret;
  /**
   * Refresh an existing invite link.
   * This generates a new code and secret.
   */
  refresh_invite_link(
    organization_id: OrganizationId,
    supports_confirmation: boolean,
  ): Promise<OrganizationInviteLink>;
}

/**
 * JavaScript wrapper around the IPC client. For more information, see the
 * [`IpcClient`] trait documentation.
 */
export class IpcClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  isRunning(): boolean;
  /**
   * Create a new `IpcClient` instance with a client-managed session repository for saving
   * sessions using State Provider.
   */
  static newWithClientManagedSessions(
    communication_provider: IpcCommunicationBackend,
    session_repository: IpcSessionRepository,
  ): IpcClient;
  /**
   * Create a new `IpcClient` instance with an in-memory session repository for saving
   * sessions within the SDK.
   */
  static newWithSdkInMemorySessions(communication_provider: IpcCommunicationBackend): IpcClient;
  send(message: OutgoingMessage): Promise<void>;
  start(abort_signal?: AbortSignal | null): Promise<void>;
  subscribe(): Promise<IpcClientSubscription>;
}

/**
 * JavaScript wrapper around the IPC client subscription. For more information, see the
 * [IpcClientSubscription](crate::IpcClientSubscription) documentation.
 */
export class IpcClientSubscription {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  receive(abort_signal?: AbortSignal | null): Promise<IncomingMessage>;
}

/**
 * JavaScript implementation of the `CommunicationBackend` trait for IPC communication.
 */
export class IpcCommunicationBackend {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Creates a new instance of the JavaScript communication backend.
   */
  constructor(sender: IpcCommunicationBackendSender);
  /**
   * Used by JavaScript to provide an incoming message to the IPC framework.
   */
  receive(message: IncomingMessage): void;
}

export enum LogLevel {
  Trace = 0,
  Debug = 1,
  Info = 2,
  Warn = 3,
  Error = 4,
}

/**
 * Client for authenticating Bitwarden users.
 *
 * Handles unauthenticated operations to obtain access tokens from the Identity API.
 * After successful authentication, use the returned tokens to create an authenticated core client.
 *
 * # Lifecycle
 *
 * 1. Create `LoginClient` via `AuthClient`
 * 2. Call login method
 * 3. Use returned tokens with authenticated core client
 *
 * # Password Login Example
 *
 * ```rust,no_run
 * # use bitwarden_auth::{AuthClient, login::login_via_password::PasswordLoginRequest};
 * # use bitwarden_auth::login::models::{LoginRequest, LoginDeviceRequest, LoginResponse};
 * # use bitwarden_core::{Client, ClientSettings, DeviceType};
 * # async fn example(email: String, password: String) -> Result<(), Box<dyn std::error::Error>> {
 * // Create auth client
 * let client = Client::new(None);
 * let auth_client = AuthClient::new(client);
 *
 * // Configure client settings and create login client
 * let settings = ClientSettings {
 *     identity_url: "https://identity.bitwarden.com".to_string(),
 *     api_url: "https://api.bitwarden.com".to_string(),
 *     user_agent: "MyApp/1.0".to_string(),
 *     device_type: DeviceType::SDK,
 *     device_identifier: None,
 *     bitwarden_client_version: None,
 *     bitwarden_package_type: None,
 * };
 * let login_client = auth_client.login(settings);
 *
 * // Get user's KDF config
 * let prelogin = login_client.get_password_prelogin(email.clone()).await?;
 *
 * // Login with credentials
 * let response = login_client.login_via_password(PasswordLoginRequest {
 *     login_request: LoginRequest {
 *         client_id: "connector".to_string(),
 *         device: LoginDeviceRequest {
 *             device_type: DeviceType::SDK,
 *             device_identifier: "device-id".to_string(),
 *             device_name: "My Device".to_string(),
 *             device_push_token: None,
 *         },
 *     },
 *     email,
 *     password,
 *     prelogin_response: prelogin,
 * }).await?;
 *
 * // Use tokens from response for authenticated requests
 * match response {
 *     LoginResponse::Authenticated(success) => {
 *         let access_token = success.access_token;
 *         // Use access_token for authenticated requests
 *     }
 * }
 * # Ok(())
 * # }
 * ```
 */
export class LoginClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Retrieves the data required before authenticating with a password.
   * This includes the user's KDF configuration needed to properly derive the master key.
   */
  get_password_prelogin(email: string): Promise<PasswordPreloginResponse>;
  /**
   * Authenticates a user via email and master password.
   *
   * Derives the master password hash using KDF settings from prelogin, then sends
   * the authentication request to obtain access tokens and vault keys.
   */
  login_via_password(request: PasswordLoginRequest): Promise<LoginResponse>;
}

export enum LoginLinkedIdType {
  Username = 100,
  Password = 101,
}

/**
 * The method used to decrypt organization member data.
 */
export enum MemberDecryptionType {
  /**
   * Decryption using the user's master password.
   */
  MasterPassword = 0,
  /**
   * Decryption via Key Connector.
   */
  KeyConnector = 1,
  /**
   * Decryption via Trusted Device Encryption.
   */
  TrustedDeviceEncryption = 2,
}

/**
 * The membership status of a user within an organization.
 */
export enum OrganizationUserStatusType {
  /**
   * The user's access has been revoked. This may occur at any time from any other status.
   */
  Revoked = -1,
  /**
   * The user has been invited but has not yet accepted.
   */
  Invited = 0,
  /**
   * The user has accepted the invitation but has not yet been confirmed by an admin.
   */
  Accepted = 1,
  /**
   * The user has been confirmed by an admin and has full access.
   */
  Confirmed = 2,
  /**
   * The user has been staged for provisioning but has not yet been invited.
   */
  Staged = 3,
}

/**
 * The role of a user within an organization.
 */
export enum OrganizationUserType {
  /**
   * Full administrative control over the organization.
   */
  Owner = 0,
  /**
   * Administrative access with most management capabilities.
   */
  Admin = 1,
  /**
   * Standard organization member.
   */
  User = 2,
  /**
   * User with a customized set of permissions as indicated by
   * [`ProfileOrganization::permissions`].
   */
  Custom = 4,
}

/**
 * An untyped IPC message to be sent to another endpoint.
 */
export class OutgoingMessage {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Create an outgoing IPC message from raw payload bytes.
   */
  constructor(payload: Uint8Array, destination: Endpoint, topic?: string | null);
  /**
   * Create a new message and encode the payload as JSON.
   */
  static new_json_payload(
    payload: any,
    destination: Endpoint,
    topic?: string | null,
  ): OutgoingMessage;
  /**
   * Destination endpoint for this message.
   */
  destination: Endpoint;
  /**
   * Serialized payload bytes.
   */
  payload: Uint8Array;
  /**
   * Optional topic used for routing/dispatch.
   */
  get topic(): string | undefined;
  /**
   * Optional topic used for routing/dispatch.
   */
  set topic(value: string | null | undefined);
}

/**
 * The main entry point for the Bitwarden SDK in WebAssembly environments
 */
export class PasswordManagerClient {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Auth related operations.
   */
  auth(): AuthClient;
  /**
   * Crypto related operations.
   */
  crypto(): CryptoClient;
  /**
   * Crypto cipher suite operations.
   */
  crypto_cipher_suite(): CryptoCipherSuiteClient;
  /**
   * Key management operations that run on every sync.
   */
  crypto_sync_handler(): CryptoSyncHandlerClient;
  /**
   * Test method, echoes back the input
   */
  echo(msg: string): string;
  /**
   * Exporter related operations.
   */
  exporters(): ExporterClient;
  /**
   * Constructs a specific client for generating passwords and passphrases
   */
  generator(): GeneratorClient;
  /**
   * Whether the client is in Gov Mode.
   */
  gov_mode(): boolean;
  /**
   * Test method, calls http endpoint
   */
  http_get(url: string): Promise<string>;
  /**
   * Importer related operations.
   */
  importers(): ImporterClient;
  /**
   * Organization invite link operations.
   */
  invite_link(): InviteLinkClient;
  /**
   * Key management state bridge operations.
   */
  km_state_bridge(): StateBridgeClient;
  /**
   * Initialize a new instance of the SDK client
   */
  constructor(token_provider: any, settings?: ClientSettings | null);
  /**
   * Constructs a specific client for platform-specific functionality
   */
  platform(): PlatformClient;
  /**
   * Policy related operations.
   */
  policies(): PolicyClient;
  /**
   * Send related operations.
   */
  sends(): SendClient;
  /**
   * Test method, always throws an error
   */
  throw(msg: string): void;
  /**
   * User crypto management related operations.
   */
  user_crypto_management(): UserCryptoManagementClient;
  /**
   * Vault item related operations.
   */
  vault(): VaultClient;
  /**
   * Returns the current SDK version
   */
  version(): string;
}

/**
 * Sub-client for configuring PIN unlock behavior.
 */
export class PinSettingsClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Returns the configured PIN lock type, if a PIN lock is set.
   */
  get_lock_type(): Promise<PinLockType | undefined>;
  /**
   * Returns the currently configured PIN, if available.
   */
  get_pin(): Promise<string | undefined>;
  /**
   * Returns the current status of PIN unlock
   */
  get_status(): Promise<PinUnlockStatus>;
  /**
   * Sets or updates the account PIN and stores the corresponding unlock state.
   *
   * The `lock_type` determines how PIN unlock behaves for this account.
   * Returns an error when the PIN-protected state cannot be persisted.
   */
  set_pin(pin: string, lock_type: PinLockType): Promise<void>;
  /**
   * Unenrolls from PIN-based unlock
   */
  unset_pin(): Promise<void>;
  /**
   * Validates whether `pin` matches the currently configured unlock PIN.
   */
  validate_pin(pin: string): Promise<boolean>;
}

export class PlatformClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Load feature flags into the client
   */
  load_flags(flags: FeatureFlags): Promise<void>;
  state(): StateClient;
}

/**
 * Client for policy domain operations.
 *
 * Obtained via [`PoliciesClientExt::policies`] on a [`Client`].
 */
export class PolicyClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Filter policies of the given type for the current user.
   *
   * Untyped FFI path: native/WASM callers pass a runtime `policy_type` integer.
   * Delegates to the registry, falling back to default rules for unknown types.
   */
  filter_by_type(
    policies: PolicyView[],
    organization_user_policy_contexts: OrganizationUserPolicyContext[],
    policy_type: PolicyType,
  ): PolicyView[];
}

/**
 * The type of an organization policy.
 *
 * The integer value matches the server's wire format.
 */
export enum PolicyType {
  /**
   * Requires members to have two-step login enabled on their account.
   */
  TwoFactorAuthentication = 0,
  /**
   * Sets minimum requirements for members' master passwords.
   */
  MasterPassword = 1,
  /**
   * Sets minimum requirements for the password generator.
   */
  PasswordGenerator = 2,
  /**
   * Restricts members to being part of a single organization.
   */
  SingleOrg = 3,
  /**
   * Requires members to authenticate with single sign-on.
   */
  RequireSso = 4,
  /**
   * Forces newly added or cloned items to be owned by the organization rather than the
   * member's personal vault. Also enables My Items functionality.
   */
  OrganizationDataOwnership = 5,
  /**
   * Disables the ability to create and edit Bitwarden Sends.
   *
   * Superseded by [`SendControls`](Self::SendControls) when the
   * `pm-31885-send-controls` feature flag is active.
   */
  DisableSend = 6,
  /**
   * Sets restrictions or defaults for Bitwarden Sends.
   *
   * Superseded by [`SendControls`](Self::SendControls) when the
   * `pm-31885-send-controls` feature flag is active.
   */
  SendOptions = 7,
  /**
   * Allows administrators to recover member accounts.
   */
  ResetPassword = 8,
  /**
   * Sets the maximum allowed vault timeout for members.
   */
  MaximumVaultTimeout = 9,
  /**
   * Disables members' ability to export their personal vault.
   */
  DisablePersonalVaultExport = 10,
  /**
   * Activates autofill on page load in the browser extension.
   */
  ActivateAutofill = 11,
  /**
   * Automatically logs members into apps using single sign-on.
   */
  AutomaticAppLogIn = 12,
  /**
   * Removes members' access to the free Bitwarden Families sponsorship benefit.
   */
  FreeFamiliesSponsorship = 13,
  /**
   * Prevents members from unlocking the app with a PIN.
   */
  RemoveUnlockWithPin = 14,
  /**
   * Restricts the item types that members can create.
   */
  RestrictedItemTypes = 15,
  /**
   * Sets the default URI match detection strategy for autofill.
   */
  UriMatchDefaults = 16,
  /**
   * Sets the default behavior for the autotype feature.
   */
  AutotypeDefaultSetting = 17,
  /**
   * Automatically confirms invited users into the organization.
   */
  AutomaticUserConfirmation = 18,
  /**
   * Blocks account creation for users with email addresses on claimed domains.
   */
  BlockClaimedDomainAccountCreation = 19,
  /**
   * Displays an organization-configured banner message to members in their vault.
   */
  OrganizationUserNotification = 20,
  /**
   * Configures Send-related behavior: disabling Sends, email visibility, access controls,
   * Send types, and deletion.
   *
   * Supersedes [`DisableSend`](Self::DisableSend) and [`SendOptions`](Self::SendOptions) when
   * the `pm-31885-send-controls` feature flag is active on the server.
   */
  SendControls = 21,
  /**
   * Enables the Fill Assist targeting-rules autofill engine as the default for members who
   * have not explicitly set their Fill Assist preference, and optionally overrides the default
   * rules feed URL.
   */
  FillAssist = 22,
}

/**
 * The subscription tier of an organization.
 */
export enum ProductTierType {
  /**
   * Free tier with limited features.
   */
  Free = 0,
  /**
   * Families plan for personal use.
   */
  Families = 1,
  /**
   * Teams plan for small organizations.
   */
  Teams = 2,
  /**
   * Enterprise plan with full features.
   */
  Enterprise = 3,
  /**
   * Starter tier for small teams.
   */
  TeamsStarter = 4,
}

/**
 * The type of provider.
 */
export enum ProviderType {
  /**
   * Managed Service Provider - sells and manages its clients' Bitwarden organizations.
   */
  Msp = 0,
  /**
   * Reseller partner - sells Bitwarden to its clients but does not have any administrative
   * access.
   */
  Reseller = 1,
  /**
   * Business unit provider - used to manage multiple organizations which form part of a single
   * large enterprise.
   */
  BusinessUnit = 2,
}

/**
 * This module represents a stopgap solution to provide access to primitive crypto functions for JS
 * clients. It is not intended to be used outside of the JS clients and this pattern should not be
 * proliferated. It is necessary because we want to use SDK crypto prior to the SDK being fully
 * responsible for state and keys.
 */
export class PureCrypto {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Decapsulates (decrypts) a symmetric key using an decapsulation-key/private-key in PKCS8
   * DER format. Note: This is unsigned, so the sender's authenticity cannot be verified by the
   * recipient.
   */
  static decapsulate_key_unsigned(
    encapsulated_key: string,
    decapsulation_key: Uint8Array,
  ): Uint8Array;
  static decrypt_user_key_with_master_key(
    encrypted_user_key: string,
    master_key: Uint8Array,
  ): Uint8Array;
  static decrypt_user_key_with_master_password(
    encrypted_user_key: string,
    master_password: string,
    email: string,
    kdf: Kdf,
  ): Uint8Array;
  /**
   * Derive output of the KDF for a [bitwarden_crypto::Kdf] configuration.
   */
  static derive_kdf_material(password: Uint8Array, salt: Uint8Array, kdf: Kdf): Uint8Array;
  /**
   * Encapsulates (encrypts) a symmetric key using an public-key/encapsulation-key
   * in SPKI format, returning the encapsulated key as a string. Note: This is unsigned, so
   * the sender's authenticity cannot be verified by the recipient.
   */
  static encapsulate_key_unsigned(shared_key: Uint8Array, encapsulation_key: Uint8Array): string;
  static encrypt_user_key_with_master_password(
    user_key: Uint8Array,
    master_password: string,
    email: string,
    kdf: Kdf,
  ): string;
  /**
   * Returns the algorithm used for the given verifying key.
   */
  static key_algorithm_for_verifying_key(verifying_key: Uint8Array): SignatureAlgorithm;
  static make_aes256_cbc_hmac_key(): SymmetricKey;
  static make_user_key_aes256_cbc_hmac(): Uint8Array;
  static make_user_key_xchacha20_poly1305(): Uint8Array;
  /**
   * Generates a new v4 UUID using a cryptographically secure random number generator
   */
  static new_guid(): string;
  /**
   * Generates a cryptographically secure random number between the given min and max
   * (inclusive).
   */
  static random_number(min: number, max: number): number;
  /**
   * Decrypts data using RSAES-OAEP with SHA-1
   * HAZMAT WARNING: Do not use outside of implementing cryptofunctionservice
   */
  static rsa_decrypt_data(encrypted_data: Uint8Array, private_key: Uint8Array): Uint8Array;
  /**
   * Encrypts data using RSAES-OAEP with SHA-1
   * HAZMAT WARNING: Do not use outside of implementing cryptofunctionservice
   */
  static rsa_encrypt_data(plain_data: Uint8Array, public_key: Uint8Array): Uint8Array;
  /**
   * Given a decrypted private RSA key PKCS8 DER this
   * returns the corresponding public RSA key in DER format.
   * HAZMAT WARNING: Do not use outside of implementing cryptofunctionservice
   */
  static rsa_extract_public_key(private_key: Uint8Array): Uint8Array;
  /**
   * Generates a new RSA key pair and returns the private key
   * HAZMAT WARNING: Do not use outside of implementing cryptofunctionservice
   */
  static rsa_generate_keypair(): Uint8Array;
  /**
   * DEPRECATED: Use `symmetric_decrypt_string` instead.
   * Cleanup ticket: <https://bitwarden.atlassian.net/browse/PM-21247>
   */
  static symmetric_decrypt(enc_string: string, key: Uint8Array): string;
  /**
   * DEPRECATED: Use `symmetric_decrypt_filedata` instead.
   * Cleanup ticket: <https://bitwarden.atlassian.net/browse/PM-21247>
   */
  static symmetric_decrypt_array_buffer(enc_bytes: Uint8Array, key: Uint8Array): Uint8Array;
  static symmetric_decrypt_bytes(enc_string: string, key: Uint8Array): Uint8Array;
  static symmetric_decrypt_filedata(enc_bytes: Uint8Array, key: Uint8Array): Uint8Array;
  static symmetric_decrypt_string(enc_string: string, key: Uint8Array): string;
  /**
   * DEPRECATED: Only used by send keys
   */
  static symmetric_encrypt_bytes(plain: Uint8Array, key: Uint8Array): string;
  static symmetric_encrypt_filedata(plain: Uint8Array, key: Uint8Array): Uint8Array;
  static symmetric_encrypt_string(plain: string, key: Uint8Array): string;
  /**
   * Unwraps (decrypts) a wrapped PKCS8 DER encoded decapsulation (private) key using a symmetric
   * wrapping key.
   */
  static unwrap_decapsulation_key(wrapped_key: string, wrapping_key: Uint8Array): Uint8Array;
  /**
   * Unwraps (decrypts) a wrapped SPKI DER encoded encapsulation (public) key using a symmetric
   * wrapping key.
   */
  static unwrap_encapsulation_key(wrapped_key: string, wrapping_key: Uint8Array): Uint8Array;
  /**
   * Unwraps (decrypts) a wrapped symmetric key using a symmetric wrapping key, returning the
   * unwrapped key as a serialized byte array.
   */
  static unwrap_symmetric_key(wrapped_key: string, wrapping_key: Uint8Array): Uint8Array;
  /**
   * For a given signing identity (verifying key), this function verifies that the signing
   * identity claimed ownership of the public key. This is a one-sided claim and merely shows
   * that the signing identity has the intent to receive messages encrypted to the public
   * key.
   */
  static verify_and_unwrap_signed_public_key(
    signed_public_key: Uint8Array,
    verifying_key: Uint8Array,
  ): Uint8Array;
  /**
   * Given a wrapped signing key and the symmetric key it is wrapped with, this returns
   * the corresponding verifying key.
   */
  static verifying_key_for_signing_key(signing_key: string, wrapping_key: Uint8Array): Uint8Array;
  /**
   * Wraps (encrypts) a PKCS8 DER encoded decapsulation (private) key using a symmetric wrapping
   * key,
   */
  static wrap_decapsulation_key(decapsulation_key: Uint8Array, wrapping_key: Uint8Array): string;
  /**
   * Wraps (encrypts) an SPKI DER encoded encapsulation (public) key using a symmetric wrapping
   * key. Note: Usually, a public key is - by definition - public, so this should not be
   * used. The specific use-case for this function is to enable rotateable key sets, where
   * the "public key" is not public, with the intent of preventing the server from being able
   * to overwrite the user key unlocked by the rotateable keyset.
   */
  static wrap_encapsulation_key(encapsulation_key: Uint8Array, wrapping_key: Uint8Array): string;
  /**
   * Wraps (encrypts) a symmetric key using a symmetric wrapping key, returning the wrapped key
   * as an EncString.
   */
  static wrap_symmetric_key(key_to_be_wrapped: Uint8Array, wrapping_key: Uint8Array): string;
}

/**
 * Client for initializing a user account.
 */
export class RegistrationClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Initializes a new cryptographic state for a user and posts it to the server;
   * enrolls the user to master password unlock.
   */
  post_keys_for_jit_password_registration(
    request: JitMasterPasswordRegistrationRequest,
  ): Promise<JitMasterPasswordRegistrationResponse>;
  /**
   * Initializes a new cryptographic state for a user and posts it to the server; enrolls the
   * user to key connector unlock.
   */
  post_keys_for_key_connector_registration(
    key_connector_url: string,
    sso_org_identifier: string,
  ): Promise<KeyConnectorRegistrationResult>;
  /**
   * Initializes a new cryptographic state for a user and posts it to the server; enrolls in
   * admin password reset and finally enrolls the user to TDE unlock.
   */
  post_keys_for_tde_registration(request: TdeRegistrationRequest): Promise<TdeRegistrationResponse>;
  /**
   * Initializes new password-based cryptographic state for a user
   * and posts the state to the server
   */
  post_keys_for_user_password_registration(
    request: UserMasterPasswordRegistrationRequest,
  ): Promise<UserMasterPasswordRegistrationResponse>;
  /**
   * Seals an [`OpenOrgInvite`] into a [`SealedOpenOrgInvite`]. The returned
   * `sealed_data` is safe to place on the verification-email link; the returned
   * `high_entropy_secret` must stay client-side.
   */
  seal_open_org_invite_data(input: OpenOrgInvite): SealedOpenOrgInvite;
  /**
   * Unseals a [`SealedOpenOrgInvite`] back into an [`OpenOrgInvite`]. Returns
   * [`RegistrationError::Crypto`] if the paired secret does not match the sealed payload or
   * the payload has been tampered with.
   */
  unseal_open_org_invite_data(sealed: SealedOpenOrgInvite): OpenOrgInvite;
}

export enum RsaError {
  Decryption = 0,
  Encryption = 1,
  KeyParse = 2,
  KeySerialize = 3,
}

/**
 * Client exposing random-number generation to cross-platform bindings.
 */
export class SdkRandomNumberClient {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Generate `len` cryptographically-secure random bytes.
   *
   * Returns [`GenBytesError::TooManyBytes`] if `len` exceeds 1 KiB. If you want over 1KiB of
   * randomness, please reconsider your design.
   */
  gen_bytes(len: number): Uint8Array;
  /**
   * Generate a cryptographically-secure random number in the range `[min, max]` (inclusive).
   *
   * Returns [`GenRangeError::InvalidRange`] if `min > max`.
   */
  gen_range(min: number, max: number): number;
  /**
   * Generate a random v4 UUID, sampled from a CRNG
   *
   * This has 122 random bits of entropy.
   */
  gen_uuid(): string;
  /**
   * Construct a new client.
   */
  constructor();
}

export enum SecureNoteType {
  Generic = 0,
}

/**
 * The `SendAccessClient` is used to interact with the Bitwarden API to get send access tokens.
 */
export class SendAccessClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Requests a new send access token.
   */
  request_send_access_token(request: SendAccessTokenRequest): Promise<SendAccessTokenResponse>;
}

export class SendClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Accesses a send, authenticated with a send access token.
   * The returned [SendAccessResponse] contains encrypted fields that must be decrypted
   * client-side using the key derived from the URL fragment.
   */
  access_send(access_token: string): Promise<SendAccessResponse>;
  /**
   * Create a new [Send] and save it to the server.
   */
  create(request: SendAddRequest): Promise<SendView>;
  /**
   * Create a new file [Send] and save it to the server.
   *
   * `file_buffer` is the *plaintext* file content. It is encrypted internally under the send key
   * derived for this send, and its ciphertext length is sent to the server as `file_length` so
   * the server can enforce storage quotas before the upload (matching the legacy client's
   * encrypt-then-create ordering).
   *
   * Returns the created send, the encrypted file bytes, and the metadata needed to upload them.
   * After calling this, hand [`CreateFileSendResponse::encrypted_file_buffer`] and the upload
   * metadata to [`SendClient::upload_send_file`].
   */
  create_file_send(
    request: SendAddRequest,
    file_buffer: Uint8Array,
  ): Promise<CreateFileSendResponse>;
  /**
   * Delete a [Send] from the server and remove it from local state.
   */
  delete(send_id: SendId): Promise<void>;
  /**
   * Edit the [Send] and save it to the server.
   */
  edit(send_id: SendId, request: SendEditRequest): Promise<SendView>;
  /**
   * Get a specific [Send] by its ID from state and decrypt it to a [SendView].
   */
  get(send_id: SendId): Promise<SendView>;
  /**
   * Gets file download data for a file send, authenticated with a send access token.
   */
  get_file_download_data(access_token: string, file_id: string): Promise<SendFileDownloadData>;
  /**
   * Get all sends from state and decrypt them to a list of [SendView].
   */
  list(): Promise<SendView[]>;
  /**
   * Remove the password from a [Send], saving the updated state to the server and local state.
   */
  remove_password(send_id: SendId): Promise<SendView>;
  /**
   * Renew the upload URL for a file [Send].
   *
   * Returns a fresh upload URL if the previous one has expired.
   */
  renew_file_upload_url(send_id: SendId, file_id: string): Promise<string>;
  /**
   * Upload the encrypted file data for a file [Send].
   *
   * `data` must be the encrypted file content (encrypted with the send key).
   * `encrypted_file_name` is the encrypted file name string from [`CreateFileSendResponse`].
   *
   * `file_upload_type` and `upload_url` come from [`CreateFileSendResponse`] and select the
   * upload backend:
   * - [`FileUploadType::Direct`] uploads directly to the Bitwarden server via a multipart POST.
   *   The `upload_url` is ignored in this case (the direct endpoint is derived from the send and
   *   file IDs).
   * - [`FileUploadType::Azure`] `PUT`s the ciphertext to the pre-signed Azure Blob Storage
   *   `upload_url`. If that URL has expired, it is renewed once via
   *   [`SendClient::renew_file_upload_url`] and the upload is retried.
   */
  upload_send_file(
    send_id: SendId,
    file_id: string,
    encrypted_file_name: string,
    file_upload_type: FileUploadType,
    upload_url: string,
    data: Uint8Array,
  ): Promise<void>;
}

/**
 * The type of Send, either text or file
 */
export enum SendType {
  /**
   * Text-based send
   */
  Text = 0,
  /**
   * File-based send
   */
  File = 1,
  /**
   * Item-based send
   */
  Item = 2,
}

/**
 * JavaScript wrapper for ServerCommunicationConfigClient
 *
 * This provides TypeScript access to the server communication configuration client,
 * allowing clients to check bootstrap requirements and retrieve cookies for HTTP requests.
 */
export class ServerCommunicationConfigClient {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Acquires a cookie from the platform and saves it to the repository
   *
   * This method calls the platform API to trigger cookie acquisition (e.g., browser
   * redirect to IdP), then validates and stores the acquired cookie in the repository.
   *
   * # Arguments
   *
   * * `domain` - The server domain (e.g., "vault.acme.com")
   *
   * # Errors
   *
   * Returns an error if:
   * - Cookie acquisition was cancelled by the user
   * - Server configuration doesn't support SSO cookies (Direct bootstrap)
   * - Acquired cookie name doesn't match expected name
   * - Repository operations fail
   */
  acquireCookie(domain: string): Promise<AcquiredCookie[]>;
  /**
   * Returns all cookies that should be included in requests to this server
   *
   * Returns an array of [cookie_name, cookie_value] pairs.
   *
   * # Arguments
   *
   * * `domain` - The server domain (e.g., "vault.acme.com")
   */
  cookies(domain: string): Promise<any>;
  /**
   * Retrieves the server communication configuration for a domain
   *
   * If no configuration exists, returns a default Direct bootstrap configuration.
   *
   * # Arguments
   *
   * * `domain` - The server domain (e.g., "vault.acme.com")
   *
   * # Errors
   *
   * Returns an error if the repository fails to retrieve the configuration.
   */
  getConfig(domain: string): Promise<ServerCommunicationConfig>;
  /**
   * Returns all cookies that should be included in requests to this server
   * and triggers cookie acquisition if needed
   *
   * # Arguments
   *
   * * `domain` - The server domain (e.g., "vault.acme.com")
   */
  getCookies(domain: string): Promise<AcquiredCookie[]>;
  /**
   * Determines if cookie bootstrapping is needed for this domain
   *
   * # Arguments
   *
   * * `domain` - The server domain (e.g., "vault.acme.com")
   */
  needsBootstrap(domain: string): Promise<boolean>;
  /**
   * Creates a new ServerCommunicationConfigClient with a JavaScript repository and platform API
   *
   * The repository should be backed by StateProvider (or equivalent
   * storage mechanism) for persistence.
   *
   * # Arguments
   *
   * * `repository` - JavaScript implementation of the repository interface
   * * `platform_api` - JavaScript implementation of the platform API interface
   */
  constructor(
    repository: ServerCommunicationConfigRepository,
    platform_api: ServerCommunicationConfigPlatformApi,
  );
  /**
   * Sets the server communication configuration for a domain
   *
   * This method saves the provided communication configuration to the repository.
   * Typically called when receiving the `/api/config` response from the server.
   * Previously acquired cookies are preserved automatically.
   *
   * # Arguments
   *
   * * `domain` - The server domain (e.g., "vault.acme.com")
   * * `request` - The server communication configuration to store
   *
   * # Errors
   *
   * Returns an error if the repository save operation fails
   */
  setCommunicationType(domain: string, request: SetCommunicationTypeRequest): Promise<void>;
  /**
   * Sets the server communication configuration using the domain from the config
   *
   * Extracts the `cookie_domain` from the `SsoCookieVendor` config and uses it as the
   * storage key. If the config is `Direct` or `cookie_domain` is not set, the call
   * is silently ignored.
   *
   * # Arguments
   *
   * * `config` - The server communication configuration to store
   *
   * # Errors
   *
   * Returns an error if the repository save operation fails
   */
  setCommunicationTypeV2(request: SetCommunicationTypeRequest): Promise<void>;
}

/**
 * Shared-unlock follower for WASM clients.
 */
export class SharedUnlockFollower {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Forwards a device event to the shared-unlock follower state machine.
   */
  handle_device_event(event: DeviceEvent): Promise<void>;
  /**
   * Starts the shared-unlock follower, which listens for messages from the leader and handles
   * them accordingly. The follower will also send heartbeat messages to the leader at
   * regular intervals to keep the shared session active.
   */
  start(abort_controller?: AbortController | null): Promise<void>;
  /**
   * Creates a new shared-unlock follower
   */
  static try_new(ipc_client: IpcClient, driver: SharedUnlockDriver): SharedUnlockFollower;
}

/**
 * Shared-unlock leader for WASM clients.
 */
export class SharedUnlockLeader {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Forwards a device event to the shared-unlock leader implementation
   */
  handle_device_event(event: DeviceEvent): Promise<void>;
  /**
   * Starts background processing for incoming follower-to-leader IPC messages.
   */
  start(abort_controller?: AbortController | null): Promise<void>;
  /**
   * Creates a new shared-unlock leader
   */
  static try_new(ipc_client: IpcClient, driver: SharedUnlockDriver): SharedUnlockLeader;
}

/**
 * Client for interacting with the key-management state bridge. This is used to read and write
 * state held by the clients
 */
export class StateBridgeClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Registers a the state bridge implementation provided by the host environment.
   */
  register_bridge_impl(bridge_impl: WasmStateBridge): void;
}

export class StateClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  register_client_managed_repositories(repositories: Repositories): void;
}

export class TotpClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Generates a TOTP code from a provided key
   *
   * # Arguments
   * - `key` - Can be:
   *     - A base32 encoded string
   *     - OTP Auth URI
   *     - Steam URI
   * - `time_ms` - Optional timestamp in milliseconds
   */
  generate_totp(key: string, time_ms?: number | null): TotpResponse;
}

export enum UriMatchType {
  Domain = 0,
  Host = 1,
  StartsWith = 2,
  Exact = 3,
  RegularExpression = 4,
  Never = 5,
}

/**
 * Client for managing the cryptographic machinery of a user account, including key-rotation.
 */
export class UserCryptoManagementClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Changes the account's KDF settings, and sets them on the server.
   */
  change_kdf(password: string, new_kdf: Kdf): Promise<void>;
  /**
   * Fetches the emergency access public keys for V1 emergency access memberships for the user.
   * These have to be trusted manually be the user before rotating.
   */
  get_untrusted_emergency_access_public_keys(): Promise<V1EmergencyAccessMembership[]>;
  /**
   * The organization and emergency access public keys the user has to confirm as trusted before
   * a key rotation.
   *
   * When the rotation creates a V2 upgrade token, the organization list is empty. Organization
   * admins update account recovery from that token, so the user confirms nothing. Every other
   * rotation returns one entry per organization the user is enrolled in for account recovery.
   *
   * Emergency access grantees always need a confirmation, because every rotation shares the new
   * user key with each of them.
   */
  get_untrusted_memberships(
    upgrade_token_action: UpgradeTokenAction,
  ): Promise<UntrustedMembershipsResponse>;
  /**
   * The organization public keys the user has to confirm as trusted before a key rotation.
   *
   * When the rotation creates a V2 upgrade token, the list is empty. Organization admins update
   * account recovery from that token, so the user confirms nothing. Every other rotation returns
   * one entry per organization the user is enrolled in for account recovery.
   */
  get_untrusted_organization_public_keys(
    upgrade_token_action: UpgradeTokenAction,
  ): Promise<V1OrganizationMembership[]>;
  /**
   * Migrates an initialized account to Key Connector unlock.
   *
   * Requires the client to be unlocked so the current user key is available in memory.
   */
  migrate_to_key_connector(key_connector_url: string): Promise<void>;
  /**
   * Combines a password change and user key rotation into a single request.
   *
   * Before rotating, this checks whether the user's public key encryption key pair needs
   * regeneration and fixes it if necessary. This ensures that key rotation can proceed even
   * if the existing private key is corrupt.
   */
  password_change_and_rotate_user_keys(
    request: PasswordChangeAndRotateUserKeysRequest,
  ): Promise<void>;
  /**
   * Returns the PIN settings sub-client.
   */
  pin_settings(): PinSettingsClient;
  /**
   * Checks whether the user's public key encryption key pair needs regeneration, and if so,
   * generates a new key pair and submits it to the server.
   *
   * If regeneration is performed, the updated [`WrappedAccountCryptographicState`] is
   * persisted via the state bridge (when registered).
   *
   * Requires the client to be unlocked so the current user key is available in memory.
   * Only applicable to V1 encryption accounts.
   */
  regenerate_public_key_encryption_key_pair_if_needed(): Promise<boolean>;
  /**
   * Rotates the user's encryption keys without a password change.
   */
  rotate_user_keys(request: RotateUserKeysRequest): Promise<void>;
  /**
   * Checks whether the user's public key encryption key pair needs regeneration.
   *
   * Returns `true` if the key pair is missing, corrupt, or doesn't match the public key on
   * the server. Returns `false` if the key pair is valid or if regeneration is not applicable
   * (e.g., user key not available, V2 encryption account).
   */
  should_regenerate_public_key_encryption_key_pair(): Promise<boolean>;
  /**
   * Records the id of the user's current user key with the server, and stores it as the id the
   * server knows.
   *
   * Safe to call when no backfill is needed, but [`Self::user_key_id_needs_backfill`] avoids the
   * round trip.
   *
   * Requires the client to be unlocked so the current user key is available in memory.
   */
  user_key_id_backfill(): Promise<void>;
  /**
   * Returns whether the server is missing the id of the user's current user key.
   */
  user_key_id_needs_backfill(): Promise<boolean>;
}

export class VaultClient {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Attachment related operations.
   */
  attachments(): AttachmentsClient;
  /**
   * Cipher risk evaluation operations.
   */
  cipher_risk(): CipherRiskClient;
  /**
   * Cipher related operations.
   */
  ciphers(): CiphersClient;
  /**
   * Collection related operations.
   */
  collections(): CollectionsClient;
  /**
   * Folder related operations.
   */
  folders(): FoldersClient;
  /**
   * TOTP related operations.
   */
  totp(): TotpClient;
}

/**
 * Atomically validates and applies a reconciliation plan to owned decrypted ciphers.
 */
export function apply_alias_reconciliation(
  plan: AliasReconciliationPlan,
  aliases: Alias[],
  ciphers: CipherView[],
): AliasReconciliationApplyOutput;

/**
 * Binds a canonical reference to a decrypted login cipher after username integrity validation.
 */
export function bind_alias_reference(value: string, cipher: CipherView): AliasCipherMutationResult;

/**
 * Validates and deterministically orders an encrypted provider-neutral journal.
 */
export function canonicalize_alias_journal(journal: AliasJournal): AliasJournal;

/**
 * Clears a binding before save when the login username no longer matches its bound address.
 */
export function clear_alias_reference_if_username_changed(
  cipher: CipherView,
): AliasCipherMutationResult;

/**
 * Creates the canonical serialized v1 alias reference from neutral alias identity.
 */
export function create_alias_reference(identity: AliasIdentity): string;

/**
 * Generate a new SSH key pair
 *
 * # Arguments
 * - `key_algorithm` - The algorithm to use for the key pair
 *
 * # Returns
 * - `Ok(SshKey)` if the key was successfully generated
 * - `Err(KeyGenerationError)` if the key could not be generated
 */
export function generate_ssh_key(key_algorithm: KeyAlgorithm): SshKeyView;

/**
 * Convert a PCKS8 or OpenSSH encrypted or unencrypted private key
 * to an OpenSSH private key with public key and fingerprint
 *
 * # Arguments
 * - `imported_key` - The private key to convert
 * - `password` - The password to use for decrypting the key
 *
 * # Returns
 * - `Ok(SshKey)` if the key was successfully coneverted
 * - `Err(PasswordRequired)` if the key is encrypted and no password was provided
 * - `Err(WrongPassword)` if the password provided is incorrect
 * - `Err(Parsing)` if the key could not be parsed
 * - `Err(UnsupportedKeyType)` if the key type is not supported
 */
export function import_ssh_key(imported_key: string, password?: string | null): SshKeyView;

/**
 * Initialize the SDK. Must be called before using any other API.
 * Only the first invocation has effect; subsequent calls are ignored.
 *
 * - `log_level`: Minimum level for console output. Defaults to `Info`.
 * - `flight_recorder_level`: Minimum level for the flight recorder. Defaults to `Info`.
 * - `flight_recorder_buffer_size`: Ring-buffer capacity for the flight recorder. Defaults to 1000.
 *   Pass `0` to disable the flight recorder entirely.
 */
export function init_sdk(
  log_level?: LogLevel | null,
  flight_recorder_level?: LogLevel | null,
  flight_recorder_buffer_size?: number | null,
): void;

/**
 * Registers shared-unlock biometrics RPC handlers on the IPC client.
 */
export function ipcRegisterBiometricsHandlers(
  ipc_client: IpcClient,
  biometrics_unlock: BiometricsUnlock,
): Promise<void>;

/**
 * Registers a DiscoverHandler so that the client can respond to DiscoverRequests.
 */
export function ipcRegisterDiscoverHandler(
  ipc_client: IpcClient,
  response: DiscoverResponse,
): Promise<void>;

/**
 * Sends an `AuthenticateBiometrics` RPC request to the desktop renderer.
 */
export function ipcRequestAuthenticateBiometrics(
  ipc_client: IpcClient,
  abort_signal?: AbortSignal | null,
): Promise<boolean>;

/**
 * Sends a DiscoverRequest to the specified destination and returns the response.
 */
export function ipcRequestDiscover(
  ipc_client: IpcClient,
  destination: Endpoint,
  abort_signal?: AbortSignal | null,
): Promise<DiscoverResponse>;

/**
 * Sends a `GetBiometricsStatus` RPC request to the desktop renderer
 */
export function ipcRequestGetBiometricsStatus(
  ipc_client: IpcClient,
  user_id: UserId,
  abort_signal?: AbortSignal | null,
): Promise<BiometricsStatus>;

/**
 * Sends an `UnlockBiometrics` RPC request to the desktop renderer.
 */
export function ipcRequestUnlockBiometrics(
  ipc_client: IpcClient,
  user_id: UserId,
  abort_signal?: AbortSignal | null,
): Promise<UnlockBiometricsResponse>;

/**
 * Pure set-union merge for two journals belonging to the same stable connection.
 */
export function merge_alias_journals(left: AliasJournal, right: AliasJournal): AliasJournal;

/**
 * Parses and validates a canonical v1 alias reference without exposing its payload in errors.
 */
export function parse_alias_reference(value: string): AliasReference;

/**
 * Computes a deterministic, read-only reconciliation plan for one stable connection.
 */
export function plan_alias_reconciliation(
  connection_id: string,
  aliases: Alias[],
  ciphers: CipherView[],
): AliasReconciliationPlan;

/**
 * Pure deterministic reduction of canonical journal facts into operation and resource state.
 */
export function reduce_alias_journal(journal: AliasJournal): AliasJournalState;

/**
 * Re-serializes a parsed reference into the one canonical JSON representation.
 */
export function serialize_alias_reference(reference: AliasReference): string;
