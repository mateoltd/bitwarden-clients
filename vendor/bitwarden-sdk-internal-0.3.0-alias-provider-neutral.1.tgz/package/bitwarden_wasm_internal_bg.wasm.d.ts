/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_aliasclient_free: (a: number, b: number) => void;
export const __wbg_flightrecorderclient_free: (a: number, b: number) => void;
export const __wbg_passwordmanagerclient_free: (a: number, b: number) => void;
export const __wbg_purecrypto_free: (a: number, b: number) => void;
export const aliasclient_connection: (a: number) => number;
export const aliasclient_create: (a: number, b: number) => number;
export const aliasclient_create_send_reply_identity: (a: number, b: number) => number;
export const aliasclient_delete: (a: number, b: number) => number;
export const aliasclient_get: (a: number, b: number) => number;
export const aliasclient_list: (a: number, b: number) => number;
export const aliasclient_list_send_reply_identities: (
  a: number,
  b: number,
  c: number,
  d: number,
) => number;
export const aliasclient_new: (a: number, b: number, c: number) => void;
export const aliasclient_remove_send_reply_identity: (a: number, b: number) => number;
export const aliasclient_set_enabled: (a: number, b: number, c: number) => number;
export const aliasclient_set_send_reply_blocked: (a: number, b: number, c: number) => number;
export const apply_alias_reconciliation: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
) => void;
export const bind_alias_reference: (a: number, b: number, c: number, d: number) => void;
export const canonicalize_alias_journal: (a: number, b: number) => void;
export const clear_alias_reference_if_username_changed: (a: number, b: number) => void;
export const create_alias_reference: (a: number, b: number) => void;
export const flightrecorderclient_count: (a: number) => number;
export const flightrecorderclient_new: () => number;
export const flightrecorderclient_read: (a: number, b: number) => void;
export const flightrecorderclient_write: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
  g: number,
) => void;
export const generate_ssh_key: (a: number, b: number) => void;
export const import_ssh_key: (a: number, b: number, c: number, d: number, e: number) => void;
export const init_sdk: (a: number, b: number, c: number) => void;
export const isTestError: (a: number) => number;
export const merge_alias_journals: (a: number, b: number, c: number) => void;
export const parse_alias_reference: (a: number, b: number, c: number) => void;
export const passwordmanagerclient_auth: (a: number) => number;
export const passwordmanagerclient_crypto: (a: number) => number;
export const passwordmanagerclient_crypto_cipher_suite: (a: number) => number;
export const passwordmanagerclient_crypto_sync_handler: (a: number) => number;
export const passwordmanagerclient_echo: (a: number, b: number, c: number, d: number) => void;
export const passwordmanagerclient_exporters: (a: number) => number;
export const passwordmanagerclient_generator: (a: number) => number;
export const passwordmanagerclient_gov_mode: (a: number) => number;
export const passwordmanagerclient_http_get: (a: number, b: number, c: number) => number;
export const passwordmanagerclient_importers: (a: number) => number;
export const passwordmanagerclient_invite_link: (a: number) => number;
export const passwordmanagerclient_new: (a: number, b: number) => number;
export const passwordmanagerclient_platform: (a: number) => number;
export const passwordmanagerclient_policies: (a: number) => number;
export const passwordmanagerclient_sends: (a: number) => number;
export const passwordmanagerclient_throw: (a: number, b: number, c: number, d: number) => void;
export const passwordmanagerclient_user_crypto_management: (a: number) => number;
export const passwordmanagerclient_vault: (a: number) => number;
export const passwordmanagerclient_version: (a: number, b: number) => void;
export const plan_alias_reconciliation: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
  g: number,
) => void;
export const platformclient_load_flags: (a: number, b: number) => number;
export const purecrypto_decapsulate_key_unsigned: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_decrypt_user_key_with_master_key: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_decrypt_user_key_with_master_password: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
  g: number,
  h: number,
) => void;
export const purecrypto_derive_kdf_material: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
) => void;
export const purecrypto_encapsulate_key_unsigned: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_encrypt_user_key_with_master_password: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
  g: number,
  h: number,
) => void;
export const purecrypto_key_algorithm_for_verifying_key: (a: number, b: number, c: number) => void;
export const purecrypto_make_aes256_cbc_hmac_key: (a: number) => void;
export const purecrypto_make_user_key_aes256_cbc_hmac: (a: number) => void;
export const purecrypto_make_user_key_xchacha20_poly1305: (a: number) => void;
export const purecrypto_new_guid: (a: number) => void;
export const purecrypto_random_number: (a: number, b: number) => number;
export const purecrypto_rsa_decrypt_data: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_rsa_encrypt_data: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_rsa_extract_public_key: (a: number, b: number, c: number) => void;
export const purecrypto_rsa_generate_keypair: (a: number) => void;
export const purecrypto_symmetric_decrypt: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_symmetric_decrypt_array_buffer: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_symmetric_decrypt_bytes: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_symmetric_decrypt_filedata: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_symmetric_decrypt_string: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_symmetric_encrypt_bytes: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_symmetric_encrypt_filedata: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_symmetric_encrypt_string: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_unwrap_decapsulation_key: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_unwrap_encapsulation_key: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_unwrap_symmetric_key: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_verify_and_unwrap_signed_public_key: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_verifying_key_for_signing_key: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_wrap_decapsulation_key: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_wrap_encapsulation_key: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const purecrypto_wrap_symmetric_key: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const reduce_alias_journal: (a: number, b: number) => void;
export const serialize_alias_reference: (a: number, b: number) => void;
export const stateclient_register_client_managed_repositories: (a: number, b: number) => void;
export const __wbg_authclient_free: (a: number, b: number) => void;
export const authclient_login: (a: number, b: number) => number;
export const authclient_registration: (a: number) => number;
export const isPasswordLoginError: (a: number) => number;
export const isPasswordPreloginError: (a: number) => number;
export const isRegistrationError: (a: number) => number;
export const loginclient_get_password_prelogin: (a: number, b: number, c: number) => number;
export const loginclient_login_via_password: (a: number, b: number) => number;
export const registrationclient_post_keys_for_jit_password_registration: (
  a: number,
  b: number,
) => number;
export const registrationclient_post_keys_for_key_connector_registration: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => number;
export const registrationclient_post_keys_for_tde_registration: (a: number, b: number) => number;
export const registrationclient_post_keys_for_user_password_registration: (
  a: number,
  b: number,
) => number;
export const registrationclient_seal_open_org_invite_data: (
  a: number,
  b: number,
  c: number,
) => void;
export const registrationclient_unseal_open_org_invite_data: (
  a: number,
  b: number,
  c: number,
) => void;
export const sendaccessclient_request_send_access_token: (a: number, b: number) => number;
export const isCollectionDecryptError: (a: number) => number;
export const __wbg_flagsclient_free: (a: number, b: number) => void;
export const cryptoclient_decrypt_with_local_user_data_key: (
  a: number,
  b: number,
  c: number,
  d: number,
) => void;
export const cryptoclient_encrypt_with_local_user_data_key: (
  a: number,
  b: number,
  c: number,
  d: number,
) => void;
export const cryptoclient_enroll_pin: (a: number, b: number, c: number, d: number) => void;
export const cryptoclient_enroll_pin_with_encrypted_pin: (
  a: number,
  b: number,
  c: number,
  d: number,
) => void;
export const cryptoclient_get_key_id_for_symmetric_key: (a: number, b: number, c: number) => void;
export const cryptoclient_get_user_encryption_key: (a: number) => number;
export const cryptoclient_get_v2_rotated_account_keys: (a: number, b: number) => void;
export const cryptoclient_initialize_org_crypto: (a: number, b: number) => number;
export const cryptoclient_initialize_user_crypto: (a: number, b: number) => number;
export const cryptoclient_make_keys_for_user_crypto_v2: (a: number, b: number) => void;
export const cryptoclient_make_update_kdf: (a: number, b: number, c: number, d: number) => number;
export const cryptoclient_unseal_password_protected_key_envelope: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
) => void;
export const isAccountCryptographyInitializationError: (a: number) => number;
export const isCryptoClientError: (a: number) => number;
export const isDeriveKeyConnectorError: (a: number) => number;
export const isEncryptionSettingsError: (a: number) => number;
export const isEnrollAdminPasswordResetError: (a: number) => number;
export const isMakeKeysError: (a: number) => number;
export const isMasterPasswordError: (a: number) => number;
export const isRotateCryptographyStateError: (a: number) => number;
export const isStatefulCryptoError: (a: number) => number;
export const statebridgeclient_register_bridge_impl: (a: number, b: number) => void;
export const isCryptoError: (a: number) => number;
export const __wbg_cryptociphersuiteclient_free: (a: number, b: number) => void;
export const cryptociphersuiteclient_default_kdf_for_new_account: (a: number) => number;
export const cryptociphersuiteclient_is_kdf_compliant: (a: number, b: number) => number;
export const __wbg_cryptosynchandlerclient_free: (a: number, b: number) => void;
export const cryptosynchandlerclient_on_sync: (a: number, b: number) => number;
export const __wbg_exporterclient_free: (a: number, b: number) => void;
export const exporterclient_export_cxf: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const exporterclient_export_organization_vault: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
  g: number,
) => void;
export const exporterclient_export_vault: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
) => number;
export const exporterclient_import_cxf: (a: number, b: number, c: number, d: number) => void;
export const isExportError: (a: number) => number;
export const __wbg_generatorclient_free: (a: number, b: number) => void;
export const generatorclient_passphrase: (a: number, b: number, c: number) => void;
export const generatorclient_password: (a: number, b: number, c: number) => void;
export const generatorclient_password_rules: (a: number, b: number, c: number, d: number) => void;
export const isPasswordError: (a: number) => number;
export const isPasswordRulesError: (a: number) => number;
export const isUsernameError: (a: number) => number;
export const importerclient_import_kdbx: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
  g: number,
  h: number,
) => number;
export const isImportError: (a: number) => number;
export const __wbg_get_incomingmessage_destination: (a: number) => number;
export const __wbg_get_incomingmessage_payload: (a: number, b: number) => void;
export const __wbg_get_incomingmessage_source: (a: number) => number;
export const __wbg_get_incomingmessage_topic: (a: number, b: number) => void;
export const __wbg_incomingmessage_free: (a: number, b: number) => void;
export const __wbg_ipcclient_free: (a: number, b: number) => void;
export const __wbg_ipcclientsubscription_free: (a: number, b: number) => void;
export const __wbg_ipccommunicationbackend_free: (a: number, b: number) => void;
export const __wbg_outgoingmessage_free: (a: number, b: number) => void;
export const __wbg_set_incomingmessage_destination: (a: number, b: number) => void;
export const __wbg_set_incomingmessage_payload: (a: number, b: number, c: number) => void;
export const __wbg_set_incomingmessage_source: (a: number, b: number) => void;
export const __wbg_set_incomingmessage_topic: (a: number, b: number, c: number) => void;
export const incomingmessage_new: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
) => number;
export const incomingmessage_parse_payload_as_json: (a: number) => number;
export const ipcRegisterDiscoverHandler: (a: number, b: number) => number;
export const ipcRequestDiscover: (a: number, b: number, c: number) => number;
export const ipcclient_isRunning: (a: number) => number;
export const ipcclient_newWithClientManagedSessions: (a: number, b: number) => number;
export const ipcclient_newWithSdkInMemorySessions: (a: number) => number;
export const ipcclient_send: (a: number, b: number) => number;
export const ipcclient_start: (a: number, b: number) => number;
export const ipcclient_subscribe: (a: number) => number;
export const ipcclientsubscription_receive: (a: number, b: number) => number;
export const ipccommunicationbackend_new: (a: number) => number;
export const ipccommunicationbackend_receive: (a: number, b: number, c: number) => void;
export const isAlreadyRunningError: (a: number) => number;
export const isChannelError: (a: number) => number;
export const isDeserializeError: (a: number) => number;
export const isReceiveError: (a: number) => number;
export const isRequestError: (a: number) => number;
export const isSubscribeError: (a: number) => number;
export const isTypedReceiveError: (a: number) => number;
export const outgoingmessage_new: (a: number, b: number, c: number, d: number, e: number) => number;
export const outgoingmessage_new_json_payload: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const __wbg_invitelinkclient_free: (a: number, b: number) => void;
export const invitelinkclient_accept_and_optionally_confirm: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
  g: number,
  h: number,
  i: number,
) => number;
export const invitelinkclient_create_invite_link: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => number;
export const invitelinkclient_get_invite_secret: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const invitelinkclient_refresh_invite_link: (a: number, b: number, c: number) => number;
export const isInviteLinkError: (a: number) => number;
export const __wbg_policyclient_free: (a: number, b: number) => void;
export const policyclient_filter_by_type: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
  g: number,
) => void;
export const __wbg_sdkrandomnumberclient_free: (a: number, b: number) => void;
export const isGenBytesError: (a: number) => number;
export const isGenRangeError: (a: number) => number;
export const sdkrandomnumberclient_gen_bytes: (a: number, b: number, c: number) => void;
export const sdkrandomnumberclient_gen_range: (a: number, b: number, c: number, d: number) => void;
export const sdkrandomnumberclient_gen_uuid: (a: number, b: number) => void;
export const sdkrandomnumberclient_new: () => number;
export const isAccessSendError: (a: number) => number;
export const isCreateFileSendError: (a: number) => number;
export const isCreateSendError: (a: number) => number;
export const isDeleteSendError: (a: number) => number;
export const isEditSendError: (a: number) => number;
export const isGetFileDownloadDataError: (a: number) => number;
export const isGetSendError: (a: number) => number;
export const isRemoveSendPasswordError: (a: number) => number;
export const isRenewFileUploadUrlError: (a: number) => number;
export const isSendAccessDecryptError: (a: number) => number;
export const isSendAccessKeyError: (a: number) => number;
export const isUploadSendFileError: (a: number) => number;
export const sendclient_access_send: (a: number, b: number, c: number) => number;
export const sendclient_create: (a: number, b: number) => number;
export const sendclient_create_file_send: (a: number, b: number, c: number, d: number) => number;
export const sendclient_delete: (a: number, b: number) => number;
export const sendclient_edit: (a: number, b: number, c: number) => number;
export const sendclient_get: (a: number, b: number) => number;
export const sendclient_get_file_download_data: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => number;
export const sendclient_list: (a: number) => number;
export const sendclient_remove_password: (a: number, b: number) => number;
export const sendclient_renew_file_upload_url: (
  a: number,
  b: number,
  c: number,
  d: number,
) => number;
export const sendclient_upload_send_file: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
  g: number,
  h: number,
  i: number,
  j: number,
  k: number,
) => number;
export const __wbg_servercommunicationconfigclient_free: (a: number, b: number) => void;
export const isAcquireCookieError: (a: number) => number;
export const isServerCommunicationConfigRepositoryError: (a: number) => number;
export const servercommunicationconfigclient_acquireCookie: (
  a: number,
  b: number,
  c: number,
) => number;
export const servercommunicationconfigclient_cookies: (a: number, b: number, c: number) => number;
export const servercommunicationconfigclient_getConfig: (a: number, b: number, c: number) => number;
export const servercommunicationconfigclient_getCookies: (
  a: number,
  b: number,
  c: number,
) => number;
export const servercommunicationconfigclient_needsBootstrap: (
  a: number,
  b: number,
  c: number,
) => number;
export const servercommunicationconfigclient_new: (a: number, b: number) => number;
export const servercommunicationconfigclient_setCommunicationType: (
  a: number,
  b: number,
  c: number,
  d: number,
) => number;
export const servercommunicationconfigclient_setCommunicationTypeV2: (
  a: number,
  b: number,
) => number;
export const __wbg_sharedunlockfollower_free: (a: number, b: number) => void;
export const __wbg_sharedunlockleader_free: (a: number, b: number) => void;
export const ipcRegisterBiometricsHandlers: (a: number, b: number) => number;
export const ipcRequestAuthenticateBiometrics: (a: number, b: number) => number;
export const ipcRequestGetBiometricsStatus: (a: number, b: number, c: number) => number;
export const ipcRequestUnlockBiometrics: (a: number, b: number, c: number) => number;
export const isFollowerStartError: (a: number) => number;
export const isLeaderStartError: (a: number) => number;
export const sharedunlockfollower_handle_device_event: (a: number, b: number) => number;
export const sharedunlockfollower_start: (a: number, b: number) => number;
export const sharedunlockfollower_try_new: (a: number, b: number, c: number) => void;
export const sharedunlockleader_handle_device_event: (a: number, b: number) => number;
export const sharedunlockleader_start: (a: number, b: number) => number;
export const sharedunlockleader_try_new: (a: number, b: number, c: number) => void;
export const isKeyGenerationError: (a: number) => number;
export const isSshKeyExportError: (a: number) => number;
export const isSshKeyImportError: (a: number) => number;
export const isDatabaseError: (a: number) => number;
export const isStateRegistryError: (a: number) => number;
export const isCallError: (a: number) => number;
export const isChangeKdfError: (a: number) => number;
export const isKeyIdBackfillError: (a: number) => number;
export const isKeyPairRegenerationError: (a: number) => number;
export const isMigrateToKeyConnectorError: (a: number) => number;
export const isPinSettingsError: (a: number) => number;
export const isRotateUserKeysError: (a: number) => number;
export const isSyncError: (a: number) => number;
export const pinsettingsclient_get_lock_type: (a: number) => number;
export const pinsettingsclient_get_pin: (a: number) => number;
export const pinsettingsclient_get_status: (a: number) => number;
export const pinsettingsclient_set_pin: (a: number, b: number, c: number, d: number) => number;
export const pinsettingsclient_unset_pin: (a: number) => number;
export const pinsettingsclient_validate_pin: (a: number, b: number, c: number) => number;
export const usercryptomanagementclient_change_kdf: (
  a: number,
  b: number,
  c: number,
  d: number,
) => number;
export const usercryptomanagementclient_get_untrusted_emergency_access_public_keys: (
  a: number,
) => number;
export const usercryptomanagementclient_get_untrusted_memberships: (a: number, b: number) => number;
export const usercryptomanagementclient_get_untrusted_organization_public_keys: (
  a: number,
  b: number,
) => number;
export const usercryptomanagementclient_migrate_to_key_connector: (
  a: number,
  b: number,
  c: number,
) => number;
export const usercryptomanagementclient_password_change_and_rotate_user_keys: (
  a: number,
  b: number,
) => number;
export const usercryptomanagementclient_pin_settings: (a: number) => number;
export const usercryptomanagementclient_regenerate_public_key_encryption_key_pair_if_needed: (
  a: number,
) => number;
export const usercryptomanagementclient_rotate_user_keys: (a: number, b: number) => number;
export const usercryptomanagementclient_should_regenerate_public_key_encryption_key_pair: (
  a: number,
) => number;
export const usercryptomanagementclient_user_key_id_backfill: (a: number) => number;
export const usercryptomanagementclient_user_key_id_needs_backfill: (a: number) => number;
export const __wbg_attachmentadminclient_free: (a: number, b: number) => void;
export const __wbg_attachmentsclient_free: (a: number, b: number) => void;
export const __wbg_cipheradminclient_free: (a: number, b: number) => void;
export const __wbg_cipherriskclient_free: (a: number, b: number) => void;
export const __wbg_ciphersclient_free: (a: number, b: number) => void;
export const __wbg_collectionviewnodeitem_free: (a: number, b: number) => void;
export const __wbg_collectionviewtree_free: (a: number, b: number) => void;
export const __wbg_foldersclient_free: (a: number, b: number) => void;
export const attachmentadminclient_delete_attachment: (
  a: number,
  b: number,
  c: number,
  d: number,
) => number;
export const attachmentadminclient_get_attachment_download_url: (
  a: number,
  b: number,
  c: number,
  d: number,
) => number;
export const attachmentsclient_admin: (a: number) => number;
export const attachmentsclient_create_attachment: (a: number, b: number, c: number) => number;
export const attachmentsclient_decrypt_buffer: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
) => void;
export const attachmentsclient_delete_attachment: (
  a: number,
  b: number,
  c: number,
  d: number,
) => number;
export const attachmentsclient_get_attachment_download_url: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
) => number;
export const attachmentsclient_renew_file_upload_url: (
  a: number,
  b: number,
  c: number,
  d: number,
) => number;
export const attachmentsclient_upgrade_attachment: (
  a: number,
  b: number,
  c: number,
  d: number,
) => number;
export const cipheradminclient_create: (a: number, b: number) => number;
export const cipheradminclient_delete: (a: number, b: number) => number;
export const cipheradminclient_delete_many: (a: number, b: number, c: number, d: number) => number;
export const cipheradminclient_edit: (a: number, b: number, c: number) => number;
export const cipheradminclient_list_assigned_org_ciphers: (a: number, b: number) => number;
export const cipheradminclient_list_org_ciphers: (a: number, b: number, c: number) => number;
export const cipheradminclient_restore: (a: number, b: number) => number;
export const cipheradminclient_restore_many: (a: number, b: number, c: number, d: number) => number;
export const cipheradminclient_soft_delete: (a: number, b: number) => number;
export const cipheradminclient_soft_delete_many: (
  a: number,
  b: number,
  c: number,
  d: number,
) => number;
export const cipheradminclient_update_collection: (
  a: number,
  b: number,
  c: number,
  d: number,
) => number;
export const cipherriskclient_compute_risk: (a: number, b: number, c: number, d: number) => number;
export const cipherriskclient_password_reuse_map: (a: number, b: number, c: number) => number;
export const ciphersclient_admin: (a: number) => number;
export const ciphersclient_bulk_update_collections: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
  g: number,
) => number;
export const ciphersclient_create: (a: number, b: number) => number;
export const ciphersclient_decrypt: (a: number, b: number) => number;
export const ciphersclient_decrypt_fido2_credentials: (a: number, b: number, c: number) => void;
export const ciphersclient_decrypt_fido2_private_key: (a: number, b: number, c: number) => void;
export const ciphersclient_decrypt_list: (a: number, b: number, c: number) => number;
export const ciphersclient_decrypt_list_full_with_failures: (
  a: number,
  b: number,
  c: number,
) => number;
export const ciphersclient_decrypt_list_with_failures: (a: number, b: number, c: number) => number;
export const ciphersclient_delete: (a: number, b: number) => number;
export const ciphersclient_delete_many: (a: number, b: number, c: number, d: number) => number;
export const ciphersclient_edit: (a: number, b: number) => number;
export const ciphersclient_edit_partial: (a: number, b: number) => number;
export const ciphersclient_encrypt: (a: number, b: number) => number;
export const ciphersclient_encrypt_cipher_for_rotation: (a: number, b: number, c: number) => number;
export const ciphersclient_encrypt_list: (a: number, b: number, c: number) => number;
export const ciphersclient_get: (a: number, b: number, c: number) => number;
export const ciphersclient_get_all: (a: number) => number;
export const ciphersclient_list: (a: number) => number;
export const ciphersclient_move_many: (a: number, b: number, c: number, d: number) => number;
export const ciphersclient_move_to_organization: (
  a: number,
  b: number,
  c: number,
  d: number,
) => void;
export const ciphersclient_restore: (a: number, b: number) => number;
export const ciphersclient_restore_many: (a: number, b: number, c: number) => number;
export const ciphersclient_set_fido2_credentials: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => void;
export const ciphersclient_share_cipher: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
) => number;
export const ciphersclient_share_ciphers_bulk: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
) => number;
export const ciphersclient_soft_delete: (a: number, b: number) => number;
export const ciphersclient_soft_delete_many: (a: number, b: number, c: number, d: number) => number;
export const ciphersclient_update_collection: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
) => number;
export const collectionsclient_decrypt: (a: number, b: number, c: number) => void;
export const collectionsclient_decrypt_list: (a: number, b: number, c: number, d: number) => void;
export const collectionsclient_encrypt: (a: number, b: number, c: number) => void;
export const collectionsclient_encrypt_list: (a: number, b: number, c: number, d: number) => void;
export const collectionsclient_get_collection_tree: (a: number, b: number, c: number) => number;
export const collectionviewnodeitem_get_ancestors: (a: number) => number;
export const collectionviewnodeitem_get_children: (a: number, b: number) => void;
export const collectionviewnodeitem_get_item: (a: number) => number;
export const collectionviewnodeitem_get_parent: (a: number) => number;
export const collectionviewtree_get_flat_items: (a: number, b: number) => void;
export const collectionviewtree_get_item_for_view: (a: number, b: number) => number;
export const collectionviewtree_get_root_items: (a: number, b: number) => void;
export const foldersclient_create: (a: number, b: number) => number;
export const foldersclient_decrypt: (a: number, b: number, c: number) => void;
export const foldersclient_decrypt_list: (a: number, b: number, c: number, d: number) => void;
export const foldersclient_edit: (a: number, b: number, c: number) => number;
export const foldersclient_encrypt: (a: number, b: number, c: number) => void;
export const foldersclient_get: (a: number, b: number) => number;
export const foldersclient_list: (a: number) => number;
export const isBulkUpdateCollectionsCipherError: (a: number) => number;
export const isCipherAdminGetAttachmentDownloadUrlError: (a: number) => number;
export const isCipherCreateAttachmentError: (a: number) => number;
export const isCipherDeleteAttachmentError: (a: number) => number;
export const isCipherError: (a: number) => number;
export const isCipherGetAttachmentDownloadUrlError: (a: number) => number;
export const isCipherRenewFileUploadUrlError: (a: number) => number;
export const isCipherRiskError: (a: number) => number;
export const isCipherUpgradeAttachmentError: (a: number) => number;
export const isCreateCipherAdminError: (a: number) => number;
export const isCreateCipherError: (a: number) => number;
export const isCreateFolderError: (a: number) => number;
export const isDecryptError: (a: number) => number;
export const isDecryptFileError: (a: number) => number;
export const isDeleteAttachmentAdminError: (a: number) => number;
export const isDeleteCipherAdminError: (a: number) => number;
export const isDeleteCipherError: (a: number) => number;
export const isEditCipherAdminError: (a: number) => number;
export const isEditCipherError: (a: number) => number;
export const isEditFolderError: (a: number) => number;
export const isEncryptError: (a: number) => number;
export const isEncryptFileError: (a: number) => number;
export const isGetAssignedOrgCiphersAdminError: (a: number) => number;
export const isGetCipherError: (a: number) => number;
export const isGetFolderError: (a: number) => number;
export const isGetOrganizationCiphersAdminError: (a: number) => number;
export const isMoveCipherError: (a: number) => number;
export const isRestoreCipherAdminError: (a: number) => number;
export const isRestoreCipherError: (a: number) => number;
export const isTotpError: (a: number) => number;
export const totpclient_generate_totp: (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
) => void;
export const vaultclient_attachments: (a: number) => number;
export const vaultclient_cipher_risk: (a: number) => number;
export const vaultclient_ciphers: (a: number) => number;
export const vaultclient_folders: (a: number) => number;
export const __wbg_intounderlyingbytesource_free: (a: number, b: number) => void;
export const __wbg_intounderlyingsink_free: (a: number, b: number) => void;
export const __wbg_intounderlyingsource_free: (a: number, b: number) => void;
export const intounderlyingbytesource_autoAllocateChunkSize: (a: number) => number;
export const intounderlyingbytesource_cancel: (a: number) => void;
export const intounderlyingbytesource_pull: (a: number, b: number) => number;
export const intounderlyingbytesource_start: (a: number, b: number) => void;
export const intounderlyingbytesource_type: (a: number) => number;
export const intounderlyingsink_abort: (a: number, b: number) => number;
export const intounderlyingsink_close: (a: number) => number;
export const intounderlyingsink_write: (a: number, b: number) => number;
export const intounderlyingsource_cancel: (a: number) => void;
export const intounderlyingsource_pull: (a: number, b: number) => number;
export const passwordmanagerclient_km_state_bridge: (a: number) => number;
export const authclient_send_access: (a: number) => number;
export const vaultclient_collections: (a: number) => number;
export const vaultclient_totp: (a: number) => number;
export const __wbg_get_outgoingmessage_payload: (a: number, b: number) => void;
export const __wbg_set_outgoingmessage_payload: (a: number, b: number, c: number) => void;
export const __wbg_loginclient_free: (a: number, b: number) => void;
export const __wbg_registrationclient_free: (a: number, b: number) => void;
export const __wbg_sendaccessclient_free: (a: number, b: number) => void;
export const __wbg_statebridgeclient_free: (a: number, b: number) => void;
export const __wbg_usercryptomanagementclient_free: (a: number, b: number) => void;
export const __wbg_collectionsclient_free: (a: number, b: number) => void;
export const __wbg_totpclient_free: (a: number, b: number) => void;
export const __wbg_vaultclient_free: (a: number, b: number) => void;
export const __wbg_set_outgoingmessage_topic: (a: number, b: number, c: number) => void;
export const __wbg_set_outgoingmessage_destination: (a: number, b: number) => void;
export const __wbg_get_outgoingmessage_topic: (a: number, b: number) => void;
export const __wbg_get_outgoingmessage_destination: (a: number) => number;
export const __wbg_stateclient_free: (a: number, b: number) => void;
export const __wbg_platformclient_free: (a: number, b: number) => void;
export const platformclient_state: (a: number) => number;
export const __wbg_importerclient_free: (a: number, b: number) => void;
export const __wbg_sendclient_free: (a: number, b: number) => void;
export const __wbg_pinsettingsclient_free: (a: number, b: number) => void;
export const __wbg_cryptoclient_free: (a: number, b: number) => void;
export const wasm_bindgen_939418e668241c4___closure__destroy___dyn_core_a71bc5e03503a777___ops__function__FnMut__web_sys_eec02cc6025bfdb5___features__gen_Event__Event____Output_______: (
  a: number,
  b: number,
) => void;
export const wasm_bindgen_939418e668241c4___closure__destroy___dyn_core_a71bc5e03503a777___ops__function__FnMut__wasm_bindgen_939418e668241c4___JsValue____Output___core_a71bc5e03503a777___result__Result_____wasm_bindgen_939418e668241c4___JsError___: (
  a: number,
  b: number,
) => void;
export const wasm_bindgen_939418e668241c4___closure__destroy___dyn_core_a71bc5e03503a777___ops__function__FnMut__js_sys_9eaf96964521e022___Array____Output___core_a71bc5e03503a777___result__Result_____wasm_bindgen_939418e668241c4___JsError___: (
  a: number,
  b: number,
) => void;
export const wasm_bindgen_939418e668241c4___closure__destroy___dyn_core_a71bc5e03503a777___ops__function__FnMut_____Output_______: (
  a: number,
  b: number,
) => void;
export const wasm_bindgen_939418e668241c4___convert__closures_____invoke___wasm_bindgen_939418e668241c4___JsValue__core_a71bc5e03503a777___result__Result_____wasm_bindgen_939418e668241c4___JsError___true_: (
  a: number,
  b: number,
  c: number,
  d: number,
) => void;
export const wasm_bindgen_939418e668241c4___convert__closures_____invoke___wasm_bindgen_939418e668241c4___JsValue__core_a71bc5e03503a777___result__Result_____wasm_bindgen_939418e668241c4___JsError___true__4: (
  a: number,
  b: number,
  c: number,
  d: number,
) => void;
export const wasm_bindgen_939418e668241c4___convert__closures_____invoke___js_sys_9eaf96964521e022___Function_fn_wasm_bindgen_939418e668241c4___JsValue_____wasm_bindgen_939418e668241c4___sys__Undefined___js_sys_9eaf96964521e022___Function_fn_wasm_bindgen_939418e668241c4___JsValue_____wasm_bindgen_939418e668241c4___sys__Undefined_______true_: (
  a: number,
  b: number,
  c: number,
  d: number,
) => void;
export const wasm_bindgen_939418e668241c4___convert__closures_____invoke___wasm_bindgen_939418e668241c4___JsValue______true_: (
  a: number,
  b: number,
  c: number,
) => void;
export const wasm_bindgen_939418e668241c4___convert__closures_____invoke___wasm_bindgen_939418e668241c4___JsValue______true__1: (
  a: number,
  b: number,
  c: number,
) => void;
export const wasm_bindgen_939418e668241c4___convert__closures_____invoke_______true_: (
  a: number,
  b: number,
) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
